# NVL72 Burn-In System

Automated parallel burn-in qualification for NVIDIA GB200 NVL72 racks,
implementing **NVL72-BIP-001 Rev 1.1** across 100–1,000 racks concurrently
with a minimum of human interaction.

> **Version 1.2** — see `REVIEW.md` for what changed and why. The agent now
> runs **once per compute tray** (18 per rack); the orchestrator aggregates
> node results into the rack verdict and owns every rack state transition.

## How a run works (1.2)

```
operator            orchestrator (leader-elected scheduler)        18 node agents
INSPECTING ──► ONBOARDING (new run_id) ──────────────────────────► directive: run_id
                     BOOTING ◄──────────── node boot_validation (idle) x18
      power-zone admission (slot + stagger) ─► BASELINE ─────────► functional validation
                     BURNING (shared deadline) ◄────────── all 18 passed functional
                     VALIDATING ◄────────────── all 18 completed burn-in
                     PASSED ◄───────────────── all 18 passed post-burn
 any node fails/aborts/goes silent ─► FAILED/ABORTED ─► directive "abort" to all nodes
```

Agent ↔ orchestrator contract: `POST /racks/{rack}/nodes/{node}/events`
(durable, idempotent on `event_id`, ordered by `seq`),
`POST …/heartbeat` (latest-value only), `GET …/directive`.

## Spec items to verify before production (not changed in code)

| Item | Why it needs checking |
|---|---|
| STREAM Triad ≥ 900 GB/s per socket | GB200 Grace LPDDR5X peak is ~512 GB/s per CPU (NVIDIA: up to 18.4 TB/s across 36 Grace). As written, every rack fails. |
| NVLink-C2C ≥ 800 GB/s, P2P ≥ 900 GB/s | Depend on the measurement tool/direction; 900 GB/s C2C is the bidirectional figure. Calibrate on known-good trays. |
| `required_services: [nvidia-fabricmanager]` | On NVL72, fabric management is expected to live on the NVLink switch trays (NMX) and compute trays run IMEX; confirm what runs on your compute-tray image. |
| XID fatal list, `nvlinks_per_gpu: 18`, CPU thermal zone regex | Driver-branch and OS-image specific. |
| No rack-wide NVLink test | Every test is tray-local. Nothing exercises the 72-GPU NVLink domain (e.g. nccl-tests across 18 trays). Recommended as an orchestrator-coordinated step. |

---

## Repository Layout

```
nvl72-burnin/
├── agent/                       # Rack-side Python daemon
│   ├── burnin_agent/
│   │   ├── config.py            # Config loader (YAML + env overrides)
│   │   ├── telemetry.py         # GPU/CPU/coolant/power collection + Prometheus
│   │   ├── abort.py             # Abort condition evaluator
│   │   ├── workloads.py         # gpu_burn / stress-ng / STREAM / HPCG manager
│   │   ├── api_client.py        # Durable ordered outbox + directive client
│   │   ├── proc.py              # Hang-safe subprocess runner
│   │   ├── agent.py             # Main agent loop / state machine
│   │   ├── main.py              # Entry point
│   │   └── phases/
│   │       └── __init__.py      # Phase 2/3/5 execution (BIP-001 §§5-8)
│   ├── requirements.txt
│   └── setup.py
│
├── orchestrator/                # Central FastAPI orchestration service
│   ├── burnin_orchestrator/
│   │   ├── main.py              # FastAPI app + lifespan
│   │   ├── config.py            # Orchestrator config
│   │   ├── models.py            # Pydantic models + RackState enum
│   │   ├── redis_store.py       # Redis-backed state machine + audit log
│   │   ├── scheduler.py         # Staggered-start scheduler
│   │   └── routers/
│   │       ├── racks.py         # Operator rack lifecycle API
│   │       ├── nodes.py         # Node agent API (events/heartbeat/directive)
│   │       ├── metrics.py       # Telemetry ingest + VictoriaMetrics forward
│   │       └── reports.py       # Acceptance report generation (JSON + PDF)
│   ├── Dockerfile
│   └── requirements.txt
│
├── grafana/
│   ├── provisioning/
│   │   ├── datasources/         # VictoriaMetrics + Loki + Orchestrator JSON API
│   │   └── dashboards/          # Auto-provisioned dashboard folder
│   └── dashboards/
│       ├── fleet_overview.json       # State distribution, power, temp heatmap
│       ├── rack_detail.json          # Per-rack GPU/CPU/coolant/NVLink detail
│       └── thermal_fleet_matrix.json # Color-coded per-rack temp timeline
│
├── prometheus/
│   └── rules/
│       └── burnin_alerts.yml    # VictoriaMetrics alerting rules (thermal/error/power)
│
├── alertmanager/
│   └── alertmanager.yml         # PagerDuty (critical) + Slack (warning) routing
│
├── ansible/
│   ├── deploy_agent.yml         # Playbook: deploy agent to rack management OS
│   └── roles/burnin_agent/
│       └── templates/
│           ├── config.yaml.j2        # Per-rack agent config
│           ├── burnin-agent.service.j2  # systemd unit
│           └── promtail.yml.j2       # Log shipping to Loki
│
└── infra/
    ├── docker-compose.yml       # Full stack: orchestrator, Redis, VM, Loki, Grafana
    └── loki-config.yml          # Loki retention and ingestion config
```

---

## Quick Start (Development / Pilot)

### 1. Start the Orchestration Stack

```bash
cd infra
cp .env.example .env          # fill in tokens and webhook URLs
docker compose up -d
```

Services will be available at:
- **Orchestrator API**: http://localhost:8000  (Swagger UI: /docs)
- **Grafana**:          http://localhost:3000  (admin / $GRAFANA_ADMIN_PASSWORD)
- **VictoriaMetrics**:  http://localhost:8428
- **AlertManager**:     http://localhost:9093

### 2. Deploy the Agent to a Rack's 18 Compute Trays

```bash
cd ansible
# inventory: one [rack_<n>] group per rack, one host per compute tray,
# group vars rack_id / power_zone (see header of deploy_agent.yml)
ansible-playbook -i inventory/racks.ini deploy_agent.yml -f 200 \
  -e orchestrator_url=https://burnin-orch.internal/api \
  -e rack_token=<AGENT_TOKEN> \
  -e facility=dc1 \
  -e cdu_api_url=https://cdu.dc1.internal
```

Note the `/api` suffix: nginx serves Grafana at `/` and the orchestrator at
`/api/`. The 1.1 example URL pointed agents at Grafana.

### 3. Register the Rack

```bash
curl -X POST http://localhost:8000/racks \
  -H "Authorization: Bearer $OPERATOR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "rack_id": "rack-001",
    "serial_number": "SN12345",
    "facility": "dc1",
    "power_zone": "zone-A",
    "bmc_ip": "10.0.1.101",
    "mgmt_ip": "10.0.2.101"
  }'
```

### 4. Submit Physical Inspection (Touch 1)

Use the Intake Portal web app or POST directly:

```bash
curl -X POST http://localhost:8000/racks/rack-001/state \
  -H "Authorization: Bearer $OPERATOR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"state": "ONBOARDING", "reason": "Physical inspection passed by tech-01"}'
```

Registration takes `node_count` (default 18) and optional `expected_nodes`
(tray hostnames). The agents then run autonomously; the orchestrator moves
the rack ONBOARDING → BOOTING → (admission) BASELINE → BURNING → VALIDATING →
PASSED. Operator commands: `POST /racks/{id}/commands {"action": "abort|hold|proceed"}`.

### 5. Monitor Progress

Open Grafana → **NVL72 Burn-In** folder → **Fleet Overview** dashboard.

---

## Scaling to Production

### Power Zone Capacity

```bash
ZONE_CAPACITY=50                       # default slots per zone
ZONE_CAPACITIES=zone-A=80,zone-B=40    # per-zone overrides
ZONE_START_INTERVAL_S=300              # admission stagger per zone
```

A rack takes a slot when admitted to BASELINE (the first full-power phase)
and holds it through VALIDATING. Racks waiting for admission hold nothing.

### Deploying Multiple Orchestrator Workers

Workers are stateless (Redis holds all state, noeviction required). One
scheduler leader is elected through a Redis lease, so any number of
workers/replicas is safe. Scale horizontally:
```yaml
# docker-compose.yml
orchestrator:
  deploy:
    replicas: 8
```

Put an L4 load balancer (HAProxy or AWS ALB) in front of the workers.

### VictoriaMetrics at Scale

Node agents are scraped by vmagent (`infra/scrape.yml`); push forwarding
through the orchestrator is off by default. Series count per rack ≈ 18 trays
× ~60 series. The 1.1 estimate below assumed one exporter per rack:
At 1,000 racks × 1,200 metrics × 2 scrapes/min ≈ 40M samples/min. VictoriaMetrics
handles this comfortably on a 6-node cluster. Update `--storageDataPath` to an
NVMe-backed volume and add `--replicationFactor=2` for HA.

---

## Acceptance Criteria Reference (BIP-001 Rev 1.1 §9)

| Criterion | Threshold |
|---|---|
| GPU count | 72/72 |
| Grace socket count | 36/36 |
| DCGM L3 (pre + post) | All PASS |
| GPU memory errors | 0 |
| NVLink CRC errors | 0 |
| NVLink replay errors | ≤ 1,000 / GPU |
| GPU junction peak | ≤ 90°C |
| Grace CPU peak | ≤ 90°C |
| Thermal throttle events | 0 |
| CPU frequency throttle | 0 |
| stress-ng errors | 0 |
| STREAM Triad (each socket) | ≥ 900 GB/s (see "Spec items to verify") |
| NVLink-C2C (each pair) | ≥ 800 GB/s |
| Burn-in duration | ≥ 72h |
| GPU throughput degradation | ≤ 2% |
| STREAM degradation | ≤ 5% |
| All PSUs operational | Yes |
| Coolant leaks | None |

---

## Human Touches Per Rack

| Touch | When | Who | Time |
|---|---|---|---|
| **Touch 1**: Physical intake inspection | INSPECTING state | Technician | ~15 min |
| **Touch 2**: Engineering sign-off | PASSED state | Engineer | ~5 min |

All other steps are executed and validated autonomously by the agent and orchestrator.
