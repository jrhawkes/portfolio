"""NVL72 burn-in node agent."""
__version__ = "1.2.0"
