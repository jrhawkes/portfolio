"""
burnin_agent/agent.py
Node agent: runs BIP-001 on one compute tray under orchestrator control.

Sequence per node
  1. wait for a run assignment (directive carries run_id)
  2. Phase 2 boot validation (idle, low power)            -> phase_result
  3. wait for power-zone admission (rack state BASELINE)
  4. Phase 3 functional validation (full power)           -> phase_result
  5. wait for rack BURNING (all 18 nodes passed phase 3); the directive gives
     one burn deadline for the whole rack so trays finish together
  6. Phase 4 burn-in                                       -> phase_result
  7. cooldown, Phase 5 post-burn validation                -> phase_result
The orchestrator derives the rack verdict from the 18 node results.

What changed vs 1.1 (error handling / broken hardware / scaling)
  * The agent no longer moves the rack to BURNING itself; 1.1 bypassed the
    power-zone scheduler entirely.
  * A SafetyMonitor thread polls telemetry and evaluates aborts for the
    whole life of the agent, including during multi-hour DCGM/memtest runs
    (1.1 only checked during Phase 4). An abort kills in-flight tools and
    workloads immediately.
  * Any workload dying, hanging, or failing to launch aborts (1.1 exempted
    gpu_burn, so a crashed GPU produced a PASS, and STREAM/dcgmi exiting
    normally produced a spurious abort ~60 s into every run).
  * Network calls never block the control loop (see api_client).
  * An operator/rack abort from the orchestrator stops this node too.
  * SIGTERM is handled in the main thread; the orchestrator is told why.
"""

from __future__ import annotations

import json
import logging
import signal
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional

from . import proc
from .abort import AbortEvent, HealthTracker, evaluate as evaluate_abort
from .api_client import OrchestratorClient
from .config import AgentConfig
from .phases import run_boot_validation, run_functional_validation, run_post_burnin
from .telemetry import BENIGN_THROTTLE, TelemetryCollector, TelemetrySnapshot
from .workloads import WorkloadManager

log = logging.getLogger(__name__)

TERMINAL_RACK_STATES = {"FAILED", "ABORTED", "TRIAGE", "QUARANTINED", "PASSED"}
CURRENT_PHASE = {"phase": "init"}          # read by the JSON log formatter


class NodeAborted(Exception):
    """Raised in the main thread once an abort has been decided/reported."""


class SafetyMonitor:
    """Background telemetry + abort evaluation. Thread-safe."""

    def __init__(self, agent: "BurninAgent"):
        self.a = agent
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self.aborted = threading.Event()
        self.abort_events: List[AbortEvent] = []
        self.crc_baseline: Optional[Dict[int, int]] = None
        self.peaks = {"gpu_junction_c": None, "cpu_c": None, "throttle_events": 0}
        self.track_peaks = False

    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True, name="safety-monitor")
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=self.a.cfg.telemetry.collect_timeout_s + 10)

    def reset_crc_baseline(self, snap: Optional[TelemetrySnapshot]):
        if snap:
            with self._lock:
                self.crc_baseline = {g.index: g.nvlink_crc_errors for g in snap.gpus
                                     if g.nvlink_crc_errors is not None}

    def trigger(self, events: List[AbortEvent], snap: Optional[TelemetrySnapshot] = None):
        """Decide an abort (idempotent). Kills tools/workloads, reports once."""
        with self._lock:
            if self.aborted.is_set():
                return
            self.abort_events = events
            self.aborted.set()
        log.error("NODE ABORT: %s", "; ".join(e.message for e in events))
        n = proc.kill_all_active()
        if n:
            log.error("Killed %d in-flight tool process group(s)", n)
        self.a.workloads.terminate_all()
        self.a.api.report_abort([e.to_dict() for e in events],
                                snap.summary() if snap else {})

    def _run(self):
        interval = self.a.cfg.telemetry.poll_interval_s
        while not self._stop.is_set():
            t0 = time.monotonic()
            try:
                self._tick()
            except Exception:                                  # noqa: BLE001
                log.exception("Safety monitor tick failed")
            self._stop.wait(max(1.0, interval - (time.monotonic() - t0)))

    def _tick(self):
        a = self.a
        snap = a.collector.collect_once()
        with self._lock:
            base = dict(self.crc_baseline) if self.crc_baseline is not None else None
        events = a.health.evaluate(snap)
        events += evaluate_abort(snap, a.cfg.abort,
                                 gpu_burn_errors=a.workloads.gpu_burn_errors(),
                                 stressng_errors=a.workloads.stressng_errors(),
                                 nvlink_crc_baseline=base)
        if self.track_peaks:
            self._update_peaks(snap)
        a.api.heartbeat(snap.summary(), phase=CURRENT_PHASE["phase"])
        if events and not self.aborted.is_set():
            self.trigger(events, snap)

    def _update_peaks(self, snap: TelemetrySnapshot):
        g, c = snap.gpu_junction_max(), snap.cpu_temp_max()
        p = self.peaks
        if g is not None:
            p["gpu_junction_c"] = g if p["gpu_junction_c"] is None else max(p["gpu_junction_c"], g)
        if c is not None:
            p["cpu_c"] = c if p["cpu_c"] is None else max(p["cpu_c"], c)
        p["throttle_events"] += sum(1 for gpu in snap.gpus for r in gpu.throttle_reasons
                                    if r not in BENIGN_THROTTLE)


class BurninAgent:
    def __init__(self, cfg: AgentConfig):
        self.cfg = cfg
        self.log_root = Path(cfg.log_dir)
        self.artifact_dir = Path(cfg.state_dir) / "artifacts"
        self.artifact_dir.mkdir(parents=True, exist_ok=True)
        self.run_dir = self.log_root / cfg.rack_id / cfg.node_id / "pending"
        self.run_dir.mkdir(parents=True, exist_ok=True)

        self.collector = TelemetryCollector(cfg, cfg.rack_id)
        self.api = OrchestratorClient(cfg, cfg.rack_id, cfg.node_id)
        self.workloads = WorkloadManager(cfg, self.run_dir)
        self.health = HealthTracker(cfg.abort, self.collector.required_sources(),
                                    cfg.topology.gpus_per_node, cfg.node_id)
        self.monitor = SafetyMonitor(self)
        self._shutdown = threading.Event()
        self._phase_metrics: Dict = {}
        self._burn_deadline: float = 0.0
        signal.signal(signal.SIGTERM, self._handle_signal)
        signal.signal(signal.SIGINT, self._handle_signal)

    # ── entry ────────────────────────────────────────────────────────────────

    def run(self) -> int:
        """Returns a process exit code: 0 pass, 1 fail/abort, 2 agent error."""
        log.info("=== Burn-In Agent starting: rack=%s node=%s leader=%s ===",
                 self.cfg.rack_id, self.cfg.node_id, self.cfg.is_rack_leader)
        self.collector.start_prometheus()
        self.collector.start()
        rc = 2
        try:
            rc = 0 if self._run_procedure() else 1
        except NodeAborted:
            rc = 1
        except Exception as exc:                               # noqa: BLE001
            log.exception("Unhandled exception in agent: %s", exc)
            self.monitor.trigger([AbortEvent("agent_exception", 1.0, 0.0,
                                             message=f"ABORT: agent exception: {exc!r}",
                                             component={"type": "agent",
                                                        "node_id": self.cfg.node_id})])
            rc = 2
        finally:
            self.monitor.stop()
            self.workloads.terminate_all()
            if not self.api.flush(timeout_s=60):
                log.error("%d event(s) still undelivered at exit; they remain in the outbox "
                          "and will be sent if the agent is restarted", self.api.pending_count())
            self.api.stop()
            self.collector.stop()
            log.info("=== Burn-In Agent exiting (rc=%d) ===", rc)
        return rc

    # ── procedure ────────────────────────────────────────────────────────────

    def _run_procedure(self) -> bool:
        self._set_phase("await_run")
        d = self._wait_for(lambda d: bool(d.get("run_id")) and
                           d.get("rack_state") not in TERMINAL_RACK_STATES,
                           "run assignment", timeout_s=24 * 3600)
        self._adopt_run(d["run_id"])

        # Phase 2 (idle). Runs before the monitor so it owns collect_once().
        self._set_phase("boot_validation")
        self.api.report_state("BOOTING", "boot validation")
        passed, m = run_boot_validation(self.cfg, self.collector, self.health)
        self._phase_metrics["boot_validation"] = m
        self.api.report_phase_result("boot_validation", passed, m)
        if not passed:
            return False
        self.monitor.reset_crc_baseline(self.collector.latest)
        self.monitor.start()

        # Admission: the orchestrator moves the rack to BASELINE when the power
        # zone has capacity and every node passed boot validation.
        self._set_phase("await_admission")
        self._wait_for(lambda d: d.get("rack_state") == "BASELINE",
                       "power-zone admission",
                       timeout_s=self.cfg.orchestrator.admission_timeout_h * 3600)

        self._set_phase("functional_validation")
        gpu_idx = [g.index for g in (self.collector.latest.gpus if self.collector.latest else [])]
        passed, m = run_functional_validation(self.cfg, self.run_dir, gpu_idx or None)
        self._check_abort()
        self._phase_metrics["functional_validation"] = m
        self.api.report_phase_result("functional_validation", passed, m)
        if not passed:
            return False

        self._set_phase("await_burn")
        d = self._wait_for(lambda d: d.get("rack_state") == "BURNING", "rack BURNING",
                           timeout_s=6 * 3600)
        now = time.time()
        self._burn_deadline = float(d.get("burn_deadline_ts") or 0) or \
            now + self.cfg.workload.burnin_duration_s
        if self._burn_deadline - now < self.cfg.acceptance.burnin_duration_min_s * 0.95:
            log.warning("Burn deadline gives only %.1fh", (self._burn_deadline - now) / 3600)

        self._set_phase("burnin")
        burn_start = time.time()
        passed, m = self._run_burnin()
        m["duration_s"] = time.time() - burn_start
        if m["duration_s"] < self.cfg.acceptance.burnin_duration_min_s:
            passed = False
            m.setdefault("failures", []).append(
                f"burn-in lasted {m['duration_s'] / 3600:.2f}h < "
                f"{self.cfg.acceptance.burnin_duration_min_s / 3600:.0f}h")
        self._phase_metrics["burnin"] = m
        self.api.report_phase_result("burnin", passed, m)
        if not passed:
            return False

        self._set_phase("cooldown")
        self.api.report_state("COOLING", "workloads stopped")
        cool = self._wait_for_idle_temps()

        self._set_phase("post_burnin")
        passed, m = run_post_burnin(self.cfg, self.run_dir, self._phase_metrics["functional_validation"],
                                    gpu_idx or None)
        self._check_abort()
        m.update(cool)
        m.update(self._thermal_delta())
        self._phase_metrics["post_burnin"] = m
        self.api.report_phase_result("post_burnin", passed, m)
        self._write_result_bundle(passed)
        log.info("=== NODE %s %s ===", self.cfg.node_id, "PASSED" if passed else "FAILED")
        return passed

    # ── Phase 4 ──────────────────────────────────────────────────────────────

    def _run_burnin(self):
        self.monitor.reset_crc_baseline(self.collector.latest)
        self.monitor.peaks = {"gpu_junction_c": None, "cpu_c": None, "throttle_events": 0}
        self.monitor.track_peaks = True
        self.workloads.launch_all(self._burn_deadline)
        start = time.time()
        cps = sorted(int(h) for h in self.cfg.checkpoint_intervals_h)
        done = set()
        next_directive = 0.0
        log.info("Burn-in started; deadline %s", time.ctime(self._burn_deadline))
        try:
            while True:
                self._check_abort()
                now = time.time()
                if now >= self._burn_deadline:
                    break
                fails = self.workloads.check()
                if fails:
                    self.monitor.trigger([AbortEvent(
                        f"workload_{f['workload']}", 1.0, 0.0,
                        message=f"ABORT: workload {f['workload']} failed: {f['reason']}",
                        component={"type": "workload", "node_id": self.cfg.node_id,
                                   "workload": f["workload"]}) for f in fails],
                        self.collector.latest)
                    self._check_abort()
                if now >= next_directive:
                    self._apply_directive(self.api.get_directive())
                    next_directive = now + self.cfg.orchestrator.directive_poll_burn_s
                elapsed_h = (now - start) / 3600
                for h in cps:
                    if elapsed_h >= h and h not in done:
                        done.add(h)
                        self._emit_checkpoint(h)
                self._shutdown.wait(min(10, self.cfg.telemetry.poll_interval_s))
                if self._shutdown.is_set():
                    self._stop_requested()
        finally:
            self.monitor.track_peaks = False
            self.workloads.terminate_all()
        # Final workload verdicts after termination
        status = self.workloads.statuses()
        m = {
            "workloads": status,
            "gpu_burn_errors": self.workloads.gpu_burn_errors(),
            "stressng_errors": self.workloads.stressng_errors(),
            "gpu_junction_peak_c": self.monitor.peaks["gpu_junction_c"],
            "cpu_peak_c": self.monitor.peaks["cpu_c"],
            "thermal_throttle_events": self.monitor.peaks["throttle_events"],
            "stream_samples": {str(k): v for k, v in self.workloads.stream_samples.items()},
            "failures": [],
        }
        acc = self.cfg.acceptance
        if m["gpu_burn_errors"] or m["stressng_errors"]:
            m["failures"].append(f"workload errors gpu_burn={m['gpu_burn_errors']} "
                                 f"stress_ng={m['stressng_errors']}")
        if m["thermal_throttle_events"] > acc.thermal_throttle_events_max:
            m["failures"].append(f"{m['thermal_throttle_events']} thermal/HW throttle samples")
        if m["gpu_junction_peak_c"] is None:
            m["failures"].append("no GPU temperature recorded during burn-in")
        return not m["failures"], m

    def _emit_checkpoint(self, hours: int):
        snap = self.collector.latest
        data = {"elapsed_hours": hours,
                **(snap.summary() if snap else {"telemetry": "unavailable"}),
                "gpu_burn_errors": self.workloads.gpu_burn_errors(),
                "stressng_errors": self.workloads.stressng_errors(),
                "workload_statuses": {n: {"running": s["running"], "errors": s["error_count"]}
                                      for n, s in self.workloads.statuses().items()}}
        try:
            (self.run_dir / f"checkpoint_T{hours:02d}h.json").write_text(json.dumps(data, indent=2))
        except OSError as exc:
            log.warning("Checkpoint write failed: %s", exc)
        self.api.push_checkpoint(hours, data)
        log.info("Checkpoint T+%dh: GPU %s°C CPU %s°C", hours,
                 data.get("gpu_junction_max_c"), data.get("cpu_temp_max_c"))

    # ── waits / directives ───────────────────────────────────────────────────

    def _wait_for(self, predicate, what: str, timeout_s: float) -> Dict:
        """Poll the directive until predicate(directive) holds. Keeps honoring
        abort/terminal states and shutdown; safety monitor keeps running."""
        deadline = time.time() + timeout_s
        last_log = 0.0
        while True:
            self._check_abort()
            d = self.api.get_directive()
            if d is not None:
                self._apply_directive(d)
                if predicate(d):
                    log.info("Proceeding: %s (rack_state=%s)", what, d.get("rack_state"))
                    return d
            if time.time() > deadline:
                ev = AbortEvent(f"timeout_waiting_{what.replace(' ', '_')}", timeout_s, timeout_s,
                                message=f"ABORT: timed out after {timeout_s / 3600:.1f}h waiting "
                                        f"for {what}",
                                component={"type": "orchestration", "node_id": self.cfg.node_id})
                self.monitor.trigger([ev], self.collector.latest)
                raise NodeAborted(what)
            if time.time() - last_log > 600:
                log.info("Waiting for %s (rack_state=%s, orchestrator %s)", what,
                         (d or {}).get("rack_state"), "reachable" if d else "UNREACHABLE")
                last_log = time.time()
            if self._shutdown.wait(self.cfg.orchestrator.directive_poll_s):
                self._stop_requested()

    def _apply_directive(self, d: Optional[Dict]):
        if not d:
            return
        state = d.get("rack_state")
        run_id = d.get("run_id")
        if (CURRENT_PHASE["phase"] != "await_run" and self.cfg.run_id and run_id
                and run_id != self.cfg.run_id):
            self._abort_from_orchestrator(f"run_id changed {self.cfg.run_id} -> {run_id}")
        if d.get("command") == "abort":
            self._abort_from_orchestrator(d.get("reason") or "operator abort")
        if state in TERMINAL_RACK_STATES - {"PASSED"} and CURRENT_PHASE["phase"] != "await_run":
            self._abort_from_orchestrator(f"rack is {state}: {d.get('reason', '')}")

    def _abort_from_orchestrator(self, reason: str):
        self.monitor.trigger([AbortEvent("orchestrator_abort", 1.0, 0.0,
                                         message=f"ABORT: {reason}",
                                         component={"type": "orchestration",
                                                    "node_id": self.cfg.node_id})],
                             self.collector.latest)
        raise NodeAborted(reason)

    def _check_abort(self):
        if self.monitor.aborted.is_set():
            raise NodeAborted("safety monitor abort")
        if self._shutdown.is_set():
            self._stop_requested()

    def _stop_requested(self):
        self.monitor.trigger([AbortEvent("agent_stopped", 1.0, 0.0,
                                         message="ABORT: agent received SIGTERM/SIGINT",
                                         component={"type": "agent", "node_id": self.cfg.node_id})],
                             self.collector.latest)
        raise NodeAborted("signal")

    # ── helpers ──────────────────────────────────────────────────────────────

    def _adopt_run(self, run_id: str):
        self.cfg.run_id = run_id
        self.api.set_run_id(run_id)
        new_dir = self.log_root / self.cfg.rack_id / self.cfg.node_id / run_id
        new_dir.mkdir(parents=True, exist_ok=True)
        self.run_dir = new_dir
        self.workloads = WorkloadManager(self.cfg, new_dir)
        log.info("Adopted run_id=%s; logs in %s", run_id, new_dir)

    def _set_phase(self, phase: str):
        CURRENT_PHASE["phase"] = phase
        log.info("--- phase: %s ---", phase)

    def _wait_for_idle_temps(self, timeout_s: int = 2700) -> Dict:
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            self._check_abort()
            snap = self.collector.latest
            g = snap.gpu_junction_max() if snap else None
            c = snap.cpu_temp_max() if snap else None
            if g is not None and c is not None and g <= 45.0 and c <= 50.0:
                log.info("Idle temperatures reached: GPU %.1f°C CPU %.1f°C", g, c)
                return {"cooldown_reached": True, "cooldown_s": timeout_s - (deadline - time.time())}
            self._shutdown.wait(30)
        log.warning("Cooldown not reached in %ds (or sensors unreadable); continuing", timeout_s)
        return {"cooldown_reached": False, "cooldown_s": timeout_s}

    def _thermal_delta(self) -> Dict:
        snap = self.collector.latest
        base = self._phase_metrics.get("boot_validation", {})
        g = snap.gpu_junction_max() if snap else None
        c = snap.cpu_temp_max() if snap else None
        return {
            "gpu_junction_idle_post_c": g,
            "cpu_temp_idle_post_c": c,
            "gpu_junction_delta_c": (g - base["baseline_gpu_junction_avg_c"])
            if g is not None and base.get("baseline_gpu_junction_avg_c") else None,
            "cpu_temp_delta_c": (c - base["baseline_cpu_temp_avg_c"])
            if c is not None and base.get("baseline_cpu_temp_avg_c") else None,
        }

    def _write_result_bundle(self, passed: bool):
        bundle = {"rack_id": self.cfg.rack_id, "node_id": self.cfg.node_id,
                  "run_id": self.cfg.run_id, "facility": self.cfg.facility,
                  "overall_passed": passed, "timestamp": time.time(),
                  "phases": self._phase_metrics, "log_dir": str(self.run_dir)}
        path = self.artifact_dir / f"result_{self.cfg.rack_id}_{self.cfg.node_id}_{self.cfg.run_id}.json"
        try:
            path.write_text(json.dumps(bundle, indent=2, default=str))
            log.info("Result bundle written: %s", path)
        except OSError as exc:
            log.error("Result bundle write failed: %s", exc)

    def _handle_signal(self, signum, frame):
        # Only set a flag: no blocking work inside a signal handler.
        log.info("Signal %d received; stopping", signum)
        self._shutdown.set()
