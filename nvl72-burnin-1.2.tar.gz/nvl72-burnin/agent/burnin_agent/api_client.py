"""
burnin_agent/api_client.py
HTTP client for the Burn-In Orchestrator.

1.1 problems this replaces:
  * POSTs ran synchronously in the control loop with urllib3 Retry(total=5,
    backoff 2.0) and a 30 s timeout, so an orchestrator outage stalled
    thermal/abort evaluation for minutes per call.
  * Non-idempotent POSTs were retried blindly (duplicate state transitions).
  * 4xx responses were buffered by _post() but then *dropped as sent* by
    flush_buffer() (status < 500), so a rejected ABORT vanished silently.
  * Telemetry was buffered for 24 h and replayed in bulk by every rack at
    once after an outage.

1.2 design:
  * Durable events (state, phase_result, abort, checkpoint) go to a SQLite
    outbox with a monotonically increasing seq and a UUID event_id. A
    background sender delivers them in order; the server de-duplicates on
    event_id, so retries are safe.
  * The control loop only enqueues; it never waits on the network.
  * Heartbeats are latest-value-only and never buffered.
  * Response classes: 2xx -> done; 400/404/409/422 -> dead-letter (logged,
    kept on disk, queue continues); 401/403 -> keep and alarm; 408/429/5xx/
    network -> keep and back off with full jitter (capped).
"""

from __future__ import annotations

import json
import logging
import random
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from typing import Dict, List, Optional

import requests

log = logging.getLogger(__name__)

PERMANENT = {400, 404, 409, 410, 413, 422}
AUTH = {401, 403}


class OrchestratorClient:
    def __init__(self, cfg, rack_id: str, node_id: Optional[str] = None,
                 db_path: Optional[Path] = None, start_sender: bool = True):
        self.cfg = cfg
        self.rack_id = rack_id
        self.node_id = node_id or getattr(cfg, "node_id", "") or "node0"
        self.run_id = getattr(cfg, "run_id", "")
        self._base = cfg.orchestrator.url.rstrip("/")
        self._node_path = f"/racks/{self.rack_id}/nodes/{self.node_id}"
        self._timeout = cfg.orchestrator.timeout_s
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {cfg.orchestrator.token}",
            "Content-Type": "application/json",
            "X-Rack-ID": rack_id,
            "X-Node-ID": self.node_id,
        })
        if getattr(cfg.orchestrator, "ca_bundle", ""):
            self._session.verify = cfg.orchestrator.ca_bundle
        self._db_lock = threading.Lock()
        self._db = self._open_db(db_path or Path(cfg.state_dir) / "outbox.db")
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._heartbeat: Optional[dict] = None
        self._hb_lock = threading.Lock()
        self.last_success_ts: float = 0.0
        self.auth_failing = False
        self._sender: Optional[threading.Thread] = None
        if start_sender:
            self.start()

    # ── lifecycle ─────────────────────────────────────────────────────────────

    def start(self):
        if self._sender is None:
            self._sender = threading.Thread(target=self._send_loop, daemon=True,
                                            name="outbox-sender")
            self._sender.start()

    def stop(self):
        self._stop.set()
        self._wake.set()
        if self._sender:
            self._sender.join(timeout=self._timeout + 5)

    def set_run_id(self, run_id: str):
        self.run_id = run_id

    # ── durable events (enqueue only; never blocks on network) ────────────────

    def report_state(self, new_state: str, reason: str = "") -> str:
        return self._enqueue("state", {"state": new_state, "reason": reason})

    def report_phase_result(self, phase: str, passed: bool, metrics: dict) -> str:
        return self._enqueue("phase_result", {"phase": phase, "passed": passed,
                                              "metrics": metrics})

    def report_abort(self, events: list, snapshot: dict) -> str:
        return self._enqueue("abort", {"abort_events": events, "telemetry_snapshot": snapshot},
                             priority=True)

    def push_checkpoint(self, checkpoint_h: int, snapshot: dict) -> str:
        return self._enqueue("checkpoint", {"hours": checkpoint_h, "snapshot": snapshot})

    # ── best-effort ───────────────────────────────────────────────────────────

    def heartbeat(self, summary: dict, phase: str = ""):
        """Latest-value only. Sent by the sender thread; never buffered."""
        with self._hb_lock:
            self._heartbeat = {"summary": summary, "phase": phase, "run_id": self.run_id,
                               "timestamp": time.time()}
        self._wake.set()

    push_telemetry = heartbeat          # 1.1 name

    def get_directive(self) -> Optional[Dict]:
        """Synchronous, short timeout. None means 'unknown' (offline)."""
        try:
            r = self._session.get(f"{self._base}{self._node_path}/directive",
                                  timeout=min(self._timeout, 10))
            if r.status_code == 200:
                self.last_success_ts = time.time()
                return r.json()
            log.warning("Directive poll HTTP %d: %s", r.status_code, r.text[:200])
        except (requests.RequestException, ValueError) as exc:
            log.debug("Directive poll failed: %s", exc)
        return None

    def pending_count(self) -> int:
        with self._db_lock:
            return self._db.execute("SELECT COUNT(*) FROM outbox").fetchone()[0]

    def flush(self, timeout_s: float) -> bool:
        """Wait until the outbox drains (e.g. before exiting after the final
        verdict). Returns True if empty."""
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            if self.pending_count() == 0:
                return True
            self._wake.set()
            time.sleep(0.5)
        return self.pending_count() == 0

    def flush_buffer(self) -> int:     # 1.1 name; sending is continuous now
        self._wake.set()
        return 0

    # ── sender ────────────────────────────────────────────────────────────────

    def _send_loop(self):
        backoff = 0.0
        # Initial jitter so 18,000 agents restarting together don't stampede.
        self._stop.wait(random.uniform(0, 5))
        while not self._stop.is_set():
            progressed = False
            self._send_heartbeat()
            row = self._peek()
            if row is not None:
                outcome = self._deliver(row)
                if outcome == "done":
                    self._delete(row["id"])
                    progressed, backoff = True, 0.0
                elif outcome == "dead":
                    self._dead_letter(row)
                    progressed = True
                else:
                    backoff = min(self.cfg.orchestrator.backoff_max_s,
                                  max(self.cfg.orchestrator.backoff_initial_s, backoff * 2))
            self._prune_expired()
            if progressed:
                continue                                   # drain quickly while healthy
            wait = random.uniform(0, backoff) if backoff else 5.0
            self._wake.wait(wait)
            self._wake.clear()

    def _deliver(self, row: dict) -> str:
        body = {
            "event_id": row["event_id"], "seq": row["id"], "type": row["type"],
            "run_id": row["run_id"], "timestamp": row["created_at"],
            "payload": json.loads(row["payload"]),
        }
        try:
            r = self._session.post(f"{self._base}{self._node_path}/events", json=body,
                                   timeout=self._timeout)
        except requests.RequestException as exc:
            log.warning("Orchestrator unreachable (%s); %d event(s) queued",
                        type(exc).__name__, self.pending_count())
            return "retry"
        code = r.status_code
        if 200 <= code < 300:
            self.last_success_ts = time.time()
            self.auth_failing = False
            return "done"
        if code in AUTH:
            if not self.auth_failing:
                log.error("Orchestrator rejected credentials (HTTP %d); events held", code)
            self.auth_failing = True
            return "retry"
        if code in PERMANENT:
            log.error("Orchestrator permanently rejected %s event %s (HTTP %d): %s",
                      row["type"], row["event_id"], code, r.text[:300])
            return "dead"
        log.warning("Orchestrator HTTP %d for %s event; will retry", code, row["type"])
        return "retry"

    def _send_heartbeat(self):
        with self._hb_lock:
            hb, self._heartbeat = self._heartbeat, None
        if hb is None:
            return
        try:
            r = self._session.post(f"{self._base}{self._node_path}/heartbeat", json=hb,
                                   timeout=min(self._timeout, 5))
            if r.ok:
                self.last_success_ts = time.time()
        except requests.RequestException:
            pass                                           # latest-only: just drop it

    # ── SQLite outbox ─────────────────────────────────────────────────────────

    def _open_db(self, path: Path) -> sqlite3.Connection:
        path.parent.mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(str(path), check_same_thread=False, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA synchronous=NORMAL")
        db.execute("""CREATE TABLE IF NOT EXISTS outbox (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        event_id TEXT NOT NULL UNIQUE,
                        type TEXT NOT NULL,
                        run_id TEXT NOT NULL,
                        payload TEXT NOT NULL,
                        priority INTEGER NOT NULL DEFAULT 0,
                        created_at REAL NOT NULL)""")
        db.execute("""CREATE TABLE IF NOT EXISTS dead_letter (
                        id INTEGER PRIMARY KEY, event_id TEXT, type TEXT, run_id TEXT,
                        payload TEXT, created_at REAL, failed_at REAL)""")
        n = db.execute("SELECT COUNT(*) FROM outbox").fetchone()[0]
        if n:
            log.info("Outbox holds %d undelivered event(s) from a previous run", n)
        return db

    def _enqueue(self, etype: str, payload: dict, priority: bool = False) -> str:
        eid = str(uuid.uuid4())
        try:
            with self._db_lock:
                self._db.execute(
                    "INSERT INTO outbox (event_id, type, run_id, payload, priority, created_at) "
                    "VALUES (?,?,?,?,?,?)",
                    (eid, etype, self.run_id, json.dumps(payload, default=str),
                     1 if priority else 0, time.time()))
        except sqlite3.Error as exc:
            # Disk full / read-only FS: last resort is a direct attempt.
            log.error("Outbox write failed (%s); attempting direct delivery of %s", exc, etype)
            self._deliver({"id": 0, "event_id": eid, "type": etype, "run_id": self.run_id,
                           "created_at": time.time(), "payload": json.dumps(payload, default=str)})
        self._wake.set()
        return eid

    def _peek(self) -> Optional[dict]:
        # Aborts jump the queue; everything else is strictly ordered by seq.
        with self._db_lock:
            row = self._db.execute(
                "SELECT * FROM outbox ORDER BY priority DESC, id ASC LIMIT 1").fetchone()
        return dict(row) if row else None

    def _delete(self, rid: int):
        with self._db_lock:
            self._db.execute("DELETE FROM outbox WHERE id=?", (rid,))

    def _dead_letter(self, row: dict):
        with self._db_lock:
            self._db.execute(
                "INSERT INTO dead_letter (id, event_id, type, run_id, payload, created_at, failed_at)"
                " VALUES (?,?,?,?,?,?,?)",
                (row["id"], row["event_id"], row["type"], row["run_id"], row["payload"],
                 row["created_at"], time.time()))
            self._db.execute("DELETE FROM outbox WHERE id=?", (row["id"],))

    def _prune_expired(self):
        cutoff = time.time() - self.cfg.orchestrator.offline_buffer_hours * 3600
        with self._db_lock:
            old = self._db.execute("SELECT * FROM outbox WHERE created_at < ?", (cutoff,)).fetchall()
        for row in old:
            log.error("Dropping undeliverable %s event %s older than %dh (moved to dead_letter)",
                      row["type"], row["event_id"], self.cfg.orchestrator.offline_buffer_hours)
            self._dead_letter(dict(row))
