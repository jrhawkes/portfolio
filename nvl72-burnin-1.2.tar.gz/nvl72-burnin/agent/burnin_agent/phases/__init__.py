"""
burnin_agent/phases/__init__.py
Phase execution implementing BIP-001 Rev 1.1 §§5-8, per compute tray.

Each phase returns (passed, metrics). Rules applied throughout (1.2):
  * Fail closed: a tool that is missing, times out, or produces output we
    cannot parse is a phase FAILURE with a reason, never a silent 0 / PASS.
  * All external calls go through proc.run_cmd (hard timeout, hang-safe).
  * Scope is the local tray (topology.gpus_per_node / grace_sockets_per_node);
    rack-wide criteria are aggregated by the orchestrator.
  * Metrics carry GPU UUID/serial so a failure names the part.
"""

from __future__ import annotations

import json
import logging
import re
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .. import proc
from ..telemetry import parse_nvlink_errors
from ..workloads import (cpu_numa_nodes, parse_gpu_burn, parse_stream_triad,
                         parse_stressng, stream_cmd)

log = logging.getLogger(__name__)

PhaseResult = Tuple[bool, Dict]


# ═══════════════════════════════════════════════════════════════════════════════
# Parsers (pure; unit-tested)
# ═══════════════════════════════════════════════════════════════════════════════

def parse_dcgm_diag(stdout: str, rc: Optional[int]) -> Tuple[bool, List[str], int]:
    """
    Parse `dcgmi diag ... -j`. Returns (passed, failure_descriptions, skipped).
    Walks the JSON for any object carrying a result status, so it tolerates
    schema differences between DCGM 3.x and 4.x. Falls back to the text table.
    1.1 checked `"PASS" in stdout`; DCGM prints "Pass", so every run failed.
    A non-zero exit code with nothing parseable is a failure.
    """
    failures: List[str] = []
    skipped = 0
    seen_any = False
    try:
        data = json.loads(stdout[stdout.index("{"):]) if "{" in stdout else None
    except ValueError:
        data = None

    def walk(node, ctx: str):
        nonlocal skipped, seen_any
        if isinstance(node, dict):
            name = str(node.get("name") or node.get("test_name") or node.get("category") or ctx)
            status = node.get("status") or node.get("result")
            if isinstance(status, str):
                seen_any = True
                s = status.strip().lower()
                if s.startswith("fail"):
                    who = node.get("gpu_id", node.get("entity_id", ""))
                    info = node.get("info") or node.get("warnings") or ""
                    failures.append(f"{name}{' gpu ' + str(who) if who != '' else ''}: "
                                    f"{str(info)[:200]}")
                elif s.startswith("skip") or s == "not run":
                    skipped += 1
            for k, v in node.items():
                walk(v, name if k in ("results", "tests") else ctx)
        elif isinstance(node, list):
            for v in node:
                walk(v, ctx)

    if data is not None:
        walk(data, "dcgm")
    else:
        for line in stdout.splitlines():
            cols = [c.strip() for c in line.split("|") if c.strip()]
            if len(cols) >= 2:
                res = cols[-1].lower()
                if res.startswith(("pass", "fail", "skip", "warn")):
                    seen_any = True
                if res.startswith("fail"):
                    failures.append(" | ".join(cols)[:200])
                elif res.startswith("skip"):
                    skipped += 1

    if not seen_any:
        failures.append(f"no parsable DCGM result (rc={rc})")
    elif rc not in (0, None) and not failures:
        failures.append(f"dcgmi exited rc={rc} without a per-test failure")
    return (not failures), failures, skipped


def parse_bw_matrix(text: str) -> List[float]:
    """Numeric cells of the first bandwidth matrix in nvbandwidth /
    p2pBandwidthLatencyTest style output (row label column excluded)."""
    vals: List[float] = []
    in_matrix = False
    for line in text.splitlines():
        low = line.lower()
        if not in_matrix:
            if "gb/s" in low and ("bandwidth" in low or "matrix" in low):
                in_matrix = True
            continue
        s = line.strip()
        if not s:
            if vals:
                break
            continue
        if s.lower().startswith("sum"):
            break
        toks = s.split()
        if not re.fullmatch(r"\d+", toks[0]) or all(re.fullmatch(r"\d+", t) for t in toks):
            continue                                   # column header row (GPU indices)
        for t in toks[1:]:
            try:
                vals.append(float(t))
            except ValueError:
                pass                                   # N/A on the diagonal
    return vals


def parse_nvlink_status(text: str) -> Dict[int, Dict[str, int]]:
    """`nvidia-smi nvlink -s` -> {gpu: {'active': n, 'inactive': m}}."""
    res: Dict[int, Dict[str, int]] = {}
    cur = None
    for line in text.splitlines():
        m = re.match(r"^\s*GPU\s+(\d+)\s*:", line)
        if m:
            cur = int(m.group(1))
            res[cur] = {"active": 0, "inactive": 0}
            continue
        if cur is None or not re.search(r"Link\s+\d+", line):
            continue
        if "inactive" in line.lower():
            res[cur]["inactive"] += 1
        elif re.search(r"[\d.]+\s*GB/s", line):
            res[cur]["active"] += 1
    return res


# ═══════════════════════════════════════════════════════════════════════════════
# Shared steps
# ═══════════════════════════════════════════════════════════════════════════════

def _write(path: Path, res: proc.CmdResult):
    try:
        path.write_text(f"# {' '.join(map(str, res.cmd))}\n# {res.describe()}\n"
                        f"{res.stdout}\n--- stderr ---\n{res.stderr}")
    except OSError as exc:
        log.warning("Could not write %s: %s", path, exc)


def run_dcgm_diag(cmd: List[str], timeout_s: int, log_path: Path) -> Tuple[bool, List[str], int]:
    res = proc.run_cmd(cmd, timeout_s)
    _write(log_path, res)
    if res.error or res.timed_out:
        return False, [res.describe()], 0
    return parse_dcgm_diag(res.stdout, res.rc)


def collect_nvlink_counters(timeout_s: int, gpu_indices: List[int]) -> Tuple[Dict[str, Dict], str]:
    """Returns ({str(gpu): {crc, replay, recovery}}, error). Fail-closed:
    any GPU without parsed counters is an error."""
    res = proc.run_cmd(["nvidia-smi", "nvlink", "-e"], timeout_s)
    if not res.ok:
        return {}, res.describe()
    parsed = parse_nvlink_errors(res.stdout)
    missing = [i for i in gpu_indices if i not in parsed or parsed[i]["links"] == 0]
    out = {str(i): {k: v for k, v in c.items() if k != "links"} for i, c in parsed.items()}
    return out, (f"no NVLink counters parsed for GPUs {missing}" if missing else "")


def run_stream_all(cfg, log_dir: Path, tag: str) -> Tuple[Dict[str, float], List[str]]:
    failures: List[str] = []
    nodes = cpu_numa_nodes()
    expected = cfg.topology.grace_sockets_per_node
    if len(nodes) != expected:
        failures.append(f"{len(nodes)} CPU NUMA nodes found, expected {expected} "
                        f"(check NPS/NUMA mode)")
    results: Dict[str, float] = {}
    for node in nodes:
        cmd, env = stream_cmd(cfg, node)
        res = proc.run_cmd(cmd, cfg.workload.stream_timeout_s, env=env)
        _write(log_dir / f"stream_{tag}_node_{node}.log", res)
        gbs = parse_stream_triad(res.stdout) if res.ok else 0.0
        results[str(node)] = gbs
        if not res.ok:
            failures.append(f"STREAM node {node}: {res.describe()}")
        elif gbs <= 0:
            failures.append(f"STREAM node {node}: Triad not found in output")
        elif gbs < cfg.acceptance.stream_triad_min_gbs:
            failures.append(f"STREAM node {node}: {gbs:.0f} GB/s < "
                            f"{cfg.acceptance.stream_triad_min_gbs:.0f} GB/s")
    return results, failures


def run_stressng_sanity(cfg, log_path: Path) -> Tuple[int, List[str]]:
    res = proc.run_cmd([cfg.workload.stress_ng_binary, "--cpu", "0", "--cpu-method",
                        "matrixprod", "--verify", "--timeout", "300s", "--metrics-brief"], 420)
    _write(log_path, res)
    if res.error or res.timed_out:
        return -1, [f"stress-ng: {res.describe()}"]
    errors = parse_stressng(res.stdout + res.stderr, res.rc)
    fails = [f"stress-ng: {errors} errors (rc={res.rc})"] if errors or res.rc not in (0,) else []
    return errors, fails


def run_gpu_throughput(cfg, log_path: Path) -> Tuple[float, List[str], Dict]:
    """Short gpu_burn; returns (steady aggregate TFLOP/s, failures, per_gpu)."""
    secs = cfg.workload.baseline_gpu_burn_s
    res = proc.run_cmd([cfg.workload.gpu_burn_path, "-tc", "-m", "90%", str(secs)], secs + 300)
    _write(log_path, res)
    r = parse_gpu_burn(res.stdout)
    fails: List[str] = []
    if res.error or res.timed_out:
        fails.append(f"gpu_burn: {res.describe()}")
    if r.progress_lines == 0:
        fails.append("gpu_burn produced no progress output")
    if r.total_errors or r.faulty_gpus or r.died:
        fails.append(f"gpu_burn errors={r.per_gpu_errors} faulty={r.faulty_gpus} died={r.died}")
    per_gpu = {str(i): g for i, g in enumerate(r.per_gpu_gflops)}
    return r.steady_gflops / 1000.0, fails, per_gpu


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 2: OS Boot Validation (BIP-001 §5.2-5.3) — low power
# ═══════════════════════════════════════════════════════════════════════════════

def run_boot_validation(cfg, collector, health=None, baseline_samples: int = 10,
                        sample_interval_s: int = 30) -> PhaseResult:
    metrics: Dict = {}
    failures: List[str] = []
    topo = cfg.topology

    snap = collector.collect_once()
    metrics["gpu_count"] = len(snap.gpus)
    metrics["gpu_inventory"] = [{"index": g.index, "uuid": g.uuid, "serial": g.serial,
                                 "pci_bus_id": g.pci_bus_id} for g in snap.gpus]
    if len(snap.gpus) != topo.gpus_per_node:
        failures.append(f"GPU count {len(snap.gpus)} != expected {topo.gpus_per_node}: "
                        f"{snap.source_errors.get('gpu', '')}")
    if health is not None:
        health.set_inventory(snap.gpus)
    for g in snap.gpus:
        if g.remap_failure:
            failures.append(f"GPU {g.index} ({g.serial}) row-remap failure present at boot")
        if g.remap_pending:
            failures.append(f"GPU {g.index} ({g.serial}) row remap pending (needs reset)")
        if g.ecc_dbe_volatile:
            failures.append(f"GPU {g.index} ({g.serial}) {g.ecc_dbe_volatile} volatile DBEs at boot")

    res = proc.run_cmd(["nvidia-smi", "--query-gpu=driver_version",
                        "--format=csv,noheader"], 30)
    if res.ok and res.stdout.strip():
        ver = res.stdout.strip().splitlines()[0].strip()
        metrics["driver_version"] = ver
        try:
            if int(ver.split(".")[0]) < cfg.tools.min_driver_major:
                failures.append(f"Driver {ver} < minimum {cfg.tools.min_driver_major}")
        except ValueError:
            failures.append(f"Unparseable driver version {ver!r}")
    else:
        failures.append(f"Driver version check: {res.describe()}")

    res = proc.run_cmd(["dcgmi", "discovery", "-l"], 60)
    if res.ok:
        n = len(re.findall(r"^\|\s*\d+\s*\|", res.stdout, re.MULTILINE)) or \
            len(re.findall(r"GPU\s+\d+", res.stdout))
        metrics["dcgm_gpu_count"] = n
        if n < topo.gpus_per_node:
            failures.append(f"DCGM sees {n} GPUs, expected {topo.gpus_per_node}")
    else:
        failures.append(f"DCGM discovery: {res.describe()}")

    # NVLink link state for every local GPU (1.1 checked GPU 0 only).
    res = proc.run_cmd(["nvidia-smi", "nvlink", "-s"], 60)
    if res.ok:
        st = parse_nvlink_status(res.stdout)
        metrics["nvlink_status"] = {str(k): v for k, v in st.items()}
        for g in snap.gpus:
            s = st.get(g.index)
            if s is None:
                failures.append(f"NVLink status missing for GPU {g.index}")
            elif s["inactive"] or s["active"] < topo.nvlinks_per_gpu:
                failures.append(f"GPU {g.index} ({g.serial}): {s['active']}/{topo.nvlinks_per_gpu} "
                                f"NVLinks active, {s['inactive']} inactive")
    else:
        failures.append(f"NVLink status: {res.describe()}")

    for svc in cfg.tools.required_services:
        res = proc.run_cmd(["systemctl", "is-active", svc], 15)
        metrics[f"service_{svc}"] = res.stdout.strip() or res.describe()
        if res.stdout.strip() != "active":
            failures.append(f"service {svc} is {res.stdout.strip() or res.describe()}")

    # Idle thermal baseline. Fail closed: unreadable sensors fail the phase.
    samples = []
    for i in range(baseline_samples):
        s = collector.collect_once()
        samples.append(s)
        if s.xid_events:
            failures.append(f"XID(s) during boot validation: "
                            f"{[(e.xid, e.pci_bus_id) for e in s.xid_events]}")
        if i < baseline_samples - 1:
            time.sleep(sample_interval_s)
    gpu_vals = [s.gpu_junction_max() for s in samples if s.gpu_junction_max() is not None]
    cpu_vals = [s.cpu_temp_max() for s in samples if s.cpu_temp_max() is not None]
    if len(gpu_vals) < baseline_samples // 2:
        failures.append(f"GPU temperature readable in only {len(gpu_vals)}/{baseline_samples} samples")
    if len(cpu_vals) < baseline_samples // 2:
        failures.append(f"CPU temperature readable in only {len(cpu_vals)}/{baseline_samples} samples")
    metrics["baseline_gpu_junction_avg_c"] = _avg(gpu_vals)
    metrics["baseline_cpu_temp_avg_c"] = _avg(cpu_vals)
    metrics["baseline_coolant_inlet_c"] = samples[-1].coolant.inlet_temp_c
    metrics["baseline_coolant_outlet_c"] = samples[-1].coolant.outlet_temp_c
    if gpu_vals and metrics["baseline_gpu_junction_avg_c"] > cfg.acceptance.idle_gpu_junction_max_c:
        failures.append(f"Idle GPU junction {metrics['baseline_gpu_junction_avg_c']:.1f}°C > "
                        f"{cfg.acceptance.idle_gpu_junction_max_c}°C")
    if cpu_vals and metrics["baseline_cpu_temp_avg_c"] > cfg.acceptance.idle_cpu_max_c:
        failures.append(f"Idle CPU {metrics['baseline_cpu_temp_avg_c']:.1f}°C > "
                        f"{cfg.acceptance.idle_cpu_max_c}°C")

    return _finish("Boot validation", metrics, failures)


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 3: Functional Validation (BIP-001 §6) — full power, needs admission
# ═══════════════════════════════════════════════════════════════════════════════

def run_functional_validation(cfg, log_dir: Path, gpu_indices: Optional[List[int]] = None) -> PhaseResult:
    metrics: Dict = {}
    failures: List[str] = []
    tools, acc = cfg.tools, cfg.acceptance
    gpu_indices = gpu_indices if gpu_indices is not None else list(range(cfg.topology.gpus_per_node))

    log.info("DCGM diagnostics (baseline)...")
    ok, fails, skipped = run_dcgm_diag(tools.dcgm_diag_cmd, tools.dcgm_diag_timeout_s,
                                       log_dir / "dcgm_diag_baseline.log")
    metrics.update(dcgm_l3_baseline_passed=ok, dcgm_l3_baseline_failures=fails,
                   dcgm_l3_baseline_skipped=skipped)
    failures += [f"DCGM baseline: {f}" for f in fails]

    log.info("Grace CPU sanity (stress-ng 5 min)...")
    errs, fails = run_stressng_sanity(cfg, log_dir / "stressng_sanity.log")
    metrics["stressng_sanity_errors"] = errs
    failures += fails

    log.info("STREAM baseline per CPU NUMA node...")
    stream, fails = run_stream_all(cfg, log_dir, "baseline")
    metrics["stream_baseline_gbs_per_socket"] = stream
    metrics["stream_baseline_min_gbs"] = min(stream.values()) if stream else 0.0
    failures += fails

    log.info("NVLink-C2C bandwidth...")
    res = proc.run_cmd(tools.c2c_cmd, tools.c2c_timeout_s)
    _write(log_dir / "c2c_baseline.log", res)
    c2c_vals = parse_bw_matrix(res.stdout) if res.ok else []
    metrics["c2c_baseline_gbs"] = min(c2c_vals) if c2c_vals else 0.0
    if not c2c_vals:
        msg = f"C2C test produced no result: {res.describe()}"
        (failures.append if tools.require_c2c_test else log.warning)(msg)
    elif metrics["c2c_baseline_gbs"] < acc.c2c_bandwidth_min_gbs:
        failures.append(f"NVLink-C2C min {metrics['c2c_baseline_gbs']:.0f} GB/s < "
                        f"{acc.c2c_bandwidth_min_gbs:.0f} GB/s")

    log.info("GPU<->GPU NVLink bandwidth (node-local)...")
    res = proc.run_cmd(tools.p2p_cmd, tools.p2p_timeout_s)
    _write(log_dir / "p2p_bandwidth.log", res)
    p2p = parse_bw_matrix(res.stdout) if res.ok else []
    metrics["nvlink_allpairs_min_gbs"] = min(p2p) if p2p else 0.0
    if not p2p:
        failures.append(f"P2P bandwidth test produced no result: {res.describe()}")
    elif min(p2p) < acc.nvlink_p2p_min_gbs:
        failures.append(f"NVLink P2P min {min(p2p):.0f} GB/s < {acc.nvlink_p2p_min_gbs:.0f} GB/s")

    log.info("NVLink error counters (pre-burn-in)...")
    counters, err = collect_nvlink_counters(60, gpu_indices)
    metrics["nvlink_errors_pre_burnin"] = counters
    if err:
        failures.append(f"NVLink counters: {err}")
    crc = sum(c.get("crc", 0) for c in counters.values())
    if crc > 0:
        failures.append(f"Pre-burn-in NVLink CRC errors: {crc}")

    log.info("GPU memory test...")
    ok, fails, _ = run_dcgm_diag(tools.memtest_cmd, tools.memtest_timeout_s, log_dir / "mem_test.log")
    metrics["gpu_memory_test_errors"] = len(fails)
    failures += [f"GPU memtest: {f}" for f in fails]

    log.info("GPU throughput baseline (%ds gpu_burn)...", cfg.workload.baseline_gpu_burn_s)
    tflops, fails, per_gpu = run_gpu_throughput(cfg, log_dir / "gpu_burn_baseline.log")
    metrics["gpu_throughput_baseline_tflops"] = tflops
    metrics["gpu_throughput_baseline_per_gpu_gflops"] = per_gpu
    failures += [f"GPU baseline: {f}" for f in fails]

    return _finish("Functional validation", metrics, failures)


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 5: Post-Burn-In Validation (BIP-001 §8)
# ═══════════════════════════════════════════════════════════════════════════════

def run_post_burnin(cfg, log_dir: Path, baseline_metrics: Dict,
                    gpu_indices: Optional[List[int]] = None) -> PhaseResult:
    metrics: Dict = {}
    failures: List[str] = []
    tools, acc = cfg.tools, cfg.acceptance
    gpu_indices = gpu_indices if gpu_indices is not None else list(range(cfg.topology.gpus_per_node))

    ok, fails, skipped = run_dcgm_diag(tools.dcgm_diag_cmd, tools.dcgm_diag_timeout_s,
                                       log_dir / "dcgm_diag_post_burnin.log")
    metrics.update(dcgm_l3_post_passed=ok, dcgm_l3_post_failures=fails,
                   dcgm_l3_post_skipped=skipped)
    failures += [f"DCGM post: {f}" for f in fails]

    stream, fails = run_stream_all(cfg, log_dir, "post")
    metrics["stream_post_gbs_per_socket"] = stream
    metrics["stream_post_min_gbs"] = min(stream.values()) if stream else 0.0
    failures += fails
    base = baseline_metrics.get("stream_baseline_gbs_per_socket", {})
    degr = {}
    for node, gbs in stream.items():
        b = base.get(node, 0.0)
        if b > 0 and gbs > 0:
            d = (b - gbs) / b * 100
            degr[node] = round(d, 2)
            if d > acc.stream_degradation_max_pct:
                failures.append(f"STREAM node {node} degraded {d:.1f}% ({b:.0f} -> {gbs:.0f} GB/s)")
        elif b <= 0:
            failures.append(f"STREAM node {node}: no baseline to compare against")
    metrics["stream_degradation_pct"] = degr
    metrics["stream_degradation_max_pct"] = max(degr.values()) if degr else None

    errs, fails = run_stressng_sanity(cfg, log_dir / "stressng_post.log")
    metrics["stressng_post_errors"] = errs
    failures += fails

    counters, err = collect_nvlink_counters(60, gpu_indices)
    (log_dir / "nvlink_errors_post.json").write_text(json.dumps(counters, indent=2))
    metrics["nvlink_errors_post"] = counters
    if err:
        failures.append(f"NVLink counters: {err}")
    pre = baseline_metrics.get("nvlink_errors_pre_burnin", {})
    crc_delta = sum(max(0, c.get("crc", 0) - pre.get(g, {}).get("crc", 0)) for g, c in counters.items())
    max_replay = max((c.get("replay", 0) for c in counters.values()), default=0)
    metrics["nvlink_crc_total"] = crc_delta
    metrics["nvlink_replay_max_per_gpu"] = max_replay
    if crc_delta > acc.nvlink_crc_errors_max:
        failures.append(f"NVLink CRC errors during burn-in: {crc_delta}")
    if max_replay > acc.nvlink_replay_errors_per_gpu_max:
        failures.append(f"NVLink replay max/GPU {max_replay} > {acc.nvlink_replay_errors_per_gpu_max}")

    tflops, fails, per_gpu = run_gpu_throughput(cfg, log_dir / "gpu_burn_post.log")
    metrics["gpu_throughput_post_tflops"] = tflops
    metrics["gpu_throughput_post_per_gpu_gflops"] = per_gpu
    failures += [f"GPU post: {f}" for f in fails]
    base_t = baseline_metrics.get("gpu_throughput_baseline_tflops", 0.0)
    if base_t > 0 and tflops > 0:
        d = (base_t - tflops) / base_t * 100
        metrics["gpu_throughput_degradation_pct"] = round(d, 2)
        if d > acc.gpu_throughput_degradation_max_pct:
            failures.append(f"GPU throughput degraded {d:.2f}% ({base_t:.1f} -> {tflops:.1f} TFLOP/s)")
    else:
        metrics["gpu_throughput_degradation_pct"] = None
        failures.append("GPU throughput degradation not computable (missing baseline or post value)")
    # Per-GPU regression catches one weak GPU hidden inside the aggregate.
    base_pg = baseline_metrics.get("gpu_throughput_baseline_per_gpu_gflops", {})
    for g, v in per_gpu.items():
        b = base_pg.get(g)
        if b and v and (b - v) / b * 100 > acc.gpu_throughput_degradation_max_pct:
            failures.append(f"GPU {g} throughput degraded {(b - v) / b * 100:.1f}%")

    return _finish("Post-burn-in validation", metrics, failures)


def _avg(vals: List[float]) -> float:
    return sum(vals) / len(vals) if vals else 0.0


def _finish(name: str, metrics: Dict, failures: List[str]) -> PhaseResult:
    metrics["failures"] = failures
    if failures:
        log.error("%s FAILED: %s", name, failures)
    else:
        log.info("%s PASSED", name)
    return not failures, metrics


# 1.1 names kept for callers/tests
_parse_stream_triad = parse_stream_triad


def _parse_gpu_burn_gflops(output: str) -> float:
    return parse_gpu_burn(output).steady_gflops


def _count_stressng_errors(output: str) -> int:
    return parse_stressng(output)
