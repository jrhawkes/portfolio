"""
burnin_agent/proc.py
Bounded subprocess execution.

Every external tool the agent calls (nvidia-smi, dcgmi, ipmitool, STREAM, ...)
goes through run_cmd(). The point is that a broken GPU, BMC or driver must
never be able to stall the control loop:

  * a hard timeout is always enforced;
  * on timeout the whole process group is SIGKILLed;
  * if the child still cannot be reaped (uninterruptible sleep, typical of a
    GPU that has fallen off the bus or a wedged driver), it is abandoned and
    reported as `unkillable` instead of blocking forever in wait();
  * launch failures (missing binary, EACCES) come back as a result, not an
    exception, so callers can decide fail-open vs fail-closed explicitly.
"""

from __future__ import annotations

import logging
import os
import signal
import subprocess
import threading
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

log = logging.getLogger(__name__)

# Count of children we had to abandon. A growing value means tools are hanging
# in the kernel, which is itself a hardware/driver health signal.
_abandoned_lock = threading.Lock()
_abandoned: int = 0


def abandoned_count() -> int:
    with _abandoned_lock:
        return _abandoned


# Process groups of run_cmd children currently executing, so the safety
# monitor can stop a 4-hour memtest the moment a thermal abort fires.
_active_lock = threading.Lock()
_active: Dict[int, str] = {}


def kill_all_active(sig: int = signal.SIGKILL) -> int:
    """Signal every in-flight run_cmd child. Returns how many were signalled."""
    with _active_lock:
        pids = list(_active.items())
    for pid, name in pids:
        log.warning("Killing in-flight %s (pid %d)", name, pid)
        _killpg(pid, sig)
    return len(pids)


@dataclass
class CmdResult:
    cmd: Sequence[str]
    rc: Optional[int] = None
    stdout: str = ""
    stderr: str = ""
    timed_out: bool = False
    unkillable: bool = False
    error: Optional[str] = None       # launch failure or other non-rc problem
    duration_s: float = 0.0

    @property
    def ok(self) -> bool:
        return self.error is None and not self.timed_out and self.rc == 0

    def describe(self) -> str:
        name = os.path.basename(str(self.cmd[0])) if self.cmd else "?"
        if self.error:
            return f"{name}: {self.error}"
        if self.timed_out:
            extra = " (unkillable, abandoned)" if self.unkillable else ""
            return f"{name}: timed out after {self.duration_s:.0f}s{extra}"
        if self.rc != 0:
            tail = (self.stderr or self.stdout).strip().splitlines()[-1:] or [""]
            return f"{name}: exit {self.rc}: {tail[0][:200]}"
        return f"{name}: ok"


def run_cmd(cmd: List[str], timeout_s: float,
            env: Optional[Dict[str, str]] = None,
            reap_grace_s: float = 5.0) -> CmdResult:
    """Run cmd with a hard timeout. Never raises for process-level failures."""
    global _abandoned
    t0 = time.monotonic()
    res = CmdResult(cmd=list(cmd))
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            errors="replace",
            start_new_session=True,       # own process group; thread-safe (no preexec_fn)
            env=env,
        )
    except (OSError, ValueError) as exc:
        res.error = f"launch failed: {exc}"
        res.duration_s = time.monotonic() - t0
        return res

    with _active_lock:
        _active[proc.pid] = os.path.basename(str(cmd[0]))
    try:
        res.stdout, res.stderr = proc.communicate(timeout=timeout_s)
        res.rc = proc.returncode
    except subprocess.TimeoutExpired:
        res.timed_out = True
        _killpg(proc.pid, signal.SIGKILL)
        try:
            res.stdout, res.stderr = proc.communicate(timeout=reap_grace_s)
            res.rc = proc.returncode
        except subprocess.TimeoutExpired:
            res.unkillable = True
            with _abandoned_lock:
                _abandoned += 1
            log.error("Abandoning unkillable child pid=%d (%s); likely stuck in the "
                      "kernel on a hung device", proc.pid, cmd[0])
    finally:
        with _active_lock:
            _active.pop(proc.pid, None)
    res.duration_s = time.monotonic() - t0
    return res


def _killpg(pid: int, sig: int):
    try:
        os.killpg(os.getpgid(pid), sig)
    except (ProcessLookupError, PermissionError):
        pass
