"""
burnin_agent/telemetry.py
Collects node telemetry: GPU (nvidia-smi), NVLink error counters, Grace CPU
(sysfs), tray power/PSU (in-band IPMI), rack coolant (CDU API, leader only)
and kernel XID events (journald).

Design rules (1.2):
  * Fail closed. A source that errors is recorded in snapshot.source_errors
    and its values are None, never 0.0. The abort evaluator decides what an
    unknown value means; telemetry never silently reports "cool and healthy".
  * Bounded. Sources run concurrently, each with a hard timeout, via
    proc.run_cmd(); a hung nvidia-smi cannot delay the thermal check of the
    other sources or the next poll.
  * Identifiable. Every GPU carries UUID, serial and PCI bus id so an abort
    names the part to pull, not just an index.
"""

from __future__ import annotations

import logging
import re
import subprocess
import threading
import time
from collections import deque
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Callable, Deque, Dict, List, Optional, Tuple

import requests
from prometheus_client import Counter, Gauge, start_http_server

from . import proc

log = logging.getLogger(__name__)

# ── Prometheus metrics ────────────────────────────────────────────────────────

GPU_JUNCTION_TEMP = Gauge("burnin_gpu_junction_temp_c", "GPU junction temperature °C", ["gpu_index"])
GPU_HBM_TEMP      = Gauge("burnin_gpu_hbm_temp_c", "GPU HBM temperature °C", ["gpu_index"])
GPU_SM_UTIL       = Gauge("burnin_gpu_sm_util_pct", "GPU SM utilization %", ["gpu_index"])
GPU_POWER_W       = Gauge("burnin_gpu_power_w", "GPU power draw W", ["gpu_index"])
GPU_NVLINK_CRC    = Gauge("burnin_gpu_nvlink_crc_errors", "NVLink CRC errors cumulative", ["gpu_index"])
GPU_NVLINK_REPLAY = Gauge("burnin_gpu_nvlink_replay_errors", "NVLink replay errors cumulative", ["gpu_index"])
GPU_THROTTLE      = Gauge("burnin_gpu_throttle_active", "GPU clock event reason active (1=yes)", ["gpu_index", "reason"])
GPU_ECC_DBE       = Gauge("burnin_gpu_ecc_dbe_volatile", "Volatile uncorrectable ECC errors", ["gpu_index"])
GPU_VISIBLE       = Gauge("burnin_gpu_visible_count", "GPUs visible to nvidia-smi on this node")

CPU_TEMP_C        = Gauge("burnin_cpu_temp_c", "Grace CPU temperature °C", ["socket"])
CPU_FREQ_MHZ      = Gauge("burnin_cpu_freq_mhz", "Grace CPU current frequency MHz", ["socket"])

COOLANT_INLET_C   = Gauge("burnin_coolant_inlet_temp_c", "CDU coolant inlet temperature °C")
COOLANT_OUTLET_C  = Gauge("burnin_coolant_outlet_temp_c", "CDU coolant outlet temperature °C")
COOLANT_FLOW_LPM  = Gauge("burnin_coolant_flow_lpm", "Coolant flow rate L/min")

TRAY_POWER_KW     = Gauge("burnin_tray_power_kw", "Compute tray power draw kW (DCMI)")
PSU_FAULT_COUNT   = Gauge("burnin_psu_fault_count", "PSUs reporting a fault (tray BMC view)")

SOURCE_OK         = Gauge("burnin_telemetry_source_ok", "1 if the last collection of the source succeeded", ["source"])
SOURCE_LAST_OK_TS = Gauge("burnin_telemetry_last_success_timestamp_seconds", "Unix time of last successful collection", ["source"])
TELEMETRY_ERRORS  = Counter("burnin_telemetry_errors_total", "Telemetry collection errors", ["source"])
XID_EVENTS        = Counter("burnin_xid_events_total", "NVIDIA XID events seen in the kernel log", ["xid", "gpu_index"])
ABANDONED_CHILDREN = Gauge("burnin_abandoned_children", "Tool invocations abandoned as unkillable")

# nvidia-smi clocks_event_reasons.active bitmask (NVML nvmlClocksEventReasons).
THROTTLE_BITS: Dict[int, str] = {
    0x1:   "gpu_idle",
    0x2:   "applications_clocks_setting",
    0x4:   "sw_power_cap",
    0x8:   "hw_slowdown",
    0x10:  "sync_boost",
    0x20:  "sw_thermal_slowdown",
    0x40:  "hw_thermal_slowdown",
    0x80:  "hw_power_brake_slowdown",
    0x100: "display_clock_setting",
}
# Reasons that are expected under a sustained burn and are not faults.
BENIGN_THROTTLE = {"sw_power_cap", "gpu_idle", "applications_clocks_setting",
                   "sync_boost", "display_clock_setting", "None", ""}

_NA = {"", "n/a", "[n/a]", "not supported", "[not supported]", "[unknown error]",
       "unknown error", "[gpu is lost]", "gpu is lost"}


# ── Snapshot dataclasses ──────────────────────────────────────────────────────

@dataclass
class GpuSnapshot:
    index: int
    uuid: str = ""
    serial: str = ""
    pci_bus_id: str = ""
    junction_temp_c: Optional[float] = 0.0
    hbm_temp_c: Optional[float] = 0.0
    sm_util_pct: Optional[float] = 0.0
    power_w: Optional[float] = 0.0
    nvlink_crc_errors: Optional[int] = 0
    nvlink_replay_errors: Optional[int] = 0
    throttle_reasons: List[str] = field(default_factory=list)
    ecc_dbe_volatile: Optional[int] = None
    remap_failure: Optional[bool] = None
    remap_pending: Optional[bool] = None


@dataclass
class CpuSnapshot:
    socket: int
    temp_c: Optional[float] = 0.0
    power_w: Optional[float] = None
    freq_mhz: Optional[float] = None


@dataclass
class CoolantSnapshot:
    inlet_temp_c: Optional[float] = None
    outlet_temp_c: Optional[float] = None
    flow_lpm: Optional[float] = None
    source: str = "none"


@dataclass
class PowerSnapshot:
    rack_total_kw: Optional[float] = None     # kept for 1.1 compatibility (= tray power)
    psu_fault_count: Optional[int] = 0


@dataclass
class XidEvent:
    xid: int
    pci_bus_id: str
    gpu_index: Optional[int]
    message: str
    timestamp: float


@dataclass
class TelemetrySnapshot:
    timestamp: float = field(default_factory=time.time)
    node_id: str = ""
    gpus: List[GpuSnapshot] = field(default_factory=list)
    cpus: List[CpuSnapshot] = field(default_factory=list)
    coolant: CoolantSnapshot = field(default_factory=CoolantSnapshot)
    power: PowerSnapshot = field(default_factory=PowerSnapshot)
    xid_events: List[XidEvent] = field(default_factory=list)
    # source name -> error text for every source that failed this poll
    source_errors: Dict[str, str] = field(default_factory=dict)
    abandoned_children: int = 0

    def to_dict(self) -> dict:
        return asdict(self)

    def gpu_junction_max(self) -> Optional[float]:
        vals = [g.junction_temp_c for g in self.gpus if g.junction_temp_c is not None]
        return max(vals) if vals else None

    def gpu_hbm_max(self) -> Optional[float]:
        vals = [g.hbm_temp_c for g in self.gpus if g.hbm_temp_c is not None]
        return max(vals) if vals else None

    def cpu_temp_max(self) -> Optional[float]:
        vals = [c.temp_c for c in self.cpus if c.temp_c is not None]
        return max(vals) if vals else None

    def nvlink_crc_total(self) -> int:
        return sum(g.nvlink_crc_errors or 0 for g in self.gpus)

    def nvlink_replay_max(self) -> int:
        return max((g.nvlink_replay_errors or 0 for g in self.gpus), default=0)

    def throttle_active(self) -> bool:
        return any(r not in BENIGN_THROTTLE for g in self.gpus for r in g.throttle_reasons)

    def summary(self) -> dict:
        """Compact form for heartbeats / checkpoints (no per-GPU arrays)."""
        return {
            "timestamp": self.timestamp,
            "node_id": self.node_id,
            "gpu_count": len(self.gpus),
            "gpu_junction_max_c": self.gpu_junction_max(),
            "gpu_hbm_max_c": self.gpu_hbm_max(),
            "cpu_temp_max_c": self.cpu_temp_max(),
            "coolant_inlet_c": self.coolant.inlet_temp_c,
            "coolant_outlet_c": self.coolant.outlet_temp_c,
            "tray_power_kw": self.power.rack_total_kw,
            "nvlink_crc_total": self.nvlink_crc_total(),
            "source_errors": dict(self.source_errors),
            "xid_count": len(self.xid_events),
        }


# ── Parsers (pure functions; unit-tested) ────────────────────────────────────

def _num(s: str) -> Optional[float]:
    s = s.strip()
    if s.lower() in _NA:
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _yesno(s: str) -> Optional[bool]:
    s = s.strip().lower()
    if s in ("yes", "1", "true"):
        return True
    if s in ("no", "0", "false"):
        return False
    return None


def decode_throttle(value: str) -> Tuple[List[str], List[str]]:
    """Decode a clocks_event_reasons bitmask. Returns (reasons, unknown_bits)."""
    v = value.strip()
    if v.lower() in _NA:
        return [], []
    try:
        mask = int(v, 16) if v.lower().startswith("0x") else int(v)
    except ValueError:
        # Older drivers print names ("Not Active", "SW Power Cap") in some modes.
        return ([] if v.lower() in ("not active", "none") else [v.lower().replace(" ", "_")]), []
    reasons, unknown = [], []
    bit = 1
    while mask and bit <= mask:
        if mask & bit:
            if bit in THROTTLE_BITS:
                reasons.append(THROTTLE_BITS[bit])
            else:
                unknown.append(hex(bit))
        bit <<= 1
    return reasons, unknown


def normalize_pci(bus_id: str) -> str:
    """'00000009:01:00.0' / '0009:01:00' -> '9:1:0' for cross-tool matching."""
    try:
        parts = bus_id.strip().split(":")
        if len(parts) == 2:
            parts = ["0"] + parts
        dom, bus, devfn = parts[-3], parts[-2], parts[-1]
        dev = devfn.split(".")[0]
        return f"{int(dom, 16)}:{int(bus, 16)}:{int(dev, 16)}"
    except (ValueError, IndexError):
        return bus_id.strip().lower()


def parse_nvlink_errors(out: str) -> Dict[int, Dict[str, int]]:
    """
    Parse `nvidia-smi nvlink -e` (all GPUs). Returns {gpu_index: {crc, replay,
    recovery, links}}. Counter naming differs across driver branches
    ("CRC Flit Error Counter", "CRC Errors", ...), so we match on keywords and
    take the last integer on the line. A GPU header with no counter lines is
    returned with links=0 so the caller can treat it as unparsed.
    """
    res: Dict[int, Dict[str, int]] = {}
    cur: Optional[int] = None
    for line in out.splitlines():
        m = re.match(r"^\s*GPU\s+(\d+)\s*:", line)
        if m:
            cur = int(m.group(1))
            res[cur] = {"crc": 0, "replay": 0, "recovery": 0, "links": 0}
            continue
        if cur is None:
            continue
        ll = line.lower()
        nums = re.findall(r"(\d+)\s*$", line.strip())
        if not nums:
            continue
        val = int(nums[-1])
        if "crc" in ll:
            res[cur]["crc"] += val
            res[cur]["links"] += 1
        elif "replay" in ll:
            res[cur]["replay"] += val
        elif "recovery" in ll:
            res[cur]["recovery"] += val
    return res


def count_psu_faults(sdr_out: str) -> int:
    """Count PSU sensors asserting a fault in `ipmitool sdr type 'Power Supply'`.
    'Presence detected' is normal and must not be counted."""
    keys = ("failure detected", "predictive failure", "ac lost", "input lost",
            "out-of-range", "config error", "power supply fault")
    n = 0
    for line in sdr_out.splitlines():
        cols = [c.strip().lower() for c in line.split("|")]
        if len(cols) < 5:
            continue
        if any(k in cols[4] for k in keys):
            n += 1
    return n


XID_RE = re.compile(r"NVRM: Xid \(PCI:([0-9a-fA-F:.]+)\):\s*(\d+)(?:,\s*(.*))?")


def parse_xid_line(line: str) -> Optional[Tuple[str, int, str]]:
    m = XID_RE.search(line)
    if not m:
        return None
    return m.group(1), int(m.group(2)), (m.group(3) or "").strip()


# ── XID monitor ──────────────────────────────────────────────────────────────

class XidMonitor:
    """Follows the kernel log via `journalctl -k -f` and queues NVIDIA XIDs.
    Restarts journalctl with backoff if it dies; reports itself unhealthy
    while down so the fail-closed policy can act on it."""

    def __init__(self, source: str = "journal"):
        self.source = source
        self._q: Deque[XidEvent] = deque(maxlen=10_000)
        self._lock = threading.Lock()
        self._healthy = source == "none"
        self._last_error = ""
        self._stop = threading.Event()
        self._proc: Optional[subprocess.Popen] = None
        self._thread: Optional[threading.Thread] = None
        self._pci_to_index: Dict[str, int] = {}

    def start(self):
        if self.source == "none":
            return
        self._thread = threading.Thread(target=self._run, daemon=True, name="xid-monitor")
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._proc and self._proc.poll() is None:
            self._proc.terminate()

    def set_gpu_map(self, gpus: List[GpuSnapshot]):
        with self._lock:
            self._pci_to_index = {normalize_pci(g.pci_bus_id): g.index for g in gpus if g.pci_bus_id}

    def health(self) -> Tuple[bool, str]:
        with self._lock:
            return self._healthy, self._last_error

    def drain(self) -> List[XidEvent]:
        with self._lock:
            evs = list(self._q)
            self._q.clear()
            return evs

    def _run(self):
        backoff = 1.0
        while not self._stop.is_set():
            try:
                self._proc = subprocess.Popen(
                    ["journalctl", "-k", "-f", "-n", "0", "-o", "cat", "--no-pager"],
                    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True,
                    errors="replace", start_new_session=True)
                with self._lock:
                    self._healthy, self._last_error = True, ""
                backoff = 1.0
                for line in self._proc.stdout:          # blocks until a line arrives
                    parsed = parse_xid_line(line)
                    if parsed:
                        pci, xid, msg = parsed
                        with self._lock:
                            idx = self._pci_to_index.get(normalize_pci(pci))
                            self._q.append(XidEvent(xid, pci, idx, msg[:300], time.time()))
                        log.error("XID %d on PCI %s (gpu %s): %s", xid, pci, idx, msg[:200])
                    if self._stop.is_set():
                        break
                rc = self._proc.wait(timeout=5)
                err = f"journalctl exited rc={rc}"
            except Exception as exc:                     # noqa: BLE001 - keep monitor alive
                err = f"journalctl failed: {exc}"
            if self._stop.is_set():
                return
            with self._lock:
                self._healthy, self._last_error = False, err
            log.warning("XID monitor down (%s); restarting in %.0fs", err, backoff)
            self._stop.wait(backoff)
            backoff = min(backoff * 2, 60.0)


# ── Collector ────────────────────────────────────────────────────────────────

_GPU_CORE = ["index", "uuid", "serial", "pci.bus_id", "temperature.gpu",
             "temperature.memory", "utilization.gpu", "power.draw"]
_GPU_HEALTH = ["ecc.errors.uncorrected.volatile.total", "remapped_rows.failure",
               "remapped_rows.pending"]


class TelemetryCollector:
    """
    Collects telemetry from all node subsystems. collect_once() is safe to call
    from the control loop: it returns within ~collect_timeout_s regardless of
    how badly any single source misbehaves.
    """

    def __init__(self, cfg, rack_id: str):
        self.cfg = cfg
        self.rack_id = rack_id
        self.node_id = getattr(cfg, "node_id", "")
        self._lock = threading.Lock()
        self._latest: Optional[TelemetrySnapshot] = None
        self._pool = ThreadPoolExecutor(max_workers=6, thread_name_prefix="telemetry")
        self._inflight: Dict[str, Future] = {}
        self._gpu_query: Optional[List[str]] = None
        self._warned_unknown_bits = False
        self.xid = XidMonitor(cfg.telemetry.xid_source)

    # -- lifecycle ------------------------------------------------------------

    def start_prometheus(self):
        start_http_server(self.cfg.telemetry.metrics_port)
        log.info("Prometheus metrics server on port %d", self.cfg.telemetry.metrics_port)

    def start(self):
        self.xid.start()

    def stop(self):
        self.xid.stop()
        self._pool.shutdown(wait=False, cancel_futures=True)

    @property
    def latest(self) -> Optional[TelemetrySnapshot]:
        with self._lock:
            return self._latest

    def required_sources(self) -> List[str]:
        req = list(self.cfg.telemetry.required_sources)
        if self.cfg.is_rack_leader and "coolant" not in req:
            req.append("coolant")
        if self.cfg.telemetry.xid_source != "none" and "xid" not in req:
            req.append("xid")
        return req

    # -- main entry -----------------------------------------------------------

    def collect_once(self) -> TelemetrySnapshot:
        snap = TelemetrySnapshot(node_id=self.node_id)
        timeout = float(self.cfg.telemetry.collect_timeout_s)

        jobs: Dict[str, Callable] = {
            "gpu": self._collect_gpu,
            "cpu": self._collect_cpu,
            "power": self._collect_power,
        }
        if self.cfg.is_rack_leader:
            jobs["coolant"] = self._collect_coolant

        futures: Dict[str, Future] = {}
        for name, fn in jobs.items():
            prev = self._inflight.get(name)
            if prev is not None and not prev.done():
                snap.source_errors[name] = "previous collection still running (hung tool?)"
                continue
            futures[name] = self._inflight[name] = self._pool.submit(fn)

        deadline = time.monotonic() + timeout + 5
        results: Dict[str, object] = {}
        for name, fut in futures.items():
            try:
                results[name] = fut.result(timeout=max(0.1, deadline - time.monotonic()))
            except Exception as exc:                         # noqa: BLE001
                snap.source_errors[name] = f"{type(exc).__name__}: {exc}"

        # GPU (+ NVLink counters, which depend on the GPU list)
        if "gpu" in results:
            gpus, err = results["gpu"]
            snap.gpus = gpus
            if err:
                snap.source_errors["gpu"] = err
            if gpus:
                nv_err = self._collect_nvlink_errors(snap.gpus)
                if nv_err:
                    snap.source_errors["nvlink"] = nv_err
                self.xid.set_gpu_map(gpus)
            else:
                snap.source_errors.setdefault("nvlink", "skipped: no GPUs enumerated")
        if "cpu" in results:
            snap.cpus, err = results["cpu"]
            if err:
                snap.source_errors["cpu"] = err
        if "power" in results:
            snap.power, err = results["power"]
            if err:
                snap.source_errors["power"] = err
        if "coolant" in results:
            snap.coolant, err = results["coolant"]
            if err:
                snap.source_errors["coolant"] = err

        ok, xerr = self.xid.health()
        if not ok:
            snap.source_errors["xid"] = xerr or "xid monitor not running"
        snap.xid_events = self.xid.drain()
        snap.abandoned_children = proc.abandoned_count()

        for name, err in snap.source_errors.items():
            TELEMETRY_ERRORS.labels(source=name).inc()
            log.warning("Telemetry source %s failed: %s", name, err)

        self._publish_prometheus(snap, list(jobs) + ["nvlink", "xid"])
        with self._lock:
            self._latest = snap
        return snap

    # -- GPU ------------------------------------------------------------------

    def _gpu_query_candidates(self) -> List[List[str]]:
        return [
            _GPU_CORE + ["clocks_event_reasons.active"] + _GPU_HEALTH,
            _GPU_CORE + ["clocks_throttle_reasons.active"] + _GPU_HEALTH,
            _GPU_CORE + ["clocks_event_reasons.active"],
            _GPU_CORE + ["clocks_throttle_reasons.active"],
        ]

    def _collect_gpu(self) -> Tuple[List[GpuSnapshot], str]:
        timeout = self.cfg.telemetry.collect_timeout_s
        candidates = [self._gpu_query] if self._gpu_query else self._gpu_query_candidates()
        last = None
        for q in candidates:
            res = proc.run_cmd(["nvidia-smi", f"--query-gpu={','.join(q)}",
                                "--format=csv,noheader,nounits"], timeout)
            last = res
            if res.ok:
                if self._gpu_query is None:
                    self._gpu_query = q
                    log.info("nvidia-smi GPU query fields: %s", ",".join(q))
                return self._parse_gpu_csv(res.stdout, q)
            if res.timed_out or res.error:
                break                     # hang / missing binary: don't try more variants
            if "not a valid field" not in (res.stdout + res.stderr).lower():
                break
        return [], last.describe() if last else "nvidia-smi not run"

    def _parse_gpu_csv(self, out: str, q: List[str]) -> Tuple[List[GpuSnapshot], str]:
        gpus: List[GpuSnapshot] = []
        problems: List[str] = []
        col = {name: i for i, name in enumerate(q)}
        for line in out.strip().splitlines():
            parts = [p.strip() for p in line.split(",")]
            if len(parts) != len(q):
                problems.append(f"malformed row: {line[:120]}")
                continue
            try:
                g = GpuSnapshot(index=int(parts[col["index"]]))
            except ValueError:
                problems.append(f"bad index: {line[:120]}")
                continue
            g.uuid = parts[col["uuid"]]
            g.serial = parts[col["serial"]] if parts[col["serial"]].lower() not in _NA else ""
            g.pci_bus_id = parts[col["pci.bus_id"]]
            g.junction_temp_c = _num(parts[col["temperature.gpu"]])
            g.hbm_temp_c = _num(parts[col["temperature.memory"]])
            g.sm_util_pct = _num(parts[col["utilization.gpu"]])
            g.power_w = _num(parts[col["power.draw"]])
            tcol = col.get("clocks_event_reasons.active", col.get("clocks_throttle_reasons.active"))
            g.throttle_reasons, unknown = decode_throttle(parts[tcol])
            if unknown and not self._warned_unknown_bits:
                log.warning("Unknown clock-event bits %s on GPU %d (not treated as abort)",
                            unknown, g.index)
                self._warned_unknown_bits = True
            if "ecc.errors.uncorrected.volatile.total" in col:
                v = _num(parts[col["ecc.errors.uncorrected.volatile.total"]])
                g.ecc_dbe_volatile = int(v) if v is not None else None
                g.remap_failure = _yesno(parts[col["remapped_rows.failure"]])
                g.remap_pending = _yesno(parts[col["remapped_rows.pending"]])
            if g.junction_temp_c is None:
                problems.append(f"GPU {g.index} temperature unreadable")
            gpus.append(g)
        expected = self.cfg.topology.gpus_per_node
        if len(gpus) != expected:
            problems.append(f"{len(gpus)} GPUs visible, expected {expected}")
        return gpus, "; ".join(problems)

    def _collect_nvlink_errors(self, gpus: List[GpuSnapshot]) -> str:
        """One nvidia-smi call for all GPUs (was one call per GPU)."""
        res = proc.run_cmd(["nvidia-smi", "nvlink", "-e"], self.cfg.telemetry.collect_timeout_s)
        if not res.ok:
            for g in gpus:
                g.nvlink_crc_errors = g.nvlink_replay_errors = None
            return res.describe()
        parsed = parse_nvlink_errors(res.stdout)
        missing = []
        for g in gpus:
            c = parsed.get(g.index)
            if c is None or c["links"] == 0:
                g.nvlink_crc_errors = g.nvlink_replay_errors = None
                missing.append(g.index)
            else:
                g.nvlink_crc_errors = c["crc"]
                g.nvlink_replay_errors = c["replay"]
        if missing:
            return f"no NVLink CRC counters parsed for GPUs {missing} (output format changed?)"
        return ""

    # -- CPU ------------------------------------------------------------------

    def _collect_cpu(self) -> Tuple[List[CpuSnapshot], str]:
        n_sock = self.cfg.topology.grace_sockets_per_node
        rx = re.compile(self.cfg.telemetry.cpu_thermal_zone_regex)
        zones = []
        for zone in Path("/sys/class/thermal").glob("thermal_zone*"):
            try:
                ztype = (zone / "type").read_text().strip()
                if rx.search(ztype):
                    temp_c = int((zone / "temp").read_text().strip()) / 1000.0
                    zones.append((int(zone.name.replace("thermal_zone", "")), temp_c))
            except (OSError, ValueError):
                continue
        zones.sort()
        cpus = [CpuSnapshot(socket=s, temp_c=None) for s in range(n_sock)]
        err = ""
        if not zones:
            err = f"no thermal zone matched {self.cfg.telemetry.cpu_thermal_zone_regex!r}"
        else:
            # Contiguous blocks of zones per socket (sorted by zone number).
            for i, (_, t) in enumerate(zones):
                s = min(i * n_sock // len(zones), n_sock - 1)
                cur = cpus[s].temp_c
                cpus[s].temp_c = t if cur is None else max(cur, t)
            if len(zones) < n_sock:
                err = f"only {len(zones)} CPU thermal zones for {n_sock} sockets"
        freqs = self._read_cpu_freq()
        for i, pkg in enumerate(sorted(freqs)[:n_sock]):
            cpus[i].freq_mhz = freqs[pkg]
        return cpus, err

    @staticmethod
    def _read_cpu_freq() -> Dict[int, float]:
        socket_freqs: Dict[int, List[float]] = {}
        for cpu_dir in Path("/sys/devices/system/cpu").glob("cpu[0-9]*"):
            try:
                pkg = int((cpu_dir / "topology" / "physical_package_id").read_text())
                khz = int((cpu_dir / "cpufreq" / "scaling_cur_freq").read_text())
                socket_freqs.setdefault(pkg, []).append(khz / 1000.0)
            except (OSError, ValueError):
                continue
        return {s: sum(v) / len(v) for s, v in socket_freqs.items() if v}

    # -- Coolant (rack leader only) -------------------------------------------

    def _collect_coolant(self) -> Tuple[CoolantSnapshot, str]:
        url = self.cfg.telemetry.coolant_api_url
        if url:
            snap = CoolantSnapshot(source="cdu_api")
            try:
                r = requests.get(
                    f"{url}/api/v1/rack/{self.rack_id}/coolant",
                    headers={"Authorization": f"Bearer {self.cfg.telemetry.coolant_api_token}"},
                    timeout=min(10, self.cfg.telemetry.collect_timeout_s))
                r.raise_for_status()
                data = r.json()
                missing = [k for k in ("inlet_temp_c", "outlet_temp_c") if data.get(k) is None]
                snap.inlet_temp_c = _opt_float(data.get("inlet_temp_c"))
                snap.outlet_temp_c = _opt_float(data.get("outlet_temp_c"))
                snap.flow_lpm = _opt_float(data.get("flow_lpm"))
                return snap, (f"CDU response missing {missing}" if missing else "")
            except (requests.RequestException, ValueError) as exc:
                if not self.cfg.telemetry.coolant_from_ipmi:
                    return snap, f"CDU API: {exc}"
                log.warning("CDU API failed (%s); trying BMC sensors", exc)
        if self.cfg.telemetry.coolant_from_ipmi:
            return self._collect_coolant_from_bmc()
        return CoolantSnapshot(), "no coolant source configured on rack leader"

    def _collect_coolant_from_bmc(self) -> Tuple[CoolantSnapshot, str]:
        snap = CoolantSnapshot(source="ipmi")
        res = proc.run_cmd(["ipmitool", "sdr", "type", "Temperature"],
                           self.cfg.telemetry.collect_timeout_s)
        if not res.ok:
            return snap, res.describe()
        for line in res.stdout.splitlines():
            cols = [c.strip() for c in line.split("|")]
            if len(cols) < 5:
                continue
            m = re.match(r"(-?[\d.]+)", cols[4])
            if not m:
                continue
            name = cols[0].lower()
            if "coolant in" in name or "liquid in" in name:
                snap.inlet_temp_c = float(m.group(1))
            elif "coolant out" in name or "liquid out" in name:
                snap.outlet_temp_c = float(m.group(1))
        if snap.inlet_temp_c is None or snap.outlet_temp_c is None:
            return snap, "BMC coolant sensors not found"
        return snap, ""

    # -- Power (tray BMC, in-band) --------------------------------------------

    def _collect_power(self) -> Tuple[PowerSnapshot, str]:
        snap = PowerSnapshot(psu_fault_count=None)
        t = self.cfg.telemetry.collect_timeout_s
        errs = []
        r1 = proc.run_cmd(["ipmitool", "dcmi", "power", "reading"], t)
        if r1.ok:
            for line in r1.stdout.splitlines():
                if "instantaneous" in line.lower():
                    m = re.search(r":\s*([\d.]+)\s*watts", line, re.IGNORECASE)
                    if m:
                        snap.rack_total_kw = float(m.group(1)) / 1000.0
            if snap.rack_total_kw is None:
                errs.append("DCMI reading not parsed")
        else:
            errs.append(r1.describe())
        r2 = proc.run_cmd(["ipmitool", "sdr", "type", "Power Supply"], t)
        if r2.ok:
            snap.psu_fault_count = count_psu_faults(r2.stdout)
        else:
            errs.append(r2.describe())
        return snap, "; ".join(errs)

    # -- Prometheus export ----------------------------------------------------

    def _publish_prometheus(self, snap: TelemetrySnapshot, sources: List[str]):
        GPU_THROTTLE.clear()            # otherwise a reason stays at 1 forever
        GPU_VISIBLE.set(len(snap.gpus))
        for g in snap.gpus:
            idx = str(g.index)
            _set(GPU_JUNCTION_TEMP.labels(gpu_index=idx), g.junction_temp_c)
            _set(GPU_HBM_TEMP.labels(gpu_index=idx), g.hbm_temp_c)
            _set(GPU_SM_UTIL.labels(gpu_index=idx), g.sm_util_pct)
            _set(GPU_POWER_W.labels(gpu_index=idx), g.power_w)
            _set(GPU_NVLINK_CRC.labels(gpu_index=idx), g.nvlink_crc_errors)
            _set(GPU_NVLINK_REPLAY.labels(gpu_index=idx), g.nvlink_replay_errors)
            _set(GPU_ECC_DBE.labels(gpu_index=idx), g.ecc_dbe_volatile)
            for reason in g.throttle_reasons:
                GPU_THROTTLE.labels(gpu_index=idx, reason=reason).set(1)
        for c in snap.cpus:
            _set(CPU_TEMP_C.labels(socket=str(c.socket)), c.temp_c)
            _set(CPU_FREQ_MHZ.labels(socket=str(c.socket)), c.freq_mhz)
        _set(COOLANT_INLET_C, snap.coolant.inlet_temp_c)
        _set(COOLANT_OUTLET_C, snap.coolant.outlet_temp_c)
        _set(COOLANT_FLOW_LPM, snap.coolant.flow_lpm)
        _set(TRAY_POWER_KW, snap.power.rack_total_kw)
        _set(PSU_FAULT_COUNT, snap.power.psu_fault_count)
        for ev in snap.xid_events:
            XID_EVENTS.labels(xid=str(ev.xid), gpu_index=str(ev.gpu_index)).inc()
        ABANDONED_CHILDREN.set(snap.abandoned_children)
        now = time.time()
        for s in set(sources):
            ok = s not in snap.source_errors
            SOURCE_OK.labels(source=s).set(1 if ok else 0)
            if ok:
                SOURCE_LAST_OK_TS.labels(source=s).set(now)


def _set(gauge, value):
    """Unknown values are exported as NaN, not 0, so dashboards and alerts
    can't mistake a dead sensor for a cold one."""
    gauge.set(float("nan") if value is None else value)


def _opt_float(v) -> Optional[float]:
    try:
        return None if v is None else float(v)
    except (TypeError, ValueError):
        return None
