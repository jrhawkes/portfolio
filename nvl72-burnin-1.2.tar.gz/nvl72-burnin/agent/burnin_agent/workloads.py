"""
burnin_agent/workloads.py
Lifecycle of the Phase 4 burn-in workloads on one compute tray:

  long-running (must stay alive until the burn deadline):
    gpu_burn      GPU tensor-core stress + checksum verification
    stress_ng     Grace CPU matrix/cache stress with --verify
    hpcg          optional, memory-bound CPU load
  periodic (sampled on an interval by the watchdog thread):
    stream        STREAM Triad per CPU NUMA node (records degradation over time)
    dcgm_health   `dcgmi health -c` background health check

Failure model (1.2):
  * ANY long-running workload exiting before its deadline is a failure,
    including gpu_burn (1.1 excluded gpu_burn, so a GPU crash was a PASS).
  * gpu_burn output not advancing for workload_stall_s is a hang.
  * Launch failures are failures, not "error_count = 1".
  * Parsers read the tool's actual output format and are unit-tested.
  * Termination signals every process group first, then waits once, bounded;
    unkillable children are abandoned instead of blocking shutdown.
"""

from __future__ import annotations

import dataclasses
import logging
import os
import re
import signal
import statistics
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from . import proc

log = logging.getLogger(__name__)

SIGTERM_TIMEOUT_S = 30
LONG_RUNNING = ("gpu_burn", "stress_ng", "hpcg")
# A long-running workload that exits cleanly within this window before the
# deadline is treated as having completed (its own timer vs ours).
DEADLINE_SLACK_S = 600


# ── Output parsers (pure; unit-tested) ───────────────────────────────────────

@dataclass
class GpuBurnResult:
    per_gpu_errors: List[int] = field(default_factory=list)
    per_gpu_gflops: List[float] = field(default_factory=list)
    faulty_gpus: List[int] = field(default_factory=list)
    died: bool = False
    progress_lines: int = 0
    steady_gflops: float = 0.0          # median aggregate over recent samples

    @property
    def total_errors(self) -> int:
        return sum(self.per_gpu_errors)


def parse_gpu_burn(text: str, window: int = 10) -> GpuBurnResult:
    """
    gpu_burn progress lines (carriage-return separated) look like
      '42.0%  proc'd: 1234 (56789 Gflop/s) - 1230 (56701 Gflop/s)   errors: 0 - 0   temps: 55 C - 56 C'
    and the run ends with 'GPU 0: OK' / 'GPU 1: FAULTY'. A worker that dies
    shows '(DIED!)' in the errors column.
    1.1 summed every Gflop/s figure in the whole log, so the "baseline" grew
    with run length and the degradation check was meaningless.
    """
    r = GpuBurnResult()
    samples: List[float] = []
    last_prog = None
    for line in re.split(r"[\r\n]+", text):
        if "proc'd" in line and "errors" in line:
            r.progress_lines += 1
            last_prog = line
            g = [float(x) for x in re.findall(r"\(([\d.]+)\s*Gflop/s\)", line, re.IGNORECASE)]
            if g:
                samples.append(sum(g))
        m = re.search(r"GPU\s+(\d+):\s*(OK|FAULTY)", line)
        if m and m.group(2) == "FAULTY":
            r.faulty_gpus.append(int(m.group(1)))
        if "DIED" in line:
            r.died = True
    if last_prog:
        r.per_gpu_gflops = [float(x) for x in re.findall(r"\(([\d.]+)\s*Gflop/s\)",
                                                          last_prog, re.IGNORECASE)]
        seg = re.search(r"errors:\s*(.*?)(?:temps:|$)", last_prog, re.IGNORECASE)
        if seg:
            r.per_gpu_errors = [int(x) for x in re.findall(r"(\d+)", seg.group(1))]
    if samples:
        r.steady_gflops = statistics.median(samples[-window:])
    return r


def parse_stressng(text: str, rc: Optional[int] = None) -> int:
    """
    Error count from stress-ng output + exit code.
      'stress-ng: fail:  [pid] ...'   one line per failure
      'stress-ng: info:  [pid] failed: 2: cpu (2)'   summary (newer versions)
    Exit code 2 = one or more stressors failed.
    1.1 used r'\\bfail\\b.*?(\\d+)', which matched the PID in 'fail: [1234]'
    (reporting thousands of errors) and never matched 'failed: N'.
    """
    fail_lines = len(re.findall(r"stress-ng:\s*fail:", text))
    summary = [int(x) for x in re.findall(r"\bfailed:\s*(\d+)", text)]
    errors = max([fail_lines] + summary)
    if rc == 2 and errors == 0:
        errors = 1
    return errors


def parse_stream_triad(output: str) -> float:
    """Triad best rate in GB/s (STREAM reports MB/s)."""
    for line in output.splitlines():
        m = re.match(r"\s*Triad:\s*([\d.]+)", line)
        if m:
            return float(m.group(1)) / 1000.0
    return 0.0


def parse_dcgm_health(text: str) -> Tuple[str, str]:
    """Return (overall, detail) from `dcgmi health -c` text output.
    overall in {'healthy','warning','failure','unknown'}."""
    low = text.lower()
    m = re.search(r"overall health\s*[|:]?\s*(healthy|warning|failure)", low)
    if m:
        return m.group(1), ""
    if "failure" in low:
        return "failure", text.strip()[:300]
    return "unknown", text.strip()[:300]


def cpu_numa_nodes() -> List[int]:
    """NUMA nodes that have CPUs. On Grace-Blackwell the GPU HBM is exposed as
    CPU-less NUMA nodes; STREAM must not be bound to those."""
    nodes = []
    for d in sorted(Path("/sys/devices/system/node").glob("node[0-9]*")):
        try:
            if (d / "cpulist").read_text().strip():
                nodes.append(int(d.name[4:]))
        except (OSError, ValueError):
            continue
    return nodes


def cpus_in_node(node: int) -> int:
    try:
        spec = Path(f"/sys/devices/system/node/node{node}/cpulist").read_text().strip()
    except OSError:
        return 0
    n = 0
    for part in spec.split(","):
        if "-" in part:
            a, b = part.split("-")
            n += int(b) - int(a) + 1
        elif part:
            n += 1
    return n


def stream_cmd(cfg, node: int) -> Tuple[List[str], Dict[str, str]]:
    env = dict(os.environ)
    ncpu = cpus_in_node(node)
    if ncpu:
        env["OMP_NUM_THREADS"] = str(ncpu)
    env.setdefault("OMP_PROC_BIND", "spread")
    env.setdefault("OMP_PLACES", "cores")
    return (["numactl", f"--cpunodebind={node}", f"--membind={node}",
             cfg.workload.stream_binary], env)


# ── Manager ──────────────────────────────────────────────────────────────────

@dataclass
class WorkloadStatus:
    name: str
    pid: Optional[int] = None
    running: bool = False
    returncode: Optional[int] = None
    error_count: int = 0
    last_throughput: float = 0.0        # Gflop/s for gpu_burn; GB/s for STREAM
    start_time: float = 0.0
    log_path: str = ""
    last_progress_ts: float = 0.0
    last_log_size: int = 0
    failure: str = ""                   # non-empty => workload failed


class WorkloadManager:
    """Thread-safe: public methods take self._lock; status objects are
    replaced, never mutated in place outside the lock."""

    def __init__(self, cfg, log_dir: Path):
        self.cfg = cfg
        self.log_dir = log_dir
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._procs: Dict[str, subprocess.Popen] = {}
        self._status: Dict[str, WorkloadStatus] = {}
        self._stop = threading.Event()
        self._watchdog_thread: Optional[threading.Thread] = None
        self._deadline_ts: float = 0.0
        self.stream_samples: Dict[int, List[Tuple[float, float]]] = {}
        self._dcgm_tool_failures = 0

    # ── Public API ─────────────────────────────────────────────────────────

    def launch_all(self, deadline_ts: float):
        """Launch Phase 4 workloads. deadline_ts is the planned burn end."""
        self._deadline_ts = deadline_ts
        self._stop.clear()
        duration = max(1, int(deadline_ts - time.time()))
        w = self.cfg.workload
        self._launch("gpu_burn", [w.gpu_burn_path, "-tc", "-m", f"{w.gpu_burn_mem_pct}%",
                                  str(duration)], self.log_dir / "burnin_gpu.log")
        self._launch("stress_ng", [w.stress_ng_binary, "--cpu", "0", "--cpu-method", "matrixprod",
                                   "--cache", "0", "--verify", "--timeout", f"{duration}s",
                                   "--metrics-brief"], self.log_dir / "stressng_cpu.log")
        if w.enable_hpcg:
            np_ = self.cfg.topology.grace_sockets_per_node
            self._launch("hpcg", ["mpirun", "-np", str(np_), "--bind-to", "socket",
                                  w.hpcg_binary, f"--nx={w.hpcg_nx}", f"--ny={w.hpcg_ny}",
                                  f"--nz={w.hpcg_nz}", f"--rt={duration}"],
                         self.log_dir / "hpcg.log")
        self._dcgm_health_setup()
        self._watchdog_thread = threading.Thread(target=self._watchdog_loop, daemon=True,
                                                 name="workload-watchdog")
        self._watchdog_thread.start()
        log.info("Burn-in workloads launched; deadline in %ds", duration)

    def check(self) -> List[Dict[str, str]]:
        """Cheap liveness check for the control loop. Returns failures as
        [{'workload':..., 'reason':...}]; empty list = all healthy."""
        now = time.time()
        with self._lock:
            procs = dict(self._procs)
            status = dict(self._status)
        failures = []
        for name, st in status.items():
            p = procs.get(name)
            if p is not None and st.running:
                rc = p.poll()
                if rc is not None:
                    early = now < self._deadline_ts - DEADLINE_SLACK_S
                    failure = ""
                    if rc != 0 or early:
                        failure = (f"exited rc={rc} "
                                   f"{int(self._deadline_ts - now)}s before deadline"
                                   if early else f"exited rc={rc}")
                    log.log(logging.ERROR if failure else logging.INFO,
                            "Workload %s exited rc=%s%s", name, rc,
                            f" ({failure})" if failure else "")
                    with self._lock:
                        cur = self._status[name]
                        st = dataclasses.replace(cur, running=False, returncode=rc,
                                                 failure=cur.failure or failure)
                        self._status[name] = st
            if st.failure:
                failures.append({"workload": name, "reason": st.failure})
        return failures

    def terminate_all(self):
        """Stop every workload: SIGTERM all groups, one bounded wait, SIGKILL
        stragglers, abandon anything unkillable. Worst case ~SIGTERM_TIMEOUT_S+5s
        total (1.1 waited 30s per process sequentially)."""
        self._stop.set()
        with self._lock:
            procs = {n: p for n, p in self._procs.items() if p.poll() is None}
        if not procs:
            return
        log.info("Terminating workloads: %s", sorted(procs))
        for p in procs.values():
            _signal_group(p, signal.SIGTERM)
        deadline = time.monotonic() + SIGTERM_TIMEOUT_S
        for name, p in procs.items():
            try:
                p.wait(timeout=max(0.1, deadline - time.monotonic()))
            except subprocess.TimeoutExpired:
                log.warning("%s ignored SIGTERM; sending SIGKILL", name)
                _signal_group(p, signal.SIGKILL)
                try:
                    p.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    log.error("%s (pid %d) unkillable; abandoning (device hang?)", name, p.pid)
        with self._lock:
            for name, p in procs.items():
                st = self._status.get(name)
                if st:
                    self._status[name] = dataclasses.replace(st, running=False,
                                                             returncode=p.poll())
        if self._watchdog_thread:
            self._watchdog_thread.join(timeout=10)

    def get_status(self, name: str) -> Optional[WorkloadStatus]:
        with self._lock:
            return self._status.get(name)

    def statuses(self) -> Dict[str, Dict]:
        with self._lock:
            return {n: dataclasses.asdict(s) for n, s in self._status.items()}

    def gpu_burn_errors(self) -> int:
        st = self.get_status("gpu_burn")
        return st.error_count if st else 0

    def stressng_errors(self) -> int:
        st = self.get_status("stress_ng")
        return st.error_count if st else 0

    def all_error_counts(self) -> Dict[str, int]:
        with self._lock:
            return {n: s.error_count for n, s in self._status.items()}

    def is_gpu_burn_complete(self) -> bool:
        st = self.get_status("gpu_burn")
        return bool(st) and not st.running and st.returncode == 0 and not st.failure

    # ── Launch ─────────────────────────────────────────────────────────────

    def _launch(self, name: str, cmd: List[str], log_path: Path):
        now = time.time()
        try:
            with open(log_path, "ab") as fh:          # parent closes its copy
                p = subprocess.Popen(cmd, stdout=fh, stderr=subprocess.STDOUT,
                                     start_new_session=True)
            st = WorkloadStatus(name=name, pid=p.pid, running=True, start_time=now,
                                log_path=str(log_path), last_progress_ts=now)
            with self._lock:
                self._procs[name] = p
                self._status[name] = st
            log.info("Launched %s (pid=%d) -> %s", name, p.pid, log_path)
        except OSError as exc:
            log.error("Failed to launch %s: %s", name, exc)
            with self._lock:
                self._status[name] = WorkloadStatus(name=name, log_path=str(log_path),
                                                    failure=f"launch failed: {exc}")

    # ── Watchdog (log parsing, stall detection, periodic samples) ──────────

    def _watchdog_loop(self):
        next_stream = time.time() + 300          # let clocks/thermals settle first
        next_health = time.time() + 60
        while not self._stop.wait(30):
            try:
                self._parse_logs()
                now = time.time()
                if now >= next_health:
                    self._dcgm_health_check()
                    next_health = now + 300
                if now >= next_stream:
                    self._stream_sample()
                    next_stream = time.time() + self.cfg.workload.stream_interval_s
            except Exception:                    # noqa: BLE001 - watchdog must survive
                log.exception("Workload watchdog iteration failed")

    def _parse_logs(self):
        """Parse long-running workload logs. Results are merged into the
        *current* status under the lock so a concurrent check() update
        (running/returncode) is never overwritten."""
        stall_s = self.cfg.abort.workload_stall_s
        now = time.time()
        with self._lock:
            items = [(n, s.log_path, s.last_log_size, s.last_progress_ts, s.running,
                      s.returncode) for n, s in self._status.items()]
        for name, log_path, last_size, last_prog, running, rc in items:
            if not log_path or name not in LONG_RUNNING:
                continue
            path = Path(log_path)
            try:
                size = path.stat().st_size
            except OSError:
                continue
            if size != last_size:
                last_size, last_prog = size, now
            text = _tail(path)
            errors, throughput, failure = 0, None, ""
            if name == "gpu_burn":
                r = parse_gpu_burn(text)
                errors = max(r.total_errors, len(r.faulty_gpus))
                throughput = r.steady_gflops or None
                if r.died:
                    failure = "gpu_burn worker DIED (GPU fault or CUDA error)"
                elif stall_s and running and now - last_prog > stall_s:
                    failure = (f"no gpu_burn progress for {int(now - last_prog)}s "
                               f"(GPU/driver hang suspected)")
            elif name == "stress_ng":
                errors = parse_stressng(text, rc)
            elif name == "hpcg" and re.search(r"\bINVALID\b", text):
                errors, failure = 1, "HPCG result INVALID"
            with self._lock:
                cur = self._status.get(name)
                if cur is None:
                    continue
                upd = dataclasses.replace(cur, last_log_size=last_size,
                                          last_progress_ts=last_prog,
                                          error_count=max(cur.error_count, errors))
                if throughput:
                    upd.last_throughput = throughput
                if failure and not upd.failure:
                    upd.failure = failure
                self._status[name] = upd

    def _stream_sample(self):
        nodes = cpu_numa_nodes()
        for node in nodes:
            if self._stop.is_set():
                return
            cmd, env = stream_cmd(self.cfg, node)
            res = proc.run_cmd(cmd, self.cfg.workload.stream_timeout_s, env=env)
            name = f"stream_node_{node}"
            gbs = parse_stream_triad(res.stdout) if res.ok else 0.0
            self.stream_samples.setdefault(node, []).append((time.time(), gbs))
            with self._lock:
                st = self._status.get(name) or WorkloadStatus(name=name)
                st = dataclasses.replace(st, last_throughput=gbs)
                if not res.ok:
                    st.error_count += 1
                    log.warning("STREAM sample on node %d failed: %s", node, res.describe())
                self._status[name] = st

    def _dcgm_health_setup(self):
        grp = str(self.cfg.tools.dcgm_health_group)
        res = proc.run_cmd(["dcgmi", "health", "-g", grp, "-s", "a"], 60)
        if not res.ok:
            log.warning("Could not enable DCGM health watches: %s", res.describe())

    def _dcgm_health_check(self):
        grp = str(self.cfg.tools.dcgm_health_group)
        res = proc.run_cmd(["dcgmi", "health", "-g", grp, "-c"], 120)
        with self._lock:
            st = self._status.get("dcgm_health") or WorkloadStatus(name="dcgm_health")
            st = dataclasses.replace(st)
        if not res.ok and not res.stdout:
            self._dcgm_tool_failures += 1
            log.warning("dcgmi health check failed: %s", res.describe())
            if self._dcgm_tool_failures >= 3:
                st.failure = st.failure or f"DCGM health unavailable: {res.describe()}"
        else:
            self._dcgm_tool_failures = 0
            overall, detail = parse_dcgm_health(res.stdout)
            if overall == "failure":
                st.error_count += 1
                st.failure = st.failure or f"DCGM health FAILURE: {detail or res.stdout[-300:]}"
            elif overall == "warning":
                log.warning("DCGM health warning:\n%s", res.stdout[-800:])
        with self._lock:
            self._status["dcgm_health"] = st


def _tail(path: Path, nbytes: int = 65536) -> str:
    try:
        with open(path, "rb") as fh:
            fh.seek(0, 2)
            size = fh.tell()
            fh.seek(max(0, size - nbytes))
            return fh.read().decode("utf-8", errors="replace")
    except OSError:
        return ""


def _signal_group(p: subprocess.Popen, sig: int):
    try:
        os.killpg(os.getpgid(p.pid), sig)
    except (ProcessLookupError, PermissionError):
        pass
