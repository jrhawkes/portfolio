#!/usr/bin/env python3
"""
cli/bio.py  —  Burn-In Orchestrator CLI
========================================
Command-line interface for operators interacting with the Burn-In Orchestrator.
Wraps the BIO REST API with a clean UX, colour-coded output, and tabular views.

Usage:
    bio rack list [--facility dc1] [--state BURNING]
    bio rack show <rack-id>
    bio rack register --serial SN123 --facility dc1 --zone zone-A --bmc 10.0.1.5 --mgmt 10.0.2.5
    bio rack state <rack-id> <NEW_STATE> [--reason "..."]
    bio rack command <rack-id> abort|hold|proceed
    bio rack triage <rack-id> RE_RUN|REPAIR|QUARANTINE|WAIVE --reason "..."
    bio rack report <rack-id> [--pdf]
    bio fleet summary
    bio fleet power
    bio alerts active
    bio watch [--interval 10]

Environment:
    BIO_URL    — orchestrator base URL (default: http://localhost:8000)
    BIO_TOKEN  — operator Bearer token
"""

from __future__ import annotations

import json
import os
import sys
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import click
import httpx
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.text import Text
from rich import box

console = Console()

# ── Config from environment ────────────────────────────────────────────────────

def _base_url() -> str:
    return os.environ.get("BIO_URL", "http://localhost:8000").rstrip("/")

def _token() -> str:
    tok = os.environ.get("BIO_TOKEN", "")
    if not tok:
        console.print("[red]Error:[/] BIO_TOKEN environment variable not set.")
        sys.exit(1)
    return tok

def _headers() -> dict:
    return {"Authorization": f"Bearer {_token()}", "Content-Type": "application/json"}

def _client() -> httpx.Client:
    return httpx.Client(base_url=_base_url(), headers=_headers(), timeout=30)


# ── State colour mapping ───────────────────────────────────────────────────────

STATE_COLORS = {
    "REGISTERED":  "dim white",
    "INSPECTING":  "yellow",
    "ONBOARDING":  "cyan",
    "BOOTING":     "cyan",
    "BASELINE":    "blue",
    "BURNING":     "bright_green",
    "COOLING":     "green",
    "VALIDATING":  "blue",
    "REPORTING":   "blue",
    "PASSED":      "bold green",
    "FAILED":      "bold red",
    "ABORTED":     "bold red",
    "TRIAGE":      "bold yellow",
    "QUARANTINED": "bold magenta",
}

def _state_text(state: str) -> Text:
    color = STATE_COLORS.get(state, "white")
    return Text(state, style=color)


# ── Formatting helpers ─────────────────────────────────────────────────────────

def _ts(unix: Optional[float]) -> str:
    if not unix:
        return "—"
    return datetime.fromtimestamp(unix, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

def _elapsed(unix: Optional[float]) -> str:
    if not unix:
        return "—"
    secs = int(time.time() - unix)
    h, m = divmod(secs // 60, 60)
    d, h = divmod(h, 24)
    if d:
        return f"{d}d {h:02d}h {m:02d}m"
    if h:
        return f"{h}h {m:02d}m"
    return f"{m}m {secs%60:02d}s"


# ── API helpers ────────────────────────────────────────────────────────────────

def _get(path: str) -> Any:
    with _client() as c:
        r = c.get(path)
    if r.status_code == 404:
        console.print(f"[red]Not found:[/] {path}")
        sys.exit(1)
    r.raise_for_status()
    return r.json()

def _post(path: str, payload: dict) -> Any:
    with _client() as c:
        r = c.post(path, json=payload)
    if not r.is_success:
        console.print(f"[red]Error {r.status_code}:[/] {r.text}")
        sys.exit(1)
    return r.json()


# ── CLI root ───────────────────────────────────────────────────────────────────

@click.group()
def cli():
    """bio — NVL72 Burn-In Orchestrator CLI"""
    pass


# ══════════════════════════════════════════════════════════════════════════════
# rack commands
# ══════════════════════════════════════════════════════════════════════════════

@cli.group()
def rack():
    """Per-rack operations."""
    pass


@rack.command("list")
@click.option("--facility", "-f", default=None, help="Filter by facility code")
@click.option("--state",    "-s", default=None, help="Filter by state (e.g. BURNING)")
@click.option("--json",     "as_json", is_flag=True, help="Output raw JSON")
def rack_list(facility, state, as_json):
    """List all registered racks."""
    params = []
    if facility:
        params.append(f"facility={facility}")
    if state:
        params.append(f"state={state}")
    qs = "?" + "&".join(params) if params else ""
    data = _get(f"/racks{qs}")

    if as_json:
        console.print_json(json.dumps(data))
        return

    t = Table(
        box=box.SIMPLE_HEAD,
        show_header=True,
        header_style="bold cyan",
        border_style="dim",
    )
    t.add_column("Rack ID",     style="bold", min_width=12)
    t.add_column("Facility",    min_width=6)
    t.add_column("Zone",        min_width=8)
    t.add_column("State",       min_width=12)
    t.add_column("Time in State", min_width=12)
    t.add_column("Run #",       min_width=6, justify="right")
    t.add_column("Serial",      min_width=10)

    for r in sorted(data, key=lambda x: x.get("state", "")):
        t.add_row(
            r["rack_id"],
            r.get("facility", "—"),
            r.get("power_zone", "—"),
            _state_text(r.get("state", "?")),
            _elapsed(r.get("state_entered_at")),
            str(r.get("run_count", 0)),
            r.get("serial_number", "—"),
        )

    console.print(t)
    console.print(f"[dim]{len(data)} racks total[/]")


@rack.command("show")
@click.argument("rack_id")
@click.option("--json", "as_json", is_flag=True)
def rack_show(rack_id, as_json):
    """Show detailed status for a single rack."""
    r = _get(f"/racks/{rack_id}")

    if as_json:
        console.print_json(json.dumps(r))
        return

    state = r.get("state", "?")
    color = STATE_COLORS.get(state, "white")

    # Header panel
    console.print(Panel(
        f"[bold]{r['rack_id']}[/bold]   "
        f"[dim]Serial:[/dim] {r.get('serial_number','—')}   "
        f"[dim]Facility:[/dim] {r.get('facility','—')}   "
        f"[dim]Zone:[/dim] {r.get('power_zone','—')}",
        title=f"[{color}]{state}[/{color}]",
        border_style=color,
    ))

    # Timeline table
    timeline = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    timeline.add_column("Key", style="dim", min_width=20)
    timeline.add_column("Value")
    timeline.add_row("Registered",      _ts(r.get("registered_at")))
    timeline.add_row("State entered",   _ts(r.get("state_entered_at")))
    timeline.add_row("Time in state",   _elapsed(r.get("state_entered_at")))
    timeline.add_row("Run count",       str(r.get("run_count", 0)))
    timeline.add_row("BMC IP",          r.get("bmc_ip", "—"))
    timeline.add_row("Mgmt IP",         r.get("mgmt_ip", "—"))
    timeline.add_row("Agent version",   r.get("agent_version", "—"))
    console.print(timeline)

    # Phase results
    phases = r.get("phase_results", {})
    if phases:
        console.print("\n[bold cyan]Phase Results[/bold cyan]")
        pt = Table(box=box.SIMPLE_HEAD, header_style="bold")
        pt.add_column("Phase")
        pt.add_column("Result", min_width=8)
        pt.add_column("Timestamp")
        for phase, res in phases.items():
            passed = res.get("passed", False)
            result_text = Text("PASS" if passed else "FAIL",
                               style="green" if passed else "red")
            pt.add_row(phase, result_text, _ts(res.get("timestamp")))
        console.print(pt)

    # Checkpoints
    checkpoints = r.get("checkpoints", [])
    if checkpoints:
        console.print("\n[bold cyan]Thermal Checkpoints[/bold cyan]")
        ct = Table(box=box.SIMPLE_HEAD, header_style="bold")
        ct.add_column("Time")
        ct.add_column("GPU °C", justify="right")
        ct.add_column("CPU °C", justify="right")
        ct.add_column("CDU Out °C", justify="right")
        ct.add_column("Power kW", justify="right")
        ct.add_column("gpu_burn err", justify="right")
        for cp in checkpoints:
            ct.add_row(
                f"T+{cp.get('hours','?')}h",
                f"{cp.get('gpu_junction_max_c', 0):.1f}",
                f"{cp.get('cpu_temp_max_c', 0):.1f}",
                f"{cp.get('coolant_outlet_c', 0):.1f}",
                f"{cp.get('rack_power_kw', 0):.1f}",
                str(cp.get("gpu_burn_errors", 0)),
            )
        console.print(ct)

    # Abort events
    aborts = r.get("abort_events", [])
    if aborts:
        console.print("\n[bold red]Abort Events[/bold red]")
        for ab in aborts:
            console.print(f"  [{_ts(ab.get('timestamp'))}]")
            for ev in ab.get("events", []):
                console.print(f"    [red]•[/red] {ev.get('message', ev.get('condition', ''))}")

    # Notes
    if r.get("notes"):
        console.print(f"\n[bold]Notes:[/bold] {r['notes']}")


@rack.command("register")
@click.option("--rack-id",  required=True, help="Unique rack identifier")
@click.option("--serial",   required=True, help="Hardware serial number")
@click.option("--facility", required=True, help="Facility/datacenter code")
@click.option("--zone",     required=True, help="Power zone label")
@click.option("--bmc",      required=True, help="BMC IP address")
@click.option("--mgmt",     required=True, help="Management OS IP address")
def rack_register(rack_id, serial, facility, zone, bmc, mgmt):
    """Register a new rack in the orchestrator."""
    result = _post("/racks", {
        "rack_id": rack_id,
        "serial_number": serial,
        "facility": facility,
        "power_zone": zone,
        "bmc_ip": bmc,
        "mgmt_ip": mgmt,
    })
    console.print(f"[green]✓[/green] Registered rack [bold]{rack_id}[/bold] "
                  f"(facility={facility}, zone={zone})")
    console.print(f"  State: [yellow]{result.get('state')}[/yellow]")
    console.print(f"  Next step: submit physical inspection via Intake Portal "
                  f"or:  bio rack state {rack_id} ONBOARDING --reason 'Inspection passed'")


@rack.command("state")
@click.argument("rack_id")
@click.argument("new_state")
@click.option("--reason", "-r", default="", help="Reason for state change")
def rack_state(rack_id, new_state, reason):
    """Manually transition a rack to a new state."""
    result = _post(f"/racks/{rack_id}/state", {
        "state": new_state.upper(),
        "reason": reason or f"Manual transition by operator via bio CLI",
    })
    console.print(
        f"[green]✓[/green] {rack_id}: "
        f"[yellow]{result.get('previous_state')}[/yellow] → "
        f"[bold {STATE_COLORS.get(new_state.upper(), 'white')}]{new_state.upper()}[/]"
    )


@rack.command("command")
@click.argument("rack_id")
@click.argument("action", type=click.Choice(["abort", "hold", "proceed"]))
@click.option("--reason", "-r", default="")
def rack_command(rack_id, action, reason):
    """Send a real-time command to a rack agent."""
    _post(f"/racks/{rack_id}/commands", {
        "action": action,
        "reason": reason or f"Operator command via bio CLI",
        "timestamp": time.time(),
    })
    icon = {"abort": "🛑", "hold": "⏸", "proceed": "▶"}.get(action, "→")
    console.print(f"{icon} Command [bold]{action}[/bold] queued for {rack_id}")


@rack.command("triage")
@click.argument("rack_id")
@click.argument("disposition",
                type=click.Choice(["RE_RUN", "RE_RUN_AFTER_COOLDOWN",
                                   "REPAIR", "QUARANTINE", "WAIVE"]))
@click.option("--reason", "-r", required=True, help="Disposition reason (required)")
@click.option("--operator-id", default=None, help="Operator ID (defaults to $USER)")
def rack_triage(rack_id, disposition, reason, operator_id):
    """Submit a triage disposition for a FAILED or ABORTED rack."""
    op_id = operator_id or os.environ.get("USER", "operator")
    result = _post(f"/racks/{rack_id}/triage", {
        "rack_id": rack_id,
        "disposition": disposition,
        "reason": reason,
        "operator_id": op_id,
    })
    new_state = result.get("state", "?")
    console.print(
        f"[green]✓[/green] {rack_id}: disposition={disposition} → "
        f"[bold {STATE_COLORS.get(new_state, 'white')}]{new_state}[/]"
    )


@rack.command("report")
@click.argument("rack_id")
@click.option("--pdf", is_flag=True, help="Also trigger PDF generation")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON")
def rack_report(rack_id, pdf, as_json):
    """View the acceptance report for a completed rack."""
    data = _get(f"/reports/{rack_id}")

    if as_json:
        console.print_json(json.dumps(data))
        return

    overall = data.get("overall_result", "?")
    color = "green" if overall == "PASS" else "red"
    console.print(Panel(
        f"[bold]Rack:[/bold] {rack_id}  |  "
        f"[bold]Serial:[/bold] {data.get('serial_number', '—')}  |  "
        f"[bold]Run ID:[/bold] {data.get('run_id', '—')}  |  "
        f"[bold]Runs:[/bold] {data.get('run_count', 0)}",
        title=f"[bold {color}]OVERALL: {overall}[/bold {color}]",
        border_style=color,
    ))

    # Acceptance criteria table
    criteria = data.get("acceptance_criteria", [])
    if criteria:
        at = Table(box=box.SIMPLE_HEAD, header_style="bold cyan")
        at.add_column("Criterion")
        at.add_column("Required", justify="right", min_width=12)
        at.add_column("Measured", justify="right", min_width=12)
        at.add_column("Result", min_width=6)
        for row in criteria:
            passed = row.get("passed", False)
            result_style = "green" if passed else "bold red"
            at.add_row(
                row.get("criterion", ""),
                str(row.get("required", "—")),
                str(row.get("measured", "—")),
                Text("PASS" if passed else "FAIL", style=result_style),
            )
        console.print(at)

    if pdf:
        console.print("Generating PDF report...")
        result = _post(f"/reports/{rack_id}/generate-pdf", {})
        console.print(f"[green]✓[/green] PDF written: {result.get('pdf_path')}")
        console.print(f"  Download: bio rack report {rack_id} --download  "
                      f"or GET /reports/{rack_id}/download")


# ══════════════════════════════════════════════════════════════════════════════
# fleet commands
# ══════════════════════════════════════════════════════════════════════════════

@cli.group()
def fleet():
    """Fleet-wide views."""
    pass


@fleet.command("summary")
def fleet_summary():
    """Show fleet state distribution."""
    data = _get("/racks/fleet/summary")

    total = data.get("total", 0)
    by_state = data.get("by_state", {})

    console.print(f"\n[bold]Fleet Summary[/bold] — {total} racks registered\n")

    t = Table(box=box.SIMPLE, show_header=False, padding=(0, 3))
    t.add_column("State", min_width=14)
    t.add_column("Count", justify="right", min_width=6)
    t.add_column("Bar")

    max_count = max(by_state.values(), default=1)
    bar_width = 40

    for state in [
        "REGISTERED", "INSPECTING", "ONBOARDING", "BOOTING",
        "BASELINE", "BURNING", "COOLING", "VALIDATING", "REPORTING",
        "PASSED", "FAILED", "ABORTED", "TRIAGE", "QUARANTINED",
    ]:
        count = by_state.get(state, 0)
        if count == 0:
            continue
        bar_len = int(count / max_count * bar_width)
        color = STATE_COLORS.get(state, "white")
        bar = Text("█" * bar_len, style=color)
        t.add_row(
            Text(state, style=color),
            Text(str(count), style="bold"),
            bar,
        )

    console.print(t)


@fleet.command("power")
def fleet_power():
    """Show per-facility, per-zone power consumption summary."""
    racks = _get("/racks")
    # Group by facility + zone
    zones: Dict[str, Dict[str, int]] = {}
    for r in racks:
        fac = r.get("facility", "?")
        zone = r.get("power_zone", "?")
        state = r.get("state", "")
        key = f"{fac} / {zone}"
        if key not in zones:
            zones[key] = {"total": 0, "burning": 0}
        zones[key]["total"] += 1
        if state in ("BURNING", "VALIDATING", "BASELINE", "BOOTING"):
            zones[key]["burning"] += 1

    t = Table(box=box.SIMPLE_HEAD, header_style="bold cyan",
              title="Power Zone Utilization")
    t.add_column("Facility / Zone", min_width=20)
    t.add_column("Racks Registered", justify="right")
    t.add_column("Racks Active", justify="right")
    t.add_column("Est. Power Draw", justify="right")
    t.add_column("Est. Max Power", justify="right")

    for zone_key, counts in sorted(zones.items()):
        burning = counts["burning"]
        total = counts["total"]
        est_kw = burning * 200
        max_kw = total * 200
        utilization = f"{est_kw:,} kW"
        t.add_row(
            zone_key,
            str(total),
            str(burning),
            Text(utilization, style="yellow" if est_kw > max_kw * 0.8 else "green"),
            f"{max_kw:,} kW",
        )

    console.print(t)


# ══════════════════════════════════════════════════════════════════════════════
# alerts command
# ══════════════════════════════════════════════════════════════════════════════

@cli.group()
def alerts():
    """Alert management."""
    pass


@alerts.command("active")
def alerts_active():
    """Show racks currently in FAILED or ABORTED state needing attention."""
    racks = _get("/racks")
    attention = [r for r in racks
                 if r.get("state") in ("FAILED", "ABORTED", "TRIAGE", "QUARANTINED")]

    if not attention:
        console.print("[green]✓[/green] No racks require attention.")
        return

    t = Table(box=box.SIMPLE_HEAD, header_style="bold red",
              title=f"[bold red]{len(attention)} Racks Require Attention[/bold red]")
    t.add_column("Rack ID", style="bold")
    t.add_column("State")
    t.add_column("Time in State", justify="right")
    t.add_column("Run #", justify="right")
    t.add_column("Last Abort Condition")

    for r in attention:
        state = r.get("state", "?")
        aborts = r.get("abort_events", [])
        last_condition = "—"
        if aborts:
            events = aborts[-1].get("events", [])
            if events:
                last_condition = events[0].get("condition", "unknown")

        t.add_row(
            r["rack_id"],
            _state_text(state),
            _elapsed(r.get("state_entered_at")),
            str(r.get("run_count", 0)),
            last_condition,
        )

    console.print(t)
    console.print(
        "\n[dim]Triage a rack:[/dim]  "
        "bio rack triage <rack-id> RE_RUN --reason '...'"
    )


# ══════════════════════════════════════════════════════════════════════════════
# watch command — live auto-refreshing fleet view
# ══════════════════════════════════════════════════════════════════════════════

@cli.command("watch")
@click.option("--interval", "-i", default=15, help="Refresh interval in seconds")
def watch(interval):
    """Live-updating fleet overview. Press Ctrl+C to exit."""

    def _render() -> Table:
        try:
            racks = _get("/racks")
        except Exception as exc:
            t = Table()
            t.add_column("Error")
            t.add_row(f"[red]{exc}[/red]")
            return t

        t = Table(
            title=f"NVL72 Burn-In Fleet  [dim]— refreshes every {interval}s — "
                  f"{datetime.now().strftime('%H:%M:%S')}[/dim]",
            box=box.SIMPLE_HEAD,
            header_style="bold cyan",
            border_style="dim",
        )
        t.add_column("Rack ID",     style="bold", min_width=14)
        t.add_column("State",       min_width=12)
        t.add_column("In State",    min_width=10, justify="right")
        t.add_column("Facility",    min_width=6)
        t.add_column("Zone",        min_width=8)
        t.add_column("Run #",       min_width=5, justify="right")

        state_order = [
            "BURNING", "VALIDATING", "COOLING", "REPORTING",
            "BASELINE", "BOOTING", "ONBOARDING", "INSPECTING", "REGISTERED",
            "PASSED", "FAILED", "ABORTED", "TRIAGE", "QUARANTINED",
        ]
        sorted_racks = sorted(
            racks,
            key=lambda r: (state_order.index(r.get("state", "REGISTERED"))
                           if r.get("state") in state_order else 99,
                           r.get("rack_id", ""))
        )

        for r in sorted_racks:
            state = r.get("state", "?")
            t.add_row(
                r["rack_id"],
                _state_text(state),
                _elapsed(r.get("state_entered_at")),
                r.get("facility", "—"),
                r.get("power_zone", "—"),
                str(r.get("run_count", 0)),
            )

        return t

    with Live(console=console, refresh_per_second=0.1, screen=False) as live:
        try:
            while True:
                live.update(_render())
                time.sleep(interval)
        except KeyboardInterrupt:
            pass
    console.print("[dim]Watch stopped.[/dim]")


if __name__ == "__main__":
    cli()
