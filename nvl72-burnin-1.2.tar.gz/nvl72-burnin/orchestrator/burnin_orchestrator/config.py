"""orchestrator/burnin_orchestrator/config.py"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Dict

log = logging.getLogger(__name__)

_INSECURE = {"", "changeme-agent-token", "changeme-operator-token", "changeme"}


@dataclass
class OrchestratorConfig:
    redis_url: str = "redis://localhost:6379/0"
    victoriametrics_url: str = "http://victoriametrics:8428"
    vm_forward: bool = True               # forward /metrics/ingest pushes to VM
    agent_shared_token: str = ""
    operator_token: str = ""
    readonly_token: str = ""              # Grafana / dashboards (GET only)
    # Power zone capacity: max racks holding a power slot (BASELINE..VALIDATING)
    zone_capacity: Dict[str, int] = field(default_factory=dict)
    default_zone_capacity: int = 50
    start_interval_s: int = 300           # min spacing between admissions per zone
    burnin_duration_s: int = 259_200      # rack-wide burn window handed to nodes
    node_stale_s: int = 300               # heartbeat age that counts as node lost
    scheduler_tick_s: int = 30
    audit_maxlen: int = 2_000_000         # approximate cap on the audit stream
    alert_maxlen: int = 200_000
    event_dedupe_ttl_s: int = 14 * 86400
    max_reruns: int = 3
    s3_bucket: str = "s3://burnin-artifacts"
    report_dir: str = "/var/lib/burnin-orchestrator/reports"
    log_level: str = "INFO"


def _parse_zone_caps(spec: str) -> Dict[str, int]:
    caps: Dict[str, int] = {}
    for item in filter(None, (s.strip() for s in spec.split(","))):
        name, _, val = item.partition("=")
        caps[name.strip()] = int(val)
    return caps


def load_config() -> OrchestratorConfig:
    e = os.environ.get
    cfg = OrchestratorConfig()
    cfg.redis_url = e("REDIS_URL", cfg.redis_url)
    cfg.victoriametrics_url = e("VM_URL", cfg.victoriametrics_url)
    cfg.vm_forward = e("VM_FORWARD", "true").lower() in ("1", "true", "yes")
    cfg.agent_shared_token = e("AGENT_TOKEN", "")
    cfg.operator_token = e("OPERATOR_TOKEN", "")
    cfg.readonly_token = e("READONLY_TOKEN", "")
    cfg.default_zone_capacity = int(e("ZONE_CAPACITY", cfg.default_zone_capacity))
    cfg.zone_capacity = _parse_zone_caps(e("ZONE_CAPACITIES", ""))     # "zone-A=80,zone-B=40"
    cfg.start_interval_s = int(e("ZONE_START_INTERVAL_S", cfg.start_interval_s))
    cfg.burnin_duration_s = int(e("BURNIN_DURATION_S", cfg.burnin_duration_s))
    cfg.node_stale_s = int(e("NODE_STALE_S", cfg.node_stale_s))
    cfg.max_reruns = int(e("MAX_RERUNS", cfg.max_reruns))
    cfg.report_dir = e("REPORT_DIR", cfg.report_dir)
    cfg.log_level = e("LOG_LEVEL", "INFO")

    insecure_ok = e("ALLOW_INSECURE_TOKENS", "").lower() in ("1", "true", "yes")
    problems = []
    if any(t in _INSECURE or t.startswith("changeme") or len(t) < 16
           for t in (cfg.agent_shared_token, cfg.operator_token)):
        problems.append("AGENT_TOKEN / OPERATOR_TOKEN unset, default, or shorter than 16 chars")
    if cfg.agent_shared_token and cfg.agent_shared_token == cfg.operator_token:
        problems.append("AGENT_TOKEN must differ from OPERATOR_TOKEN (agents could waive racks)")
    if problems:
        if not insecure_ok:
            raise RuntimeError("; ".join(problems) + " (set ALLOW_INSECURE_TOKENS=1 for dev)")
        log.warning("INSECURE: %s", "; ".join(problems))
    return cfg
