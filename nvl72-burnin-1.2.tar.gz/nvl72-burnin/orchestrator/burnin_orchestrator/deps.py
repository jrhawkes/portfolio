"""Shared FastAPI dependencies: store/config access and role-based auth.

1.1 accepted either token for every endpoint, so any rack agent (whose token
sits on 18,000 tray filesystems) could WAIVE a failed rack to PASSED or
register/abort racks. Agents may now only call node endpoints."""
from __future__ import annotations

import hmac
from typing import Optional

from fastapi import Header, HTTPException, Request

from .redis_store import RedisStore


def get_store(request: Request) -> RedisStore:
    return request.app.state.store


def get_cfg(request: Request):
    return request.app.state.cfg


def _token(authorization: Optional[str]) -> str:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid Authorization header")
    return authorization.removeprefix("Bearer ").strip()


def _eq(a: str, b: str) -> bool:
    return bool(a) and bool(b) and hmac.compare_digest(a.encode(), b.encode())


async def require_operator(request: Request, authorization: Optional[str] = Header(None)) -> str:
    tok = _token(authorization)
    if not _eq(tok, get_cfg(request).operator_token):
        raise HTTPException(status_code=403, detail="Operator token required")
    return "operator"


async def require_agent(request: Request, authorization: Optional[str] = Header(None)) -> str:
    """Agents or operators (operators may drive node endpoints for testing)."""
    tok = _token(authorization)
    cfg = get_cfg(request)
    if _eq(tok, cfg.agent_shared_token):
        return "agent"
    if _eq(tok, cfg.operator_token):
        return "operator"
    raise HTTPException(status_code=403, detail="Invalid token")


async def require_reader(request: Request, authorization: Optional[str] = Header(None)) -> str:
    """GET endpoints: operator, agent, or the read-only token (Grafana)."""
    tok = _token(authorization)
    cfg = get_cfg(request)
    if _eq(tok, getattr(cfg, "readonly_token", "")):
        return "reader"
    return await require_agent(request, authorization)


verify_token = require_reader       # 1.1 name
