"""
orchestrator/burnin_orchestrator/models.py
Pydantic models, RackState enum and the rack state machine definition.

1.2 changes:
  * Explicit ALLOWED_TRANSITIONS. 1.1 accepted any state -> any state, so a
    replayed "BURNING" from an agent's offline buffer could resurrect an
    ABORTED rack.
  * POWER_SLOT_STATES replaces ACTIVE_STATES for zone capacity. 1.1 counted
    racks *waiting* in BASELINE against capacity, so a zone full of waiting
    racks could never admit any of them (deadlock), while racks that were
    actually at full power (agent self-promoted to BURNING) bypassed it.
  * A rack is 18 compute-tray nodes; NodeRecord holds per-node progress.
"""

from __future__ import annotations

import time
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class RackState(str, Enum):
    REGISTERED  = "REGISTERED"
    INSPECTING  = "INSPECTING"
    ONBOARDING  = "ONBOARDING"
    BOOTING     = "BOOTING"
    BASELINE    = "BASELINE"
    BURNING     = "BURNING"
    COOLING     = "COOLING"
    VALIDATING  = "VALIDATING"
    REPORTING   = "REPORTING"
    PASSED      = "PASSED"
    FAILED      = "FAILED"
    ABORTED     = "ABORTED"
    TRIAGE      = "TRIAGE"
    QUARANTINED = "QUARANTINED"


S = RackState

# Racks in these states hold a power-zone slot (full-power work may be running).
POWER_SLOT_STATES = {S.BASELINE, S.BURNING, S.COOLING, S.VALIDATING}
ACTIVE_STATES = POWER_SLOT_STATES          # 1.1 name

# States in which node agents are expected to heartbeat.
AGENT_DRIVEN_STATES = {S.BOOTING, S.BASELINE, S.BURNING, S.COOLING, S.VALIDATING}

HUMAN_REQUIRED_STATES = {S.INSPECTING, S.PASSED, S.FAILED, S.ABORTED, S.TRIAGE, S.QUARANTINED}
TERMINAL_FAILURE_STATES = {S.FAILED, S.ABORTED, S.TRIAGE, S.QUARANTINED}

_FAIL = {S.FAILED, S.ABORTED}
ALLOWED_TRANSITIONS: Dict[RackState, set] = {
    S.REGISTERED:  {S.INSPECTING, S.QUARANTINED},
    S.INSPECTING:  {S.ONBOARDING, S.QUARANTINED, S.TRIAGE},
    S.ONBOARDING:  {S.BOOTING} | _FAIL,
    S.BOOTING:     {S.BASELINE} | _FAIL,
    S.BASELINE:    {S.BURNING} | _FAIL,
    S.BURNING:     {S.COOLING, S.VALIDATING} | _FAIL,
    S.COOLING:     {S.VALIDATING} | _FAIL,
    S.VALIDATING:  {S.REPORTING} | _FAIL,
    S.REPORTING:   {S.PASSED, S.FAILED},
    S.PASSED:      {S.ONBOARDING},                       # operator re-qualification
    S.FAILED:      {S.TRIAGE, S.ONBOARDING, S.QUARANTINED, S.PASSED},
    S.ABORTED:     {S.TRIAGE, S.ONBOARDING, S.QUARANTINED, S.PASSED},
    S.TRIAGE:      {S.ONBOARDING, S.QUARANTINED, S.PASSED},
    S.QUARANTINED: {S.TRIAGE},
}

# State timeout configuration (seconds)
STATE_TIMEOUTS: Dict[RackState, int] = {
    S.INSPECTING:  4 * 3600,
    S.ONBOARDING:  60 * 60,      # agents must pick up the run and report
    S.BOOTING:     24 * 3600,    # includes queueing for power admission
    S.BASELINE:    10 * 3600,    # DCGM L3 (<=2h) + memtest (<=4h) + tests
    S.BURNING:     80 * 3600,
    S.COOLING:     2 * 3600,
    S.VALIDATING:  6 * 3600,
    S.REPORTING:   15 * 60,
    S.PASSED:      72 * 3600,    # sign-off SLA (alert only)
}

NODE_PHASES = ("boot_validation", "functional_validation", "burnin", "post_burnin")


class NodeRecord(BaseModel):
    node_id: str
    registered_at: float = Field(default_factory=time.time)
    state: str = ""                                  # last state the agent reported
    phases: Dict[str, Dict[str, Any]] = Field(default_factory=dict)  # phase -> {passed, ts, failures}
    aborted: bool = False
    last_event_seq: int = 0


class RackRecord(BaseModel):
    rack_id: str
    serial_number: str = ""
    facility: str = ""
    power_zone: str = ""
    state: RackState = RackState.REGISTERED
    previous_state: Optional[RackState] = None
    state_entered_at: float = Field(default_factory=time.time)
    state_reason: str = ""
    registered_at: float = Field(default_factory=time.time)
    run_id: str = ""
    run_count: int = 0
    agent_version: str = ""
    bmc_ip: str = ""
    mgmt_ip: str = ""
    node_count: int = 18
    expected_nodes: List[str] = Field(default_factory=list)   # optional allow-list
    nodes: Dict[str, NodeRecord] = Field(default_factory=dict)
    admission_ready: bool = False
    hold: bool = False
    burn_deadline_ts: float = 0.0
    phase_results: Dict[str, Any] = Field(default_factory=dict)   # rack-level summary
    checkpoints: List[Dict] = Field(default_factory=list)
    abort_events: List[Dict] = Field(default_factory=list)
    failed_components: List[Dict] = Field(default_factory=list)
    run_history: List[Dict] = Field(default_factory=list)         # summaries of prior runs
    commands_pending: List[Dict] = Field(default_factory=list)    # 1.1 compat (unused)
    notes: str = ""


class StateTransitionRequest(BaseModel):
    state: str
    reason: str = ""
    force: bool = False
    operator_id: str = "operator"
    timestamp: float = Field(default_factory=time.time)


class PhaseResultRequest(BaseModel):
    phase: str
    passed: bool
    metrics: Dict[str, Any]
    timestamp: float = Field(default_factory=time.time)


class AbortRequest(BaseModel):
    abort_events: List[Dict[str, Any]]
    telemetry_snapshot: Dict[str, Any] = Field(default_factory=dict)
    timestamp: float = Field(default_factory=time.time)


class CheckpointRequest(BaseModel):
    hours: int
    snapshot: Dict[str, Any]
    timestamp: float = Field(default_factory=time.time)


class NodeEvent(BaseModel):
    """Envelope sent by node agents (api_client outbox)."""
    event_id: str
    seq: int = 0
    type: str                        # state | phase_result | abort | checkpoint
    run_id: str
    timestamp: float = Field(default_factory=time.time)
    payload: Dict[str, Any] = Field(default_factory=dict)


class HeartbeatRequest(BaseModel):
    summary: Dict[str, Any] = Field(default_factory=dict)
    phase: str = ""
    run_id: str = ""
    timestamp: float = Field(default_factory=time.time)


class RackRegistrationRequest(BaseModel):
    rack_id: str
    serial_number: str
    facility: str
    power_zone: str
    bmc_ip: str = ""
    mgmt_ip: str = ""
    agent_version: str = ""
    node_count: int = 18
    expected_nodes: List[str] = Field(default_factory=list)


class TriageDispositionRequest(BaseModel):
    rack_id: str = ""
    disposition: str   # RE_RUN | RE_RUN_AFTER_COOLDOWN | REPAIR | QUARANTINE | WAIVE
    reason: str
    operator_id: str
