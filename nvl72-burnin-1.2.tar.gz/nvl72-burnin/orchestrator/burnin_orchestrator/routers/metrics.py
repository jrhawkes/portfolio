"""
orchestrator/burnin_orchestrator/routers/metrics.py
Legacy push ingest (agent 1.1 full snapshots) -> VictoriaMetrics.

Preferred path at scale: vmagent scrapes each node agent's :9101 directly;
this endpoint then isn't needed (set VM_FORWARD=false).

1.1 problems fixed: no authentication; a new httpx client (TCP+TLS setup)
per request; the agent's request waited on VictoriaMetrics (up to 5 s);
label values were not escaped. Now: auth required, one shared client, a
bounded queue drained in batches by a background task (drops oldest when VM
is down instead of back-pressuring agents).
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections import deque
from typing import Deque, List, Optional

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request

from ..deps import get_cfg, require_agent

log = logging.getLogger(__name__)
router = APIRouter()

MAX_QUEUE_LINES = 2_000_000
BATCH_LINES = 20_000


class VMForwarder:
    def __init__(self, url: str):
        self.url = url.rstrip("/")
        self.q: Deque[str] = deque(maxlen=MAX_QUEUE_LINES)
        self.dropped = 0
        self._client: Optional[httpx.AsyncClient] = None
        self._task: Optional[asyncio.Task] = None

    async def start(self):
        self._client = httpx.AsyncClient(timeout=10.0,
                                         limits=httpx.Limits(max_keepalive_connections=4))
        self._task = asyncio.create_task(self._run())

    async def stop(self):
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        if self._client:
            await self._client.aclose()

    def submit(self, lines: List[str]):
        if len(self.q) + len(lines) > MAX_QUEUE_LINES:
            self.dropped += len(lines)
        self.q.extend(lines)

    async def _run(self):
        backoff = 1.0
        while True:
            if not self.q:
                await asyncio.sleep(1.0)
                continue
            batch = [self.q.popleft() for _ in range(min(BATCH_LINES, len(self.q)))]
            try:
                r = await self._client.post(f"{self.url}/api/v1/import/prometheus",
                                            content="\n".join(batch))
                r.raise_for_status()
                backoff = 1.0
            except Exception as exc:                          # noqa: BLE001
                self.q.extendleft(reversed(batch))
                log.warning("VictoriaMetrics forward failed (%s); %d lines queued, %d dropped",
                            exc, len(self.q), self.dropped)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 60)


def _esc(v) -> str:
    return str(v).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")


def _num(v) -> Optional[float]:
    try:
        f = float(v)
        return None if f != f else f
    except (TypeError, ValueError):
        return None


@router.post("/ingest")
async def ingest_telemetry(payload: dict, request: Request, _=Depends(require_agent)):
    rack_id = payload.get("rack_id")
    snapshot = payload.get("snapshot") or {}
    if not rack_id or not isinstance(snapshot, dict):
        raise HTTPException(status_code=400, detail="rack_id and snapshot required")
    fwd: Optional[VMForwarder] = getattr(request.app.state, "vm_forwarder", None)
    if fwd is not None:
        fwd.submit(snapshot_to_prometheus_lines(rack_id, payload.get("node_id", ""), snapshot))
    return {"status": "ok", "rack_id": rack_id}


def snapshot_to_prometheus_lines(rack_id: str, node_id: str, snapshot: dict) -> list:
    lines = []
    ts_ms = int((_num(snapshot.get("timestamp")) or time.time()) * 1000)
    base = f'rack_id="{_esc(rack_id)}"' + (f',node_id="{_esc(node_id)}"' if node_id else "")

    def emit(name, labels, value):
        v = _num(value)
        if v is not None:                    # unknown stays absent, never 0
            lines.append(f"{name}{{{labels}}} {v} {ts_ms}")

    for gpu in snapshot.get("gpus", []) or []:
        gl = f'{base},gpu_index="{_esc(gpu.get("index", ""))}"'
        for k, m in (("junction_temp_c", "burnin_gpu_junction_temp_c"),
                     ("hbm_temp_c", "burnin_gpu_hbm_temp_c"),
                     ("sm_util_pct", "burnin_gpu_sm_util_pct"),
                     ("power_w", "burnin_gpu_power_w"),
                     ("nvlink_crc_errors", "burnin_gpu_nvlink_crc_errors"),
                     ("nvlink_replay_errors", "burnin_gpu_nvlink_replay_errors")):
            emit(m, gl, gpu.get(k))
    for cpu in snapshot.get("cpus", []) or []:
        cl = f'{base},socket="{_esc(cpu.get("socket", ""))}"'
        emit("burnin_cpu_temp_c", cl, cpu.get("temp_c"))
        emit("burnin_cpu_power_w", cl, cpu.get("power_w"))
    c = snapshot.get("coolant") or {}
    emit("burnin_coolant_inlet_temp_c", base, c.get("inlet_temp_c"))
    emit("burnin_coolant_outlet_temp_c", base, c.get("outlet_temp_c"))
    emit("burnin_coolant_flow_lpm", base, c.get("flow_lpm"))
    p = snapshot.get("power") or {}
    emit("burnin_rack_power_kw", base, p.get("rack_total_kw"))
    emit("burnin_psu_fault_count", base, p.get("psu_fault_count"))
    return lines


_snapshot_to_prometheus_lines = lambda rack_id, snapshot: snapshot_to_prometheus_lines(rack_id, "", snapshot)  # noqa: E731
