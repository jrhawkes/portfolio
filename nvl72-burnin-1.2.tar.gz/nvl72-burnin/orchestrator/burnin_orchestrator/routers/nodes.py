"""
orchestrator/burnin_orchestrator/routers/nodes.py
Endpoints used by node agents (one per compute tray).

  POST /racks/{rack}/nodes/{node}/events     durable, idempotent (event_id)
  POST /racks/{rack}/nodes/{node}/heartbeat  latest-value telemetry summary
  GET  /racks/{rack}/nodes/{node}/directive  what the node should do now

Status codes are part of the agent contract: 2xx = delivered (including
duplicates), 404/409/422 = permanent (agent dead-letters), 5xx = retry.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..deps import get_store, require_agent
from ..models import HeartbeatRequest, NodeEvent
from ..redis_store import RedisStore, StoreError

router = APIRouter()


@router.post("/{rack_id}/nodes/{node_id}/events")
async def node_event(rack_id: str, node_id: str, ev: NodeEvent,
                     store: RedisStore = Depends(get_store), _=Depends(require_agent)):
    try:
        return await store.apply_node_event(rack_id, node_id, ev)
    except StoreError as exc:
        raise HTTPException(status_code=exc.status, detail=str(exc))


@router.post("/{rack_id}/nodes/{node_id}/heartbeat")
async def heartbeat(rack_id: str, node_id: str, hb: HeartbeatRequest,
                    store: RedisStore = Depends(get_store), _=Depends(require_agent)):
    try:
        return await store.record_heartbeat(rack_id, node_id, hb)
    except StoreError as exc:
        raise HTTPException(status_code=exc.status, detail=str(exc))


@router.get("/{rack_id}/nodes/{node_id}/directive")
async def directive(rack_id: str, node_id: str, store: RedisStore = Depends(get_store),
                    _=Depends(require_agent)):
    try:
        return await store.get_directive(rack_id, node_id)
    except StoreError as exc:
        raise HTTPException(status_code=exc.status, detail=str(exc))
