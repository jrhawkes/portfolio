"""
orchestrator/burnin_orchestrator/routers/racks.py
Rack lifecycle API for operators and tools (CLI, intake portal, Grafana).
Node agents use routers/nodes.py.
"""

from __future__ import annotations

import logging
import time
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException

from ..deps import get_store, require_agent, require_operator, require_reader
from ..models import (AbortRequest, CheckpointRequest, PhaseResultRequest, RackRecord,
                      RackRegistrationRequest, RackState, StateTransitionRequest,
                      TriageDispositionRequest)
from ..redis_store import RedisStore, StoreError

log = logging.getLogger(__name__)
router = APIRouter()


def _http(exc: StoreError) -> HTTPException:
    return HTTPException(status_code=exc.status, detail=str(exc))


@router.post("", status_code=201, response_model=RackRecord)
async def register_rack(req: RackRegistrationRequest, store: RedisStore = Depends(get_store),
                        _=Depends(require_operator)):
    rack = RackRecord(rack_id=req.rack_id, serial_number=req.serial_number,
                      facility=req.facility, power_zone=req.power_zone, bmc_ip=req.bmc_ip,
                      mgmt_ip=req.mgmt_ip, agent_version=req.agent_version,
                      node_count=req.node_count, expected_nodes=req.expected_nodes,
                      state=RackState.INSPECTING, state_entered_at=time.time())
    try:
        return await store.create_rack(rack)
    except StoreError as exc:
        raise _http(exc)


@router.post("/{rack_id}/state", response_model=RackRecord)
async def update_state(rack_id: str, req: StateTransitionRequest,
                       store: RedisStore = Depends(get_store), _=Depends(require_operator)):
    """Operator state change. Validated against the transition table unless
    force=true (audited)."""
    try:
        return await store.transition_state(rack_id, req.state, req.reason,
                                            operator_id=req.operator_id, force=req.force)
    except StoreError as exc:
        raise _http(exc)


@router.post("/{rack_id}/phase-result", response_model=RackRecord)
async def record_phase_result(rack_id: str, req: PhaseResultRequest,
                              store: RedisStore = Depends(get_store), _=Depends(require_operator)):
    """Rack-level results from operator tools (e.g. physical_inspection)."""
    try:
        return await store.record_phase_result(rack_id, req.phase, req.passed, req.metrics)
    except StoreError as exc:
        raise _http(exc)


@router.post("/{rack_id}/abort", response_model=RackRecord)
async def record_abort(rack_id: str, req: AbortRequest, store: RedisStore = Depends(get_store),
                       _=Depends(require_operator)):
    try:
        return await store.record_abort(rack_id, req.abort_events, req.telemetry_snapshot)
    except StoreError as exc:
        raise _http(exc)


@router.post("/{rack_id}/checkpoint")
async def record_checkpoint(rack_id: str, req: CheckpointRequest):
    raise HTTPException(status_code=410,
                        detail="Use POST /racks/{rack}/nodes/{node}/events (agent 1.2)")


@router.post("/{rack_id}/commands")
async def send_command(rack_id: str, command: dict, store: RedisStore = Depends(get_store),
                       _=Depends(require_operator)):
    """abort | hold | proceed. Commands are state, not a queue: 1.1 popped the
    queue on GET, so a lost response lost an operator abort."""
    action = str(command.get("action", "")).lower()
    who = str(command.get("operator_id", "operator"))
    try:
        if action == "abort":
            rack = await store.record_abort(rack_id, [{
                "condition": "operator_abort", "message": command.get("reason", "operator abort"),
                "component": {"type": "operator", "operator_id": who}}], {}, actor=who)
        elif action in ("hold", "proceed"):
            rack = await store.set_hold(rack_id, action == "hold", who)
        else:
            raise HTTPException(status_code=400, detail="action must be abort|hold|proceed")
    except StoreError as exc:
        raise _http(exc)
    return {"rack_id": rack_id, "applied": action, "state": rack.state.value, "hold": rack.hold}


@router.get("/{rack_id}/commands")
async def get_commands(rack_id: str, store: RedisStore = Depends(get_store),
                       _=Depends(require_agent)):
    """1.1 agent compatibility: derived from the directive, never consumed."""
    try:
        d = await store.get_directive(rack_id, "legacy")
    except StoreError as exc:
        raise _http(exc)
    cmds = [{"action": d["command"]}] if d["command"] else []
    return {"rack_id": rack_id, "commands": cmds}


@router.get("", response_model=List[RackRecord])
async def list_racks(facility: Optional[str] = None, state: Optional[str] = None,
                     store: RedisStore = Depends(get_store), _=Depends(require_reader)):
    if state:
        racks = await store.get_racks_in_state(state.upper())
        return [r for r in racks if facility is None or r.facility == facility]
    return await store.list_racks(facility=facility)


@router.get("/fleet/summary")
async def fleet_summary(store: RedisStore = Depends(get_store), _=Depends(require_reader)):
    return await store.get_fleet_summary()


@router.get("/{rack_id}", response_model=RackRecord)
async def get_rack(rack_id: str, store: RedisStore = Depends(get_store), _=Depends(require_reader)):
    rack = await store.get_rack(rack_id)
    if rack is None:
        raise HTTPException(status_code=404, detail=f"Rack {rack_id} not found")
    return rack


@router.get("/{rack_id}/telemetry")
async def get_telemetry(rack_id: str, store: RedisStore = Depends(get_store),
                        _=Depends(require_reader)):
    snap = await store.get_latest_telemetry(rack_id)
    if snap is None:
        raise HTTPException(status_code=404, detail="No telemetry available")
    return {"rack_id": rack_id, "nodes": snap}


@router.post("/{rack_id}/triage", response_model=RackRecord)
async def disposition_triage(rack_id: str, req: TriageDispositionRequest,
                             store: RedisStore = Depends(get_store), _=Depends(require_operator)):
    """RE_RUN | RE_RUN_AFTER_COOLDOWN | REPAIR | QUARANTINE | WAIVE.
    RE_RUN starts a fresh run (new run_id, node results cleared) in ONBOARDING;
    power admission happens again through the scheduler (1.1 jumped straight
    to BURNING and lost the run_count increment)."""
    try:
        return await store.triage(rack_id, req.disposition, req.reason, req.operator_id)
    except StoreError as exc:
        raise _http(exc)
