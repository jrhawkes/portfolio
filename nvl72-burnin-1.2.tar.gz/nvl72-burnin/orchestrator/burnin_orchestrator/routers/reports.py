"""
orchestrator/burnin_orchestrator/routers/reports.py
Acceptance report: aggregates the 18 node results of the current run.

1.1 issues fixed: unauthenticated; REPORT_DIR created at import time (the
non-root container user can't create /var/lib/..., so the app failed to
start); WeasyPrint ran on the event loop, blocking every other request for
the length of a render; criteria were hard-coded PASS (duration, STREAM
degradation) and C2C could read FAIL on a PASSED rack.
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import FileResponse

from ..deps import get_cfg, get_store, require_operator
from ..redis_store import RedisStore

log = logging.getLogger(__name__)
router = APIRouter()


def _report_dir(cfg) -> Path:
    d = Path(cfg.report_dir)
    d.mkdir(parents=True, exist_ok=True)
    return d


@router.get("/{rack_id}")
async def get_report(rack_id: str, store: RedisStore = Depends(get_store),
                     _=Depends(require_operator)):
    rack = await store.get_rack(rack_id)
    if rack is None:
        raise HTTPException(status_code=404, detail=f"Rack {rack_id} not found")
    return _build_report(rack, await store.get_node_phase_metrics(rack),
                         await store.get_checkpoints(rack))


@router.post("/{rack_id}/generate-pdf")
async def generate_pdf(rack_id: str, request: Request, store: RedisStore = Depends(get_store),
                       _=Depends(require_operator)):
    rack = await store.get_rack(rack_id)
    if rack is None:
        raise HTTPException(status_code=404, detail=f"Rack {rack_id} not found")
    data = _build_report(rack, await store.get_node_phase_metrics(rack),
                         await store.get_checkpoints(rack))
    try:
        path = await run_in_threadpool(_render_pdf, _report_dir(get_cfg(request)),
                                       rack_id, rack.run_id, data)
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"report write failed: {exc}")
    return {"rack_id": rack_id, "path": str(path)}


@router.get("/{rack_id}/download")
async def download_report(rack_id: str, request: Request, store: RedisStore = Depends(get_store),
                          _=Depends(require_operator)):
    rack = await store.get_rack(rack_id)
    if rack is None:
        raise HTTPException(status_code=404, detail="Rack not found")
    d = Path(get_cfg(request).report_dir)
    for ext, mt in (("pdf", "application/pdf"), ("json", "application/json")):
        p = d / f"{rack_id}_{rack.run_id}_acceptance.{ext}"
        if p.exists():
            return FileResponse(str(p), media_type=mt, filename=p.name)
    raise HTTPException(status_code=404, detail="Not generated. POST /reports/{rack_id}/generate-pdf")


def _vals(node_metrics: Dict[str, Dict[str, Any]], phase: str, key: str) -> List[Any]:
    return [m.get(phase, {}).get(key) for m in node_metrics.values()
            if m.get(phase, {}).get(key) is not None]


def _build_report(rack, node_metrics: Dict[str, Dict[str, Any]], checkpoints: List[Dict]) -> dict:
    n_exp = rack.node_count
    nodes_reported = len(node_metrics)

    def row(name, passed, measured=None, required=None):
        known = passed is not None
        return {"criterion": name, "passed": bool(passed), "measured": measured,
                "required": required,
                "result": ("PASS" if passed else "FAIL") if known else "NO DATA"}

    def all_nodes(phase, key, pred):
        v = _vals(node_metrics, phase, key)
        if len(v) < n_exp:
            return None, v
        return all(pred(x) for x in v), v

    gpu_counts = _vals(node_metrics, "boot_validation", "gpu_count")
    stream_min = _vals(node_metrics, "post_burnin", "stream_post_min_gbs")
    c2c = _vals(node_metrics, "functional_validation", "c2c_baseline_gbs")
    degr = _vals(node_metrics, "post_burnin", "gpu_throughput_degradation_pct")
    sdeg = _vals(node_metrics, "post_burnin", "stream_degradation_max_pct")
    crc = _vals(node_metrics, "post_burnin", "nvlink_crc_total")
    replay = _vals(node_metrics, "post_burnin", "nvlink_replay_max_per_gpu")
    dur = _vals(node_metrics, "burnin", "duration_s")
    peak = _vals(node_metrics, "burnin", "gpu_junction_peak_c")
    thr = _vals(node_metrics, "burnin", "thermal_throttle_events")
    full = lambda v: len(v) >= n_exp                               # noqa: E731

    rows = [
        row(f"Nodes reporting ({n_exp})", nodes_reported >= n_exp, nodes_reported, n_exp),
        row("GPU count", sum(gpu_counts) == n_exp * 4 if full(gpu_counts) else None,
            sum(gpu_counts), n_exp * 4),
        row("DCGM diag baseline", all_nodes("functional_validation", "dcgm_l3_baseline_passed", bool)[0]),
        row("DCGM diag post-burn", all_nodes("post_burnin", "dcgm_l3_post_passed", bool)[0]),
        row("GPU memory test failures = 0",
            all_nodes("functional_validation", "gpu_memory_test_errors", lambda x: x == 0)[0]),
        row("NVLink CRC errors = 0", (sum(crc) == 0) if full(crc) else None, sum(crc), 0),
        row("NVLink replay <= 1000/GPU", (max(replay) <= 1000) if full(replay) else None,
            max(replay) if replay else None, 1000),
        row("stress-ng errors = 0",
            all_nodes("post_burnin", "stressng_post_errors", lambda x: x == 0)[0]),
        row("STREAM Triad >= 900 GB/s", (min(stream_min) >= 900) if full(stream_min) else None,
            min(stream_min) if stream_min else None, 900),
        row("NVLink-C2C >= 800 GB/s", (min(c2c) >= 800) if full(c2c) else None,
            min(c2c) if c2c else None, 800),
        row("Burn-in >= 72h", (min(dur) >= 259_200) if full(dur) else None,
            round(min(dur) / 3600, 2) if dur else None, 72),
        row("GPU junction peak <= 90C", (max(peak) <= 90) if full(peak) else None,
            max(peak) if peak else None, 90),
        row("Thermal throttle events = 0", (sum(thr) == 0) if full(thr) else None, sum(thr), 0),
        row("GPU throughput degradation <= 2%", (max(degr) <= 2.0) if full(degr) else None,
            max(degr) if degr else None, 2.0),
        row("STREAM degradation <= 5%", (max(sdeg) <= 5.0) if full(sdeg) else None,
            max(sdeg) if sdeg else None, 5.0),
    ]
    overall = rack.state.value == "PASSED"
    return {
        "rack_id": rack.rack_id, "serial_number": rack.serial_number,
        "facility": rack.facility, "power_zone": rack.power_zone, "run_id": rack.run_id,
        "run_count": rack.run_count, "overall_result": "PASS" if overall else "FAIL",
        "overall_passed": overall, "state": rack.state.value,
        "waived": "WAIVER:" in (rack.notes or ""),
        "registered_at": rack.registered_at, "report_generated_at": time.time(),
        "acceptance_criteria": rows,
        "nodes": {n: {"phases": r.phases, "aborted": r.aborted} for n, r in rack.nodes.items()},
        "failed_components": rack.failed_components,
        "checkpoints": checkpoints, "abort_events": rack.abort_events, "notes": rack.notes,
    }


def _render_pdf(report_dir: Path, rack_id: str, run_id: str, report_data: dict) -> Path:
    try:
        from jinja2 import Template
        from weasyprint import HTML
    except (ImportError, OSError) as exc:     # OSError: pango/cairo libs missing
        json_path = report_dir / f"{rack_id}_{run_id}_acceptance.json"
        json_path.write_text(json.dumps(report_data, indent=2, default=str))
        log.warning("PDF renderer unavailable (%s); wrote JSON report %s", exc, json_path)
        return json_path
    pdf_path = report_dir / f"{rack_id}_{run_id}_acceptance.pdf"
    HTML(string=Template(_PDF_TEMPLATE).render(**report_data)).write_pdf(str(pdf_path))
    return pdf_path


_PDF_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  body { font-family: Arial, sans-serif; font-size: 11pt; margin: 2cm; }
  h1 { color: #1A3A5C; border-bottom: 3px solid #76B900; padding-bottom: 8px; }
  h2 { color: #1F5C99; margin-top: 24px; }
  .verdict { font-size: 28pt; font-weight: bold; padding: 16px; text-align: center;
             border: 3px solid; border-radius: 8px; margin: 20px 0; }
  .pass { color: #2d7a2d; border-color: #2d7a2d; background: #f0fff0; }
  .fail { color: #cc0000; border-color: #cc0000; background: #fff0f0; }
  table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 10pt; }
  th { background: #1A3A5C; color: white; padding: 6px 10px; text-align: left; }
  td { padding: 5px 10px; border-bottom: 1px solid #ddd; }
  tr:nth-child(even) { background: #f5f8fc; }
  .p { color: #2d7a2d; font-weight: bold; }
  .f { color: #cc0000; font-weight: bold; }
</style>
</head>
<body>
<h1>NVL72 Burn-In Acceptance Report</h1>

<table>
  <tr><td><b>Rack ID</b></td><td>{{ rack_id }}</td>
      <td><b>Serial</b></td><td>{{ serial_number }}</td></tr>
  <tr><td><b>Facility</b></td><td>{{ facility }}</td>
      <td><b>Power Zone</b></td><td>{{ power_zone }}</td></tr>
  <tr><td><b>Run ID</b></td><td>{{ run_id }}</td>
      <td><b>Run #</b></td><td>{{ run_count }}</td></tr>
</table>

<div class="verdict {{ 'pass' if overall_passed else 'fail' }}">
  OVERALL: {{ overall_result }}
</div>

<h2>Acceptance Criteria</h2>
<table>
  <tr><th>Criterion</th><th>Required</th><th>Measured</th><th>Result</th></tr>
  {% for row in acceptance_criteria %}
  <tr>
    <td>{{ row.criterion }}</td>
    <td>{{ row.required if row.required is not none else '—' }}</td>
    <td>{{ row.measured if row.measured is not none else '—' }}</td>
    <td class="{{ 'p' if row.passed else 'f' }}">{{ row.result }}</td>
  </tr>
  {% endfor %}
</table>

{% if checkpoints %}
<h2>Thermal Checkpoints</h2>
<table>
  <tr><th>Time</th><th>GPU °C</th><th>CPU °C</th><th>CDU Out °C</th><th>Power kW</th></tr>
  {% for cp in checkpoints %}
  <tr>
    <td>T+{{ cp.hours }}h</td>
    <td>{{ cp.get('node_id', '') }} {{ cp.get('gpu_junction_max_c') }}</td>
    <td>{{ cp.get('cpu_temp_max_c') }}</td>
    <td>{{ cp.get('coolant_outlet_c') }}</td>
    <td>{{ cp.get('tray_power_kw') }}</td>
  </tr>
  {% endfor %}
</table>
{% endif %}

{% if notes %}
<h2>Notes</h2>
<p>{{ notes }}</p>
{% endif %}

<hr>
<p><small>Report generated {{ report_generated_at }}</small></p>
<p>Engineer Signature: ______________________________ Date: _______________</p>
</body>
</html>
"""
