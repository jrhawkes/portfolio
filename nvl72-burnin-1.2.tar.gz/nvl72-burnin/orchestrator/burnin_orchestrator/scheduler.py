"""
orchestrator/burnin_orchestrator/scheduler.py
Power-zone admission, rack timeouts and lost-node detection.

1.1 problems:
  * One scheduler per uvicorn worker per replica (4 workers x N replicas),
    each with its own in-memory "last start" per zone, so the 5-minute
    stagger and the capacity check were both racy and multiplied.
  * Capacity check-then-act was not atomic.
  * Racks waiting in BASELINE counted against capacity (deadlock), and the
    agent promoted itself to BURNING anyway (bypass).
  * Stall checks ran on `int(time.time()) % 300 < 60`, which drifts and skips.
  * Nothing detected a dead agent despite the systemd unit comment saying the
    orchestrator would.

1.2: a Redis lease elects one leader across all workers/replicas; admission
is an optimistic transaction watching the zone slot set and stagger key;
admission gates the first full-power phase (BOOTING -> BASELINE) and the slot
is held through VALIDATING; heartbeats older than node_stale_s abort the rack.
"""

from __future__ import annotations

import asyncio
import logging
import os
import socket
import time
import uuid
from collections import defaultdict
from typing import Dict, List

from .models import RackState
from .redis_store import RedisStore

log = logging.getLogger(__name__)

LEASE_MS = 90_000


class BurninScheduler:
    def __init__(self, cfg, store: RedisStore):
        self.cfg = cfg
        self.store = store
        self.instance_id = f"{socket.gethostname()}:{os.getpid()}:{uuid.uuid4().hex[:6]}"
        self._task: asyncio.Task = None
        self.is_leader = False
        self._last_stall_check = 0.0

    async def start(self):
        self._task = asyncio.create_task(self._loop())
        log.info("Scheduler started (instance %s)", self.instance_id)

    async def stop(self):
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        if self.is_leader:
            await self.store.release_leader(self.instance_id)

    def capacity(self, zone: str) -> int:
        return self.cfg.zone_capacity.get(zone, self.cfg.default_zone_capacity)

    async def _loop(self):
        while True:
            try:
                was = self.is_leader
                self.is_leader = await self.store.acquire_or_renew_leader(self.instance_id, LEASE_MS)
                if self.is_leader != was:
                    log.info("Scheduler leadership %s", "ACQUIRED" if self.is_leader else "lost")
                if self.is_leader:
                    await self.tick()
            except asyncio.CancelledError:
                raise
            except Exception:                                   # noqa: BLE001
                log.exception("Scheduler iteration failed")
            await asyncio.sleep(self.cfg.scheduler_tick_s)

    async def tick(self):
        await self.admit_waiting_racks()
        for rack in await self.store.get_racks_in_state(RackState.BASELINE):
            if not rack.hold:
                await self.store.advance_unheld_baseline(rack.rack_id)
        await self.store.check_stale_nodes()
        if time.time() - self._last_stall_check >= 300:
            self._last_stall_check = time.time()
            await self.store.check_stalled_racks()

    async def admit_waiting_racks(self) -> List[str]:
        """Admit in FIFO order of readiness, one rack per zone per tick (the
        stagger interval would block a second one anyway)."""
        waiting = [r for r in await self.store.get_racks_in_state(RackState.BOOTING)
                   if r.admission_ready and not r.hold]
        by_zone: Dict[str, list] = defaultdict(list)
        for r in sorted(waiting, key=lambda r: r.state_entered_at):
            by_zone[r.power_zone].append(r)
        admitted = []
        for zone, racks in by_zone.items():
            ok, why = await self.store.try_admit(racks[0].rack_id, self.capacity(zone),
                                                 self.cfg.start_interval_s)
            if ok:
                admitted.append(racks[0].rack_id)
                log.info("Admitted %s in zone %s (%d waiting)", racks[0].rack_id, zone, len(racks) - 1)
            else:
                log.debug("Zone %s: %s not admitted: %s", zone, racks[0].rack_id, why)
        return admitted

    async def schedule_rack(self, rack_id: str, power_zone: str) -> bool:
        """1.1 API: attempt admission of one rack now."""
        ok, _ = await self.store.try_admit(rack_id, self.capacity(power_zone),
                                           self.cfg.start_interval_s)
        return ok
