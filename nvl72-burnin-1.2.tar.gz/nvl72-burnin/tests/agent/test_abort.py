"""
tests/agent/test_abort.py
Unit tests for the abort condition evaluator.
No hardware required — all inputs are constructed in-memory.
"""

from __future__ import annotations

import pytest
from unittest.mock import MagicMock

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../agent'))

from burnin_agent.abort import evaluate, AbortEvent
from burnin_agent.config import AbortThresholds
from burnin_agent.telemetry import (
    TelemetrySnapshot, GpuSnapshot, CpuSnapshot, CoolantSnapshot, PowerSnapshot
)


def make_snap(
    gpu_junc=50.0, gpu_hbm=50.0, cpu_temp=45.0,
    coolant_out=52.0, coolant_in=42.0,
    nvlink_crc=0, nvlink_replay=0,
    psu_faults=0, throttle_reasons=None
) -> TelemetrySnapshot:
    gpus = [
        GpuSnapshot(
            index=i,
            junction_temp_c=gpu_junc,
            hbm_temp_c=gpu_hbm,
            nvlink_crc_errors=nvlink_crc,
            nvlink_replay_errors=nvlink_replay,
            throttle_reasons=throttle_reasons or [],
        )
        for i in range(4)   # 4 GPUs for test speed
    ]
    cpus = [CpuSnapshot(socket=s, temp_c=cpu_temp) for s in range(2)]
    return TelemetrySnapshot(
        gpus=gpus,
        cpus=cpus,
        coolant=CoolantSnapshot(
            inlet_temp_c=coolant_in,
            outlet_temp_c=coolant_out,
        ),
        power=PowerSnapshot(psu_fault_count=psu_faults),
    )


THRESHOLDS = AbortThresholds()


class TestNominal:
    def test_no_abort_on_normal_values(self):
        snap = make_snap()
        events = evaluate(snap, THRESHOLDS)
        assert events == []

    def test_sw_power_cap_throttle_is_not_abort(self):
        snap = make_snap(throttle_reasons=["sw_power_cap"])
        events = evaluate(snap, THRESHOLDS)
        assert events == []

    def test_none_throttle_is_not_abort(self):
        snap = make_snap(throttle_reasons=["None"])
        events = evaluate(snap, THRESHOLDS)
        assert events == []


class TestGPUTemperature:
    def test_gpu_junction_exactly_at_threshold_no_abort(self):
        snap = make_snap(gpu_junc=90.0)
        events = evaluate(snap, THRESHOLDS)
        assert events == []

    def test_gpu_junction_one_tenth_over_aborts(self):
        snap = make_snap(gpu_junc=90.1)
        events = evaluate(snap, THRESHOLDS)
        assert any(e.condition.startswith("gpu_") and "junction" in e.condition for e in events)

    def test_gpu_junction_reports_all_offending_gpus(self):
        snap = make_snap(gpu_junc=95.0)
        junction_events = [e for e in evaluate(snap, THRESHOLDS) if "junction" in e.condition]
        # All 4 test GPUs should trigger
        assert len(junction_events) == 4

    def test_gpu_hbm_threshold(self):
        snap = make_snap(gpu_hbm=95.1)
        events = evaluate(snap, THRESHOLDS)
        assert any("hbm" in e.condition for e in events)


class TestCPUTemperature:
    def test_cpu_at_threshold_no_abort(self):
        snap = make_snap(cpu_temp=90.0)
        events = evaluate(snap, THRESHOLDS)
        assert not any("cpu" in e.condition for e in events)

    def test_cpu_over_threshold_aborts(self):
        snap = make_snap(cpu_temp=90.1)
        events = evaluate(snap, THRESHOLDS)
        assert any("cpu" in e.condition for e in events)

    def test_cpu_event_includes_socket_number(self):
        snap = make_snap(cpu_temp=91.0)
        events = evaluate(snap, THRESHOLDS)
        cpu_events = [e for e in events if "cpu_socket" in e.condition]
        assert len(cpu_events) == 2   # 2 test CPU sockets


class TestCoolant:
    def test_coolant_outlet_at_threshold_no_abort(self):
        snap = make_snap(coolant_out=60.0)
        events = evaluate(snap, THRESHOLDS)
        assert not any("coolant_outlet" in e.condition for e in events)

    def test_coolant_outlet_over_threshold_aborts(self):
        snap = make_snap(coolant_out=60.1)
        events = evaluate(snap, THRESHOLDS)
        assert any("coolant_outlet" in e.condition for e in events)

    def test_coolant_inlet_over_threshold_aborts(self):
        snap = make_snap(coolant_in=50.1)
        events = evaluate(snap, THRESHOLDS)
        assert any("coolant_inlet" in e.condition for e in events)


class TestNVLink:
    def test_zero_crc_errors_no_abort(self):
        snap = make_snap(nvlink_crc=0)
        events = evaluate(snap, THRESHOLDS)
        assert not any("nvlink_crc" in e.condition for e in events)

    def test_one_crc_error_aborts(self):
        snap = make_snap(nvlink_crc=1)
        events = evaluate(snap, THRESHOLDS)
        assert any("nvlink_crc" in e.condition for e in events)

    def test_crc_total_includes_all_gpus(self):
        snap = make_snap(nvlink_crc=1)   # 4 GPUs × 1 error = 4 total
        events = evaluate(snap, THRESHOLDS)
        crc_events = [e for e in events if "nvlink_crc" in e.condition]
        assert len(crc_events) == 1
        assert crc_events[0].measured == 4   # total across all GPUs


class TestPSU:
    def test_no_psu_fault_no_abort(self):
        snap = make_snap(psu_faults=0)
        events = evaluate(snap, THRESHOLDS)
        assert not any("psu" in e.condition for e in events)

    def test_psu_fault_aborts(self):
        snap = make_snap(psu_faults=1)
        events = evaluate(snap, THRESHOLDS)
        assert any("psu_fault" in e.condition for e in events)


class TestThrottling:
    def test_hw_thermal_throttle_aborts(self):
        snap = make_snap(throttle_reasons=["hw_thermal"])
        events = evaluate(snap, THRESHOLDS)
        assert any("throttle" in e.condition for e in events)

    def test_pcie_replay_throttle_aborts(self):
        snap = make_snap(throttle_reasons=["pcie_replay"])
        events = evaluate(snap, THRESHOLDS)
        assert any("throttle" in e.condition for e in events)

    def test_multiple_non_cap_reasons_all_reported(self):
        snap = make_snap(throttle_reasons=["hw_thermal", "power_brake"])
        events = evaluate(snap, THRESHOLDS)
        throttle_events = [e for e in events if "throttle" in e.condition]
        assert len(throttle_events) >= 1


class TestWorkloadErrors:
    def test_gpu_burn_error_aborts(self):
        snap = make_snap()
        events = evaluate(snap, THRESHOLDS, gpu_burn_errors=1)
        assert any("gpu_burn" in e.condition for e in events)

    def test_zero_gpu_burn_errors_no_abort(self):
        snap = make_snap()
        events = evaluate(snap, THRESHOLDS, gpu_burn_errors=0)
        assert not any("gpu_burn" in e.condition for e in events)

    def test_stressng_error_aborts(self):
        snap = make_snap()
        events = evaluate(snap, THRESHOLDS, stressng_errors=1)
        assert any("stressng" in e.condition for e in events)


class TestMultipleAborts:
    def test_multiple_conditions_all_returned(self):
        """When multiple abort conditions fire, all are returned in one call."""
        snap = make_snap(
            gpu_junc=91.0,
            cpu_temp=91.0,
            coolant_out=61.0,
            nvlink_crc=2,
            psu_faults=1,
        )
        events = evaluate(snap, THRESHOLDS, gpu_burn_errors=5)
        # Should have: 4 GPU junction + 4 GPU HBM (within threshold) ... actually:
        # 4 GPU junction (91>90) + 2 CPU (91>90) + coolant_outlet + nvlink_crc + psu + gpu_burn
        assert len(events) >= 5

    def test_abort_event_has_required_fields(self):
        snap = make_snap(gpu_junc=95.0)
        events = evaluate(snap, THRESHOLDS)
        for ev in events:
            assert ev.condition
            assert ev.measured is not None
            assert ev.threshold is not None
            assert ev.message


class TestTelemetryHelpers:
    def test_gpu_junction_max(self):
        snap = make_snap()
        snap.gpus[0].junction_temp_c = 88.5
        snap.gpus[1].junction_temp_c = 72.0
        assert snap.gpu_junction_max() == 88.5

    def test_nvlink_crc_total_sums_all_gpus(self):
        snap = make_snap()
        snap.gpus[0].nvlink_crc_errors = 2
        snap.gpus[1].nvlink_crc_errors = 3
        assert snap.nvlink_crc_total() == 5

    def test_throttle_active_false_for_empty(self):
        snap = make_snap()
        assert not snap.throttle_active()

    def test_throttle_active_false_for_sw_power_cap(self):
        snap = make_snap(throttle_reasons=["sw_power_cap"])
        assert not snap.throttle_active()

    def test_throttle_active_true_for_hw_thermal(self):
        snap = make_snap(throttle_reasons=["hw_thermal"])
        assert snap.throttle_active()
