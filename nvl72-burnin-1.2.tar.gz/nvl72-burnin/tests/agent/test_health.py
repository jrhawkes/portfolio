"""Fail-closed abort behaviour."""
from burnin_agent.abort import HealthTracker, evaluate
from burnin_agent.config import AbortThresholds
from burnin_agent.telemetry import GpuSnapshot, TelemetrySnapshot, XidEvent

T = AbortThresholds()


def gpus(n=4, **kw):
    return [GpuSnapshot(index=i, uuid=f"GPU-{i}", serial=f"S{i}", junction_temp_c=50.0,
                        hbm_temp_c=50.0, **kw) for i in range(n)]


def tracker():
    h = HealthTracker(T, ["gpu", "cpu", "nvlink"], 4, "ct00")
    h.set_inventory(gpus())
    return h


def test_unknown_temperature_is_not_a_pass_forever():
    h = tracker()
    snap = TelemetrySnapshot(gpus=[], source_errors={"gpu": "nvidia-smi: timed out after 20s"})
    assert not evaluate(snap, T)                       # no fake 0°C reading
    assert not h.evaluate(snap) and not h.evaluate(snap)
    ev = h.evaluate(snap)                              # third consecutive failure
    assert ev and ev[0].condition == "telemetry_lost_gpu"


def test_source_recovery_resets_streak():
    h = tracker()
    bad = TelemetrySnapshot(gpus=gpus(), source_errors={"cpu": "no zones"})
    good = TelemetrySnapshot(gpus=gpus())
    h.evaluate(bad); h.evaluate(bad); h.evaluate(good)
    assert not h.evaluate(bad)


def test_missing_gpu_named_from_inventory():
    h = tracker()
    snap = TelemetrySnapshot(gpus=gpus(4)[:3], source_errors={"gpu": "3 GPUs visible, expected 4"})
    ev = h.evaluate(snap)
    assert ev[0].condition == "gpu_missing" and ev[0].component["serial"] == "S3"


def test_fatal_xid_aborts_with_component():
    h = tracker()
    g = gpus()
    snap = TelemetrySnapshot(gpus=g, xid_events=[XidEvent(79, "0009:01:00", 2, "off bus", 0)])
    ev = h.evaluate(snap)
    assert ev[0].condition == "xid_79" and ev[0].component["uuid"] == "GPU-2"


def test_nonfatal_xid_ignored():
    snap = TelemetrySnapshot(gpus=gpus(), xid_events=[XidEvent(13, "x", 0, "app", 0)])
    assert not tracker().evaluate(snap)


def test_ecc_and_remap():
    g = gpus()
    g[1].ecc_dbe_volatile = 1
    g[2].remap_failure = True
    conds = {e.condition for e in tracker().evaluate(TelemetrySnapshot(gpus=g))}
    assert conds == {"gpu_1_ecc_dbe", "gpu_2_row_remap_failure"}


def test_crc_judged_on_delta_from_baseline():
    g = gpus(nvlink_crc_errors=7)
    snap = TelemetrySnapshot(gpus=g)
    assert evaluate(snap, T)                                        # absolute
    assert not evaluate(snap, T, nvlink_crc_baseline={i: 7 for i in range(4)})
    g[3].nvlink_crc_errors = 8
    ev = evaluate(snap, T, nvlink_crc_baseline={i: 7 for i in range(4)})
    assert ev[0].component["gpu_index"] == 3


def test_hung_tools():
    snap = TelemetrySnapshot(gpus=gpus(), abandoned_children=2)
    assert tracker().evaluate(snap)[0].condition == "hung_tools"
