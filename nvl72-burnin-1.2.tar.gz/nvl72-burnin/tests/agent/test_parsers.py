"""Parsers for real tool output formats (the 1.1 versions were wrong)."""
from burnin_agent.phases import (parse_bw_matrix, parse_dcgm_diag, parse_nvlink_status)
from burnin_agent.telemetry import (count_psu_faults, decode_throttle, normalize_pci,
                                    parse_nvlink_errors, parse_xid_line)
from burnin_agent.workloads import (parse_dcgm_health, parse_gpu_burn, parse_stream_triad,
                                    parse_stressng)

GPU_BURN = (
    "Burning for 900 seconds.\n"
    "10.0%  proc'd: 100 (50000 Gflop/s) - 100 (50100 Gflop/s)   errors: 0 - 0   temps: 55 C - 56 C \r"
    "20.0%  proc'd: 200 (51000 Gflop/s) - 200 (51200 Gflop/s)   errors: 0 - 0   temps: 60 C - 61 C \r"
    "30.0%  proc'd: 300 (51000 Gflop/s) - 300 (51200 Gflop/s)   errors: 0 - 3   temps: 61 C - 62 C \n"
    "Tested 2 GPUs:\n\tGPU 0: OK\n\tGPU 1: FAULTY\n")


def test_gpu_burn_per_gpu_errors_and_steady_throughput():
    r = parse_gpu_burn(GPU_BURN)
    assert r.per_gpu_errors == [0, 3] and r.total_errors == 3
    assert r.faulty_gpus == [1]
    # median of per-sample aggregates, not the sum of every line (1.1 bug)
    assert r.steady_gflops == 102200.0


def test_gpu_burn_died():
    assert parse_gpu_burn("50%  proc'd: 1 (1 Gflop/s) errors: 0 (DIED!) - 0").died


def test_stressng_pid_is_not_an_error_count():
    out = "stress-ng: info:  [48213] setting to a 300 second run\n" \
          "stress-ng: info:  [48213] successful run completed in 300.01s\n"
    assert parse_stressng(out, 0) == 0
    out2 = "stress-ng: fail:  [48213] cpu: matrixprod verification failed\n" \
           "stress-ng: info:  [48213] failed: 1: cpu (1)\n"
    assert parse_stressng(out2, 2) == 1
    assert parse_stressng("", 2) == 1


def test_stream_triad():
    assert parse_stream_triad("Copy:  400000.1  0.1\nTriad:   452123.4   0.08  0.08 0.09\n") \
        == 452.1234


def test_throttle_bitmask():
    assert decode_throttle("0x0000000000000004") == (["sw_power_cap"], [])
    assert decode_throttle("0x0000000000000000") == ([], [])      # 1.1 aborted on this
    r, _ = decode_throttle("0x0000000000000044")
    assert r == ["sw_power_cap", "hw_thermal_slowdown"]
    assert decode_throttle("[N/A]") == ([], [])
    assert decode_throttle("0x1000")[1] == ["0x1000"]


def test_nvlink_errors_all_gpus():
    out = ("GPU 0: NVIDIA GB200 (UUID: GPU-a)\n"
           "\t Link 0: Replay Errors: 2\n\t Link 0: Recovery Errors: 0\n\t Link 0: CRC Errors: 0\n"
           "\t Link 1: Replay Errors: 1\n\t Link 1: Recovery Errors: 0\n\t Link 1: CRC Errors: 5\n"
           "GPU 1: NVIDIA GB200 (UUID: GPU-b)\n")
    p = parse_nvlink_errors(out)
    assert p[0] == {"crc": 5, "replay": 3, "recovery": 0, "links": 2}
    assert p[1]["links"] == 0                      # header only => caller treats as unparsed


def test_psu_presence_is_not_fault():
    out = ("PSU1 Status      | 50h | ok  | 10.1 | Presence detected\n"
           "PSU2 Status      | 51h | ok  | 10.2 | Presence detected, Failure detected\n"
           "PSU3 Status      | 52h | ok  | 10.3 | Presence detected, Power Supply AC lost\n")
    assert count_psu_faults(out) == 2


def test_xid_and_pci_normalisation():
    pci, xid, msg = parse_xid_line("NVRM: Xid (PCI:0009:01:00): 79, pid=0, GPU has fallen off the bus.")
    assert xid == 79 and "fallen" in msg
    assert normalize_pci(pci) == normalize_pci("00000009:01:00.0")


def test_dcgm_diag_json_case_insensitive():
    js = '{"DCGM GPU Diagnostic": {"test_categories": [{"category": "Hardware", "tests": [' \
         '{"name": "Memory", "results": [{"gpu_id": "0", "status": "Pass"}, ' \
         '{"gpu_id": "1", "status": "Fail", "info": "DBE"}]}]}]}}'
    ok, fails, _ = parse_dcgm_diag(js, 226)
    assert not ok and "gpu 1" in fails[0]
    ok, fails, _ = parse_dcgm_diag(js.replace('"Fail"', '"Pass"'), 0)
    assert ok, fails


def test_dcgm_diag_unparseable_fails_closed():
    ok, fails, _ = parse_dcgm_diag("Error: unable to connect to host engine", 255)
    assert not ok


def test_dcgm_health_text():
    assert parse_dcgm_health("+---+\n| Overall Health | Healthy |\n")[0] == "healthy"
    assert parse_dcgm_health("| Overall Health | Failure |")[0] == "failure"


def test_bw_matrix_skips_na_and_labels():
    out = ("memcpy CE GPU(row) <- GPU(column) bandwidth (GB/s)\n"
           "           0         1\n"
           " 0       N/A    780.12\n"
           " 1    781.50       N/A\n\n"
           "SUM device_to_device 1561.62\n")
    assert parse_bw_matrix(out) == [780.12, 781.5]


def test_nvlink_status_counts():
    out = "GPU 0: X\n\t Link 0: 50 GB/s\n\t Link 1: <inactive>\nGPU 1: X\n\t Link 0: 50 GB/s\n"
    assert parse_nvlink_status(out) == {0: {"active": 1, "inactive": 1},
                                        1: {"active": 1, "inactive": 0}}
