"""Process handling, workload death/hang detection, outbox semantics."""
import time
from pathlib import Path
from types import SimpleNamespace

from burnin_agent import proc
from burnin_agent.api_client import OrchestratorClient
from burnin_agent.config import AgentConfig
from burnin_agent.workloads import WorkloadManager


def test_run_cmd_timeout_and_missing_binary():
    r = proc.run_cmd(["sleep", "10"], 0.5)
    assert r.timed_out and not r.ok and r.duration_s < 5
    r = proc.run_cmd(["/nonexistent/tool"], 5)
    assert r.error and "launch failed" in r.error and not r.ok


def _cfg(tmp):
    c = AgentConfig(rack_id="r1", node_id="ct00", state_dir=str(tmp), log_dir=str(tmp))
    c.workload.enable_hpcg = False
    c.orchestrator.url = "http://127.0.0.1:9"
    c.orchestrator.token = "t"
    return c


def test_early_gpu_burn_exit_is_failure(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    cfg.workload.gpu_burn_path = "/bin/true"          # exits immediately, rc=0
    cfg.workload.stress_ng_binary = "/bin/sleep"
    monkeypatch.setattr(WorkloadManager, "_dcgm_health_setup", lambda self: None)
    wm = WorkloadManager(cfg, tmp_path)
    # stress_ng replaced by sleep: give it a valid arg list
    monkeypatch.setattr(wm, "_launch", _wrap_launch(wm))
    wm.launch_all(time.time() + 3600)
    time.sleep(0.3)
    fails = wm.check()
    wm.terminate_all()
    assert any(f["workload"] == "gpu_burn" and "before deadline" in f["reason"] for f in fails)


def _wrap_launch(wm):
    orig = WorkloadManager._launch

    def launch(name, cmd, log_path):
        if name == "stress_ng":
            cmd = ["/bin/sleep", "30"]
        return orig(wm, name, cmd, log_path)
    return launch


def test_launch_failure_is_failure(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    cfg.workload.gpu_burn_path = "/nonexistent/gpu_burn"
    cfg.workload.stress_ng_binary = "/nonexistent/stress-ng"
    monkeypatch.setattr(WorkloadManager, "_dcgm_health_setup", lambda self: None)
    wm = WorkloadManager(cfg, tmp_path)
    wm.launch_all(time.time() + 3600)
    fails = {f["workload"] for f in wm.check()}
    wm.terminate_all()
    assert {"gpu_burn", "stress_ng"} <= fails


def test_terminate_all_is_bounded(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    cfg.workload.gpu_burn_path = "/bin/sleep"
    monkeypatch.setattr(WorkloadManager, "_dcgm_health_setup", lambda self: None)
    wm = WorkloadManager(cfg, tmp_path)
    for i in range(6):
        wm._launch(f"w{i}", ["sleep", "100"], tmp_path / f"w{i}.log")
    t0 = time.time()
    wm.terminate_all()
    assert time.time() - t0 < 5


class FakeResp(SimpleNamespace):
    @property
    def ok(self):
        return 200 <= self.status_code < 300


def _client(tmp_path, codes):
    c = OrchestratorClient(_cfg(tmp_path), "r1", "ct00", db_path=tmp_path / "o.db",
                           start_sender=False)
    seq = iter(codes)
    c._session.post = lambda *a, **k: FakeResp(status_code=next(seq), text="x")
    return c


def test_outbox_classification(tmp_path):
    c = _client(tmp_path, [503, 200])
    c.report_state("BOOTING")
    row = c._peek()
    assert c._deliver(row) == "retry" and c.pending_count() == 1
    assert c._deliver(row) == "done"

    c = _client(tmp_path / "b", [409])
    c.report_abort([{"condition": "x"}], {})
    row = c._peek()
    assert c._deliver(row) == "dead"               # 1.1 silently dropped this
    c._dead_letter(row)
    assert c.pending_count() == 0
    assert c._db.execute("SELECT COUNT(*) FROM dead_letter").fetchone()[0] == 1

    c = _client(tmp_path / "c", [401])
    c.report_state("X")
    assert c._deliver(c._peek()) == "retry" and c.auth_failing


def test_abort_jumps_queue_and_survives_restart(tmp_path):
    c = _client(tmp_path, [])
    c.report_state("BOOTING")
    c.push_checkpoint(1, {})
    c.report_abort([{"condition": "x"}], {})
    assert c._peek()["type"] == "abort"
    c2 = _client(tmp_path, [])                       # same DB = agent restart
    assert c2.pending_count() == 3


def test_enqueue_never_blocks_on_network(tmp_path):
    c = OrchestratorClient(_cfg(tmp_path), "r1", "ct00", db_path=tmp_path / "o.db",
                           start_sender=True)       # unreachable orchestrator
    t0 = time.time()
    for _ in range(50):
        c.report_state("BOOTING")
    assert time.time() - t0 < 1.0
    c.stop()
