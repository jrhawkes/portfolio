import os
import sys

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, "..", "agent"))
sys.path.insert(0, os.path.join(HERE, "..", "orchestrator"))
os.environ.setdefault("AGENT_TOKEN", "test-agent-token-0123456789")
os.environ.setdefault("OPERATOR_TOKEN", "test-operator-token-0123456789")
