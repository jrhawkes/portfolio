"""Agent outbox/directive client against the real orchestrator app (uvicorn,
fakeredis). Verifies paths, envelope, status-code contract, and that a rack
completes when 18 node clients report."""
import socket
import threading
import time

import fakeredis
import pytest
import requests
import uvicorn

from burnin_agent.api_client import OrchestratorClient
from burnin_agent.config import AgentConfig
from burnin_orchestrator import main
from burnin_orchestrator.config import OrchestratorConfig
from burnin_orchestrator.redis_store import RedisStore

OP = {"Authorization": "Bearer o"}


def _free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


@pytest.fixture(scope="module")
def server():
    cfg = OrchestratorConfig(agent_shared_token="a", operator_token="o", start_interval_s=0,
                             vm_forward=False)
    main.app.state.cfg = cfg
    main.app.state.store = RedisStore(cfg, client=fakeredis.FakeAsyncRedis(decode_responses=True))
    main.app.state.scheduler = type("S", (), {"is_leader": True})()
    main.app.state.vm_forwarder = None
    port = _free_port()
    srv = uvicorn.Server(uvicorn.Config(main.app, host="127.0.0.1", port=port,
                                        lifespan="off", log_level="warning"))
    t = threading.Thread(target=srv.run, daemon=True)
    t.start()
    for _ in range(100):
        try:
            requests.get(f"http://127.0.0.1:{port}/healthz", timeout=0.2)
            break
        except requests.RequestException:
            time.sleep(0.05)
    yield f"http://127.0.0.1:{port}"
    srv.should_exit = True
    t.join(timeout=5)


def _client(url, tmp, node):
    c = AgentConfig(rack_id="rk", node_id=node, state_dir=str(tmp / node), log_dir=str(tmp))
    c.orchestrator.url = url
    c.orchestrator.token = "a"
    c.orchestrator.backoff_initial_s = 0.1
    return OrchestratorClient(c, "rk", node)


def test_eighteen_nodes_drive_rack_to_burning(server, tmp_path):
    base = server
    assert requests.post(f"{base}/racks", headers=OP, json={
        "rack_id": "rk", "serial_number": "S", "facility": "dc1",
        "power_zone": "zA"}).status_code == 201
    requests.post(f"{base}/racks/rk/state", headers=OP, json={"state": "ONBOARDING"})
    clients = [_client(base, tmp_path, f"ct{i:02d}") for i in range(18)]
    run_id = clients[0].get_directive()["run_id"]
    for c in clients:
        c.set_run_id(run_id)
        c.report_state("BOOTING")
        c.report_phase_result("boot_validation", True, {"failures": []})
        c.heartbeat({"gpu_count": 4})
    for c in clients:
        assert c.flush(20), c.pending_count()
    r = requests.get(f"{base}/racks/rk", headers=OP).json()
    assert r["state"] == "BOOTING" and r["admission_ready"] and len(r["nodes"]) == 18

    # admission is the scheduler's job (covered in test_store); here an
    # operator forces it so the HTTP contract can be exercised end to end
    assert requests.post(f"{base}/racks/rk/state", headers=OP,
                         json={"state": "BASELINE", "force": True}).status_code == 200

    for c in clients:
        c.report_phase_result("functional_validation", True, {"failures": []})
    for c in clients:
        assert c.flush(20)
    d = clients[3].get_directive()
    assert d["rack_state"] == "BURNING" and d["burn_deadline_ts"]

    # one node aborts -> everyone is told to abort
    clients[7].report_abort([{"condition": "xid_79",
                              "component": {"type": "gpu", "serial": "X1"}}], {})
    assert clients[7].flush(10)
    assert clients[0].get_directive()["command"] == "abort"
    rack = requests.get(f"{base}/racks/rk", headers=OP).json()
    assert rack["state"] == "ABORTED" and rack["failed_components"][0]["serial"] == "X1"

    # late results from other trays are recorded but cannot revive the rack
    clients[1].report_phase_result("burnin", True, {"failures": []})
    assert clients[1].flush(10)
    assert requests.get(f"{base}/racks/rk", headers=OP).json()["state"] == "ABORTED"

    # after a re-run, an event carrying the old run_id is rejected (409) and
    # dead-lettered by the agent instead of being retried forever
    assert requests.post(f"{base}/racks/rk/triage", headers=OP, json={
        "disposition": "RE_RUN", "reason": "swap GPU", "operator_id": "eng"}).status_code == 200
    clients[2].report_state("BOOTING")
    assert clients[2].flush(10)
    assert clients[2]._db.execute("SELECT COUNT(*) FROM dead_letter").fetchone()[0] == 1
    for c in clients:
        c.stop()


