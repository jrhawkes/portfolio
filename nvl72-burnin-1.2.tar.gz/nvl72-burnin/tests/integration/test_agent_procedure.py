"""Runs the real BurninAgent control flow (directive waits, admission gate,
safety monitor, burn loop, outbox) against the real orchestrator app, with
hardware tools stubbed. Rack node_count=1 to keep it fast."""
import os
import stat
import threading
import time

import pytest
import requests

from burnin_agent import agent as agent_mod
from burnin_agent.config import AgentConfig
from burnin_agent.telemetry import CpuSnapshot, GpuSnapshot, TelemetrySnapshot
from burnin_orchestrator import main

from .test_agent_orchestrator_contract import OP, server  # noqa: F401 (fixture)


def _script(path, body):
    path.write_text("#!/bin/sh\n" + body + "\n")
    path.chmod(path.stat().st_mode | stat.S_IEXEC)
    return str(path)


def _healthy(*_a, **_k):
    return TelemetrySnapshot(node_id="ct00",
                             gpus=[GpuSnapshot(index=i, uuid=f"G{i}", junction_temp_c=40.0,
                                               hbm_temp_c=40.0, nvlink_crc_errors=0)
                                   for i in range(4)],
                             cpus=[CpuSnapshot(socket=s, temp_c=40.0) for s in range(2)])


def _agent_cfg(tmp, url, rack):
    c = AgentConfig(rack_id=rack, node_id="ct00", state_dir=str(tmp / "s"),
                    log_dir=str(tmp / "l"))
    c.orchestrator.url, c.orchestrator.token = url, "a"
    c.orchestrator.directive_poll_s = 1
    c.telemetry.poll_interval_s = 5
    c.telemetry.required_sources = []
    c.telemetry.xid_source = "none"
    c.workload.enable_hpcg = False
    c.workload.gpu_burn_path = _script(tmp / "gpu_burn", "sleep 600")
    c.workload.stress_ng_binary = _script(tmp / "stress", "sleep 600")
    c.acceptance.burnin_duration_min_s = 2
    c.checkpoint_intervals_h = []
    return c


def _patch(monkeypatch, boot=True):
    monkeypatch.setattr(agent_mod.TelemetryCollector, "collect_once",
                        lambda self: setattr(self, "_latest", _healthy()) or self._latest)
    monkeypatch.setattr(agent_mod.TelemetryCollector, "start_prometheus", lambda self: None)
    monkeypatch.setattr(agent_mod, "run_boot_validation", lambda cfg, col, h: (boot, {"failures": []}))
    monkeypatch.setattr(agent_mod, "run_functional_validation",
                        lambda cfg, d, g: (True, {"failures": []}))
    monkeypatch.setattr(agent_mod, "run_post_burnin", lambda cfg, d, b, g: (True, {"failures": []}))
    monkeypatch.setattr(agent_mod.BurninAgent, "_wait_for_idle_temps",
                        lambda self, timeout_s=0: {"cooldown_reached": True})
    monkeypatch.setattr(agent_mod.signal, "signal", lambda *a: None)
    monkeypatch.setattr(agent_mod.WorkloadManager, "_dcgm_health_setup", lambda self: None)


def _register(base, rack):
    requests.post(f"{base}/racks", headers=OP, json={"rack_id": rack, "serial_number": "S",
                                                     "facility": "dc1", "power_zone": "zB",
                                                     "node_count": 1})
    requests.post(f"{base}/racks/{rack}/state", headers=OP, json={"state": "ONBOARDING"})


def _admit_when_ready(base, rack, stop):
    while not stop.is_set():
        r = requests.get(f"{base}/racks/{rack}", headers=OP).json()
        if r["state"] == "BOOTING" and r["admission_ready"]:
            requests.post(f"{base}/racks/{rack}/state", headers=OP, json={"state": "BASELINE"})
            return
        time.sleep(0.2)


def test_agent_passes_rack_end_to_end(server, tmp_path, monkeypatch):  # noqa: F811
    _patch(monkeypatch)
    main.app.state.cfg.burnin_duration_s = 3
    _register(server, "rkA")
    stop = threading.Event()
    threading.Thread(target=_admit_when_ready, args=(server, "rkA", stop), daemon=True).start()
    a = agent_mod.BurninAgent(_agent_cfg(tmp_path, server, "rkA"))
    t0 = time.time()
    rc = a.run()
    stop.set()
    assert rc == 0, a.monitor.abort_events
    assert requests.get(f"{server}/racks/rkA", headers=OP).json()["state"] == "PASSED"
    assert time.time() - t0 < 60


def test_gpu_burn_crash_aborts_rack(server, tmp_path, monkeypatch):  # noqa: F811
    _patch(monkeypatch)
    main.app.state.cfg.burnin_duration_s = 3600
    _register(server, "rkB")
    stop = threading.Event()
    threading.Thread(target=_admit_when_ready, args=(server, "rkB", stop), daemon=True).start()
    cfg = _agent_cfg(tmp_path, server, "rkB")
    cfg.workload.gpu_burn_path = _script(tmp_path / "gb_crash", "sleep 1; exit 139")
    a = agent_mod.BurninAgent(cfg)
    rc = a.run()
    stop.set()
    assert rc == 1
    r = requests.get(f"{server}/racks/rkB", headers=OP).json()
    assert r["state"] == "ABORTED" and "workload_gpu_burn" in r["state_reason"]


def test_operator_abort_reaches_agent(server, tmp_path, monkeypatch):  # noqa: F811
    _patch(monkeypatch)
    main.app.state.cfg.burnin_duration_s = 3600
    _register(server, "rkC")
    stop = threading.Event()
    threading.Thread(target=_admit_when_ready, args=(server, "rkC", stop), daemon=True).start()

    def op_abort():
        while requests.get(f"{server}/racks/rkC", headers=OP).json()["state"] != "BURNING":
            time.sleep(0.2)
        time.sleep(1)
        requests.post(f"{server}/racks/rkC/commands", headers=OP,
                      json={"action": "abort", "reason": "coolant work"})
    threading.Thread(target=op_abort, daemon=True).start()
    cfg = _agent_cfg(tmp_path, server, "rkC")
    cfg.orchestrator.directive_poll_burn_s = 1
    a = agent_mod.BurninAgent(cfg)
    t0 = time.time()
    assert a.run() == 1
    assert time.time() - t0 < 60
    stop.set()
    assert a.monitor.abort_events[0].condition == "orchestrator_abort"


