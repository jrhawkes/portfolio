"""
tests/orchestrator/test_models.py
Unit tests for the rack state machine models and state transition logic.
Uses an in-memory fake store (no Redis required).
"""

from __future__ import annotations

import time
import pytest
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../orchestrator'))

from burnin_orchestrator.models import (
    RackRecord, RackState, ACTIVE_STATES, HUMAN_REQUIRED_STATES, STATE_TIMEOUTS,
)


# ── Fixtures ───────────────────────────────────────────────────────────────────

def make_rack(**kwargs) -> RackRecord:
    defaults = dict(
        rack_id="rack-test-001",
        serial_number="SN-TEST",
        facility="dc1",
        power_zone="zone-A",
        bmc_ip="10.0.1.1",
        mgmt_ip="10.0.2.1",
        state=RackState.REGISTERED,
        run_id="abc12345",
    )
    defaults.update(kwargs)
    return RackRecord(**defaults)


# ── RackState enum ────────────────────────────────────────────────────────────

class TestRackStateEnum:
    def test_all_states_have_string_value(self):
        for s in RackState:
            assert isinstance(s.value, str)
            assert s.value == s.value.upper()

    def test_state_from_string(self):
        assert RackState("BURNING") == RackState.BURNING
        assert RackState("PASSED") == RackState.PASSED

    def test_invalid_state_raises(self):
        with pytest.raises(ValueError):
            RackState("NONEXISTENT")

    def test_active_states_are_subset_of_all_states(self):
        for s in ACTIVE_STATES:
            assert s in RackState

    def test_human_required_states_are_subset_of_all_states(self):
        for s in HUMAN_REQUIRED_STATES:
            assert s in RackState

    def test_active_and_human_required_disjoint(self):
        """Active states should not require human action."""
        overlap = ACTIVE_STATES & HUMAN_REQUIRED_STATES
        assert overlap == set(), f"Overlap found: {overlap}"

    def test_burning_is_active(self):
        assert RackState.BURNING in ACTIVE_STATES

    def test_passed_requires_human(self):
        assert RackState.PASSED in HUMAN_REQUIRED_STATES

    def test_failed_requires_human(self):
        assert RackState.FAILED in HUMAN_REQUIRED_STATES


# ── STATE_TIMEOUTS ─────────────────────────────────────────────────────────────

class TestStateTimeouts:
    def test_burning_has_longest_timeout(self):
        burning_timeout = STATE_TIMEOUTS.get(RackState.BURNING, 0)
        for state, timeout in STATE_TIMEOUTS.items():
            if state != RackState.BURNING:
                assert timeout <= burning_timeout, \
                    f"{state} timeout ({timeout}) exceeds BURNING ({burning_timeout})"

    def test_critical_states_have_timeouts(self):
        """States that auto-advance (not human-gated) must have timeouts."""
        auto_states = [s for s in RackState if s not in HUMAN_REQUIRED_STATES]
        for s in auto_states:
            if s in (RackState.REGISTERED, RackState.PASSED):
                continue  # exempt: REGISTERED is entry, PASSED has sign-off SLA
            assert s in STATE_TIMEOUTS, f"{s} has no timeout configured"

    def test_onboarding_timeout_under_1h(self):
        assert STATE_TIMEOUTS[RackState.ONBOARDING] <= 3600

    def test_burning_timeout_covers_72h_burn_with_slack(self):
        # 1.2: rack BURNING spans one shared 72h node deadline; 96h hid dead
        # racks for an extra day. Must still exceed 72h plus drain time.
        assert 74 * 3600 <= STATE_TIMEOUTS[RackState.BURNING] <= 96 * 3600


# ── RackRecord model ───────────────────────────────────────────────────────────

class TestRackRecord:
    def test_default_state_is_registered(self):
        r = make_rack()
        assert r.state == RackState.REGISTERED

    def test_serialization_round_trip(self):
        r = make_rack()
        r.phase_results["boot"] = {"passed": True, "metrics": {"gpu_count": 72}}
        json_str = r.model_dump_json()
        restored = RackRecord.model_validate_json(json_str)
        assert restored.rack_id == r.rack_id
        assert restored.state == r.state
        assert restored.phase_results["boot"]["passed"] is True

    def test_state_entered_at_defaults_to_now(self):
        before = time.time()
        r = make_rack()
        after = time.time()
        assert before <= r.state_entered_at <= after

    def test_run_count_defaults_to_zero(self):
        r = make_rack()
        assert r.run_count == 0

    def test_phase_results_default_empty(self):
        r = make_rack()
        assert r.phase_results == {}

    def test_checkpoints_default_empty(self):
        r = make_rack()
        assert r.checkpoints == []

    def test_abort_events_default_empty(self):
        r = make_rack()
        assert r.abort_events == []

    def test_commands_pending_default_empty(self):
        r = make_rack()
        assert r.commands_pending == []

    def test_state_transition_preserves_other_fields(self):
        r = make_rack()
        r.run_count = 2
        r.phase_results["boot"] = {"passed": True}
        # Simulate what the store does
        r.previous_state = r.state
        r.state = RackState.BURNING
        r.state_entered_at = time.time()
        # Other fields should be unchanged
        assert r.run_count == 2
        assert r.phase_results["boot"]["passed"] is True
        assert r.previous_state == RackState.REGISTERED


# ── Acceptance criteria mapping ────────────────────────────────────────────────

class TestAcceptanceCriteriaMapping:
    """
    Validate that the 19 BIP-001 §9 acceptance criteria are all representable
    in phase_results. This is a regression guard — if someone removes a
    phase result key, these tests catch it.
    """

    REQUIRED_PHASE_KEYS = [
        "boot_validation",
        "functional_validation",
        "burnin_72h",
        "post_burnin",
        "result_bundle",
    ]

    REQUIRED_BOOT_METRICS = ["gpu_count", "driver_version", "fabric_manager_active"]
    REQUIRED_FUNC_METRICS = [
        "dcgm_l3_baseline_passed", "stressng_sanity_errors",
        "stream_baseline_min_gbs", "c2c_baseline_gbs",
        "gpu_memory_test_errors", "nvlink_allpairs_min_gbs",
    ]
    REQUIRED_POST_METRICS = [
        "dcgm_l3_post_passed", "stream_post_min_gbs", "stressng_post_errors",
        "nvlink_crc_total", "nvlink_replay_max_per_gpu",
        "gpu_throughput_degradation_pct",
    ]

    def _make_full_rack(self) -> RackRecord:
        r = make_rack(state=RackState.PASSED)
        r.phase_results = {
            "boot_validation": {
                "passed": True,
                "metrics": {k: 72 if k == "gpu_count" else True
                            for k in self.REQUIRED_BOOT_METRICS},
                "timestamp": time.time(),
            },
            "functional_validation": {
                "passed": True,
                "metrics": {
                    "dcgm_l3_baseline_passed": True,
                    "stressng_sanity_errors": 0,
                    "stream_baseline_min_gbs": 950.0,
                    "c2c_baseline_gbs": 820.0,
                    "gpu_memory_test_errors": 0,
                    "nvlink_allpairs_min_gbs": 910.0,
                    "gpu_throughput_baseline_tflops": 14000.0,
                },
                "timestamp": time.time(),
            },
            "burnin_72h": {"passed": True, "metrics": {"completed": True}, "timestamp": time.time()},
            "post_burnin": {
                "passed": True,
                "metrics": {
                    "dcgm_l3_post_passed": True,
                    "stream_post_min_gbs": 945.0,
                    "stressng_post_errors": 0,
                    "nvlink_crc_total": 0,
                    "nvlink_replay_max_per_gpu": 42,
                    "gpu_throughput_degradation_pct": 0.8,
                    "stream_post_gbs_per_socket": {str(i): 945.0 for i in range(36)},
                },
                "timestamp": time.time(),
            },
            "result_bundle": {"passed": True, "metrics": {}, "timestamp": time.time()},
        }
        return r

    def test_all_phase_keys_present(self):
        r = self._make_full_rack()
        for key in self.REQUIRED_PHASE_KEYS:
            assert key in r.phase_results, f"Missing phase key: {key}"

    def test_all_boot_metrics_present(self):
        r = self._make_full_rack()
        boot_metrics = r.phase_results["boot_validation"]["metrics"]
        for key in self.REQUIRED_BOOT_METRICS:
            assert key in boot_metrics, f"Missing boot metric: {key}"

    def test_all_func_metrics_present(self):
        r = self._make_full_rack()
        func_metrics = r.phase_results["functional_validation"]["metrics"]
        for key in self.REQUIRED_FUNC_METRICS:
            assert key in func_metrics, f"Missing functional metric: {key}"

    def test_all_post_metrics_present(self):
        r = self._make_full_rack()
        post_metrics = r.phase_results["post_burnin"]["metrics"]
        for key in self.REQUIRED_POST_METRICS:
            assert key in post_metrics, f"Missing post-burn metric: {key}"

    def test_gpu_count_is_72(self):
        r = self._make_full_rack()
        assert r.phase_results["boot_validation"]["metrics"]["gpu_count"] == 72

    def test_stream_meets_acceptance_threshold(self):
        r = self._make_full_rack()
        min_bw = r.phase_results["post_burnin"]["metrics"]["stream_post_min_gbs"]
        assert min_bw >= 900.0, f"STREAM {min_bw} GB/s below 900 GB/s threshold"

    def test_nvlink_crc_zero(self):
        r = self._make_full_rack()
        crc = r.phase_results["post_burnin"]["metrics"]["nvlink_crc_total"]
        assert crc == 0

    def test_gpu_throughput_degradation_under_2pct(self):
        r = self._make_full_rack()
        deg = r.phase_results["post_burnin"]["metrics"]["gpu_throughput_degradation_pct"]
        assert deg <= 2.0
