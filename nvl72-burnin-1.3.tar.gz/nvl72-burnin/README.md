# NVL72 Burn-In System

Automated parallel burn-in qualification for NVIDIA GB200 NVL72 racks,
implementing **NVL72-BIP-001 Rev 1.1** across 100–1,000 racks concurrently
with a minimum of human interaction.

> **Version 1.3** — GB200 acceptance thresholds (below). **1.2** — see `REVIEW.md`. The agent now
> runs **once per compute tray** (18 per rack); the orchestrator aggregates
> node results into the rack verdict and owns every rack state transition.

## How a run works (1.2)

```
operator            orchestrator (leader-elected scheduler)        18 node agents
INSPECTING ──► ONBOARDING (new run_id) ──────────────────────────► directive: run_id
                     BOOTING ◄──────────── node boot_validation (idle) x18
      power-zone admission (slot + stagger) ─► BASELINE ─────────► functional validation
                     BURNING (shared deadline) ◄────────── all 18 passed functional
                     VALIDATING ◄────────────── all 18 completed burn-in
                     PASSED ◄───────────────── all 18 passed post-burn
 any node fails/aborts/goes silent ─► FAILED/ABORTED ─► directive "abort" to all nodes
```

Agent ↔ orchestrator contract: `POST /racks/{rack}/nodes/{node}/events`
(durable, idempotent on `event_id`, ordered by `seq`),
`POST …/heartbeat` (latest-value only), `GET …/directive`.

## Acceptance thresholds (GB200, revised in 1.3)

Sources: **[G]** NVIDIA Grace Performance Tuning Guide, "Basic System Health
Checks"; **[P]** NVIDIA product specifications; **[F]** field reports or
policy. Every check is emitted by the agent with the limit it applied, and
the report rolls results up across the 18 trays, so these values live only
in `AcceptanceCriteria` / `config.yaml.j2`.

| Criterion (per tray unless noted) | 1.1 | 1.3 | Basis |
|---|---|---|---|
| STREAM Triad, per Grace, 72 threads | ≥ 900 GB/s | ≥ 307 GB/s (480 GB Grace), ≥ 400 GB/s (120 GB); other sizes fail closed unless set | [G] reference minimums; 900 exceeded Grace's ~512 GB/s peak |
| STREAM cross-socket (Grace↔Grace cNVLink), each direction | — | ≥ 100 GB/s | [G] |
| NVLink-C2C H2D, nvbandwidth CE, each GPU | ≥ 800 GB/s | ≥ 300 GB/s | [G] healthy 480 GB systems ~350–360 GB/s; 900 GB/s is bidirectional link rate |
| NVLink-C2C D2H, each GPU | — | ≥ 145 GB/s | [G] 4-GPU Grace-Blackwell systems ~170 GB/s (CEs reserved for NVLink) |
| NVLink5 P2P CE read, min pair | ≥ 900 GB/s | ≥ 630 GB/s, pre and post burn | [P] 900 GB/s/dir theoretical; [F] ~717 GB/s reported |
| NVLink5 links per GPU / per-link rate | GPU 0 only | 18 active on every GPU, each ≥ 47.5 GB/s | [P] 18 × 50 GB/s/dir |
| NVLink fabric registration | — | every GPU State=Completed, Status=Success, Bandwidth=Full; one ClusterUUID and CliqueId across all 18 trays | GB200 NMX/IMEX fabric |
| Peer consistency (C2C, P2P, STREAM) | — | no member > 10 % below tray median | [F] catches a weak part without a fleet baseline |
| gpu_burn per-GPU throughput | — | no GPU > 5 % below tray median | [F] |
| GPU thermal headroom during burn | junction ≤ 90 °C | T.Limit ≥ 5 °C (abort at 0); 90 °C junction kept as backstop | Blackwell drivers report T.Limit (°C below SW slowdown) instead of absolute limits |
| Driver / services | ≥ 560; fabricmanager | ≥ R570 (optional pinned list); nvidia-imex, nvidia-persistenced | NVIDIA GB200 NVL72 release notes list R570/R580 and IMEX on compute trays; global fabric manager runs in NMX-C on switch trays |
| NVLink CRC / replay, stress-ng, throttle, 72 h, degradation 2 % / 5 % | unchanged | unchanged | policy |
| Rack power alert (compute-tray sum) | > 210 kW | > 125 kW; < 60 kW during burn; tray < 80 % of rack median | ~120 kW rack [P]; per-tray split is an estimate |

**Still calibrate on known-good trays:** C2C and P2P floors (NVIDIA notes
SKU, IOMMU and clock sensitivity), idle temperature limits (coolant supply
dependent), Grace 90 °C cap, and the 2 % GPU throughput regression limit
(check run-to-run variance first). A 240 GB Grace has no NVIDIA STREAM
reference; set `stream_triad_min_gbs` explicitly or it fails closed.

**No rack-scale NVLink test yet.** All tests are tray-local; nothing
qualifies the 72-GPU NVLink domain (e.g. multinode nvbandwidth or nccl-tests
across 18 trays with IMEX). Fabric registration + ClusterUUID consistency is
the only rack-wide NVLink check in 1.3.

## Repository Layout

```
nvl72-burnin/
├── agent/                       # Rack-side Python daemon
│   ├── burnin_agent/
│   │   ├── config.py            # Config loader (YAML + env overrides)
│   │   ├── telemetry.py         # GPU/CPU/coolant/power collection + Prometheus
│   │   ├── abort.py             # Abort condition evaluator
│   │   ├── workloads.py         # gpu_burn / stress-ng / STREAM / HPCG manager
│   │   ├── api_client.py        # Durable ordered outbox + directive client
│   │   ├── proc.py              # Hang-safe subprocess runner
│   │   ├── agent.py             # Main agent loop / state machine
│   │   ├── main.py              # Entry point
│   │   └── phases/
│   │       └── __init__.py      # Phase 2/3/5 execution (BIP-001 §§5-8)
│   ├── requirements.txt
│   └── setup.py
│
├── orchestrator/                # Central FastAPI orchestration service
│   ├── burnin_orchestrator/
│   │   ├── main.py              # FastAPI app + lifespan
│   │   ├── config.py            # Orchestrator config
│   │   ├── models.py            # Pydantic models + RackState enum
│   │   ├── redis_store.py       # Redis-backed state machine + audit log
│   │   ├── scheduler.py         # Staggered-start scheduler
│   │   └── routers/
│   │       ├── racks.py         # Operator rack lifecycle API
│   │       ├── nodes.py         # Node agent API (events/heartbeat/directive)
│   │       ├── metrics.py       # Telemetry ingest + VictoriaMetrics forward
│   │       └── reports.py       # Acceptance report generation (JSON + PDF)
│   ├── Dockerfile
│   └── requirements.txt
│
├── grafana/
│   ├── provisioning/
│   │   ├── datasources/         # VictoriaMetrics + Loki + Orchestrator JSON API
│   │   └── dashboards/          # Auto-provisioned dashboard folder
│   └── dashboards/
│       ├── fleet_overview.json       # State distribution, power, temp heatmap
│       ├── rack_detail.json          # Per-rack GPU/CPU/coolant/NVLink detail
│       └── thermal_fleet_matrix.json # Color-coded per-rack temp timeline
│
├── prometheus/
│   └── rules/
│       └── burnin_alerts.yml    # VictoriaMetrics alerting rules (thermal/error/power)
│
├── alertmanager/
│   └── alertmanager.yml         # PagerDuty (critical) + Slack (warning) routing
│
├── ansible/
│   ├── deploy_agent.yml         # Playbook: deploy agent to rack management OS
│   └── roles/burnin_agent/
│       └── templates/
│           ├── config.yaml.j2        # Per-rack agent config
│           ├── burnin-agent.service.j2  # systemd unit
│           └── promtail.yml.j2       # Log shipping to Loki
│
└── infra/
    ├── docker-compose.yml       # Full stack: orchestrator, Redis, VM, Loki, Grafana
    └── loki-config.yml          # Loki retention and ingestion config
```

---

## Quick Start (Development / Pilot)

### 1. Start the Orchestration Stack

```bash
cd infra
cp .env.example .env          # fill in tokens and webhook URLs
docker compose up -d
```

Services will be available at:
- **Orchestrator API**: http://localhost:8000  (Swagger UI: /docs)
- **Grafana**:          http://localhost:3000  (admin / $GRAFANA_ADMIN_PASSWORD)
- **VictoriaMetrics**:  http://localhost:8428
- **AlertManager**:     http://localhost:9093

### 2. Deploy the Agent to a Rack's 18 Compute Trays

```bash
cd ansible
# inventory: one [rack_<n>] group per rack, one host per compute tray,
# group vars rack_id / power_zone (see header of deploy_agent.yml)
ansible-playbook -i inventory/racks.ini deploy_agent.yml -f 200 \
  -e orchestrator_url=https://burnin-orch.internal/api \
  -e rack_token=<AGENT_TOKEN> \
  -e facility=dc1 \
  -e cdu_api_url=https://cdu.dc1.internal
```

Note the `/api` suffix: nginx serves Grafana at `/` and the orchestrator at
`/api/`. The 1.1 example URL pointed agents at Grafana.

### 3. Register the Rack

```bash
curl -X POST http://localhost:8000/racks \
  -H "Authorization: Bearer $OPERATOR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "rack_id": "rack-001",
    "serial_number": "SN12345",
    "facility": "dc1",
    "power_zone": "zone-A",
    "bmc_ip": "10.0.1.101",
    "mgmt_ip": "10.0.2.101"
  }'
```

### 4. Submit Physical Inspection (Touch 1)

Use the Intake Portal web app or POST directly:

```bash
curl -X POST http://localhost:8000/racks/rack-001/state \
  -H "Authorization: Bearer $OPERATOR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"state": "ONBOARDING", "reason": "Physical inspection passed by tech-01"}'
```

Registration takes `node_count` (default 18) and optional `expected_nodes`
(tray hostnames). The agents then run autonomously; the orchestrator moves
the rack ONBOARDING → BOOTING → (admission) BASELINE → BURNING → VALIDATING →
PASSED. Operator commands: `POST /racks/{id}/commands {"action": "abort|hold|proceed"}`.

### 5. Monitor Progress

Open Grafana → **NVL72 Burn-In** folder → **Fleet Overview** dashboard.

---

## Scaling to Production

### Power Zone Capacity

```bash
ZONE_CAPACITY=50                       # default slots per zone
ZONE_CAPACITIES=zone-A=80,zone-B=40    # per-zone overrides
ZONE_START_INTERVAL_S=300              # admission stagger per zone
```

A rack takes a slot when admitted to BASELINE (the first full-power phase)
and holds it through VALIDATING. Racks waiting for admission hold nothing.

### Deploying Multiple Orchestrator Workers

Workers are stateless (Redis holds all state, noeviction required). One
scheduler leader is elected through a Redis lease, so any number of
workers/replicas is safe. Scale horizontally:
```yaml
# docker-compose.yml
orchestrator:
  deploy:
    replicas: 8
```

Put an L4 load balancer (HAProxy or AWS ALB) in front of the workers.

### VictoriaMetrics at Scale

Node agents are scraped by vmagent (`infra/scrape.yml`); push forwarding
through the orchestrator is off by default. Series count per rack ≈ 18 trays
× ~60 series. The 1.1 estimate below assumed one exporter per rack:
At 1,000 racks × 1,200 metrics × 2 scrapes/min ≈ 40M samples/min. VictoriaMetrics
handles this comfortably on a 6-node cluster. Update `--storageDataPath` to an
NVMe-backed volume and add `--replicationFactor=2` for HA.

---

## Acceptance Criteria Reference

See "Acceptance thresholds (GB200, revised in 1.3)" above; the 1.1 table is superseded.

---

## Human Touches Per Rack

| Touch | When | Who | Time |
|---|---|---|---|
| **Touch 1**: Physical intake inspection | INSPECTING state | Technician | ~15 min |
| **Touch 2**: Engineering sign-off | PASSED state | Engineer | ~5 min |

All other steps are executed and validated autonomously by the agent and orchestrator.
