# NVL72 Burn-In 1.1 → 1.2 Review

This review covers the whole repository. The focus areas were error handling,
broken-hardware handling, and scaling. Where this document says **verified**,
it was checked by a test in `tests/` or by running the code. Where it says
**unverified**, it depends on real GB200 hardware, tool output, or the spec,
and needs confirming on a tray.

---

## 1. Blocking defects in 1.1

These would each have stopped the system from working, or produced wrong results, on real racks.

1. **Wrong topology.** The agent ran once per rack and ran `nvidia-smi` locally, expecting 72 GPUs and 36 Grace sockets. On GB200 NVL72, each of the 18 compute trays is a separate OS that sees 4 GPUs and 2 CPUs. As a result, boot validation could never pass. STREAM was also launched on NUMA nodes 0–35, which do not exist.
   - *Fix:* the agent now runs one instance per tray (`node_id`, `topology.*`). The orchestrator aggregates the 18 node results into the rack verdict.
2. **Every burn-in aborted within about 90 seconds.** STREAM (which completes after 20 iterations) and `dcgmi health --watch/--log` (not valid dcgmi syntax) both exit quickly. The main loop treated any exited workload other than gpu_burn as `workload_died`.
   - *Fix:* STREAM now runs as a periodic sampler. DCGM health is a periodic `dcgmi health -c` check.
3. **A GPU crash produced a PASS.** `gpu_burn` was explicitly excluded from the dead-workload check. `_run_burnin()` returned `True` when the timer expired, regardless of workload state.
   - *Fix:* any long-running workload that exits before the deadline is now a failure. So is a launch failure, a `DIED` worker, or a stalled log.
4. **Fail-open telemetry.** Every collector returned `0.0` or an empty list when it errored. A GPU that fell off the bus, a hung `nvidia-smi`, or a missing `ipmitool` all read as "cool and healthy". Nothing checked GPU count during burn-in.
   - *Fix:* unknown values are now `None` with per-source errors. A required source that fails 3 consecutive polls aborts. A missing GPU aborts immediately and is named from the boot inventory.
5. **DCGM verdicts were inverted.** The code checked `"PASS" in stdout`, but DCGM prints `Pass`, so every diagnostic run failed.
   - *Fix:* results are now parsed from `-j` JSON, with a text fallback. Unparseable output is a failure.
6. **The power-zone scheduler was bypassed and could deadlock.**
   - The agent reported `BURNING` itself, so capacity was never enforced.
   - `ACTIVE_STATES` included `BASELINE`. A zone full of racks waiting for admission therefore counted as full and admitted nothing.
   - One scheduler ran per uvicorn worker per replica (4 × N), each with its own in-memory stagger clock.
   - *Fix:* there is now a single leader elected through a Redis lease. Admission is an optimistic transaction that watches the zone slot set and the stagger key. It gates the first full-power phase (`BOOTING → BASELINE`), and the slot is held through `VALIDATING`.
7. **The systemd unit starved the workloads.** `CPUQuota=10%` and `MemoryLimit=2G` apply to the whole unit cgroup, including gpu_burn, stress-ng, and STREAM. STREAM's 12 GB of static arrays would be OOM-killed. These limits are removed.
8. **Unverified: `Requires=nvidia-fabricmanager.service`.** If Fabric Manager does not run on GB200 compute trays (see §7), the agent could never start. The dependency is now `Wants`, and the service check is a named boot-validation failure.
9. **Redis could evict rack state.** It was configured with `allkeys-lru`, and the audit and alert streams were uncapped. Redis is now set to `noeviction`, the streams use `XADD MAXLEN ~`, and a startup check logs an error if the eviction policy is anything else.
10. **VictoriaMetrics would not start.** It was given `--rule` and `--notifier.url`, which are vmalert flags. vmalert is now a separate service.
11. **Unverified: STREAM would not link on aarch64.** 500M doubles × 3 arrays is 12 GB of static data, which exceeds the AArch64 small code model. The array size is now 100M (800 MB per array, well over 4× Grace L3).
12. **The orchestrator failed to start as non-root.** `REPORT_DIR.mkdir()` ran at import time under `/var/lib`. The directory is now created lazily, and the Dockerfile creates and chowns it.

## 2. Error handling

| 1.1 behaviour | 1.2 |
|---|---|
| `requests` POSTs ran in the control loop with `Retry(total=5, backoff 2.0)` and a 30 s timeout. An orchestrator outage stalled thermal and abort checks for minutes per call. | The control loop only enqueues work. A background sender delivers from a SQLite outbox. Verified by `test_enqueue_never_blocks_on_network`. |
| Non-idempotent POSTs were retried blindly. | Each event carries a UUID `event_id` and is deduplicated server-side in the same Redis transaction as the state change. Verified. |
| `_post` buffered 4xx responses, then `flush_buffer` dropped them as "sent" (`status < 500`). A rejected ABORT vanished silently. | 400/404/409/422 go to a `dead_letter` table and are logged at ERROR. 401/403 are held and alarmed. 429/5xx and network errors retry with full-jitter backoff. Verified. |
| Telemetry was buffered for 24 h and replayed in bulk by every rack after an outage. | Heartbeats are latest-value only. Only state, phase, abort, and checkpoint events are durable. Aborts jump the queue. |
| `subprocess.check_output(timeout=…)` still calls `wait()` after the kill. A child in D-state (hung GPU) blocks forever. | `proc.run_cmd` kills the process group and abandons unkillable children. Abandoned children are counted and alerted (`hung_tools`). Verified for timeout and launch failure. |
| `preexec_fn=os.setsid` was used in a multi-threaded process (deadlock risk). | Replaced with `start_new_session=True`. |
| The signal handler called `terminate_all()`, which blocks for up to 30 s per process, sequentially. | The handler only sets a flag. The main thread terminates all workloads in parallel with one bounded wait, reports `agent_stopped`, and drains the outbox. `TimeoutStopSec=120`. |
| Any-to-any state transitions were allowed, and replayed stale events could resurrect an ABORTED rack. | There is an explicit transition table. `force` is operator-only and audited. Events with a stale `run_id` return 409. Verified. |
| GET → modify → SET on the rack record, with 8+ concurrent writers. | Every mutation is WATCH/MULTI with retry. Indexes, zone slots, and audit entries are written in the same transaction. Verified with 18 concurrent node writers. |
| `record_abort` set ABORTED without updating the zone index, leaking one power slot per abort. | All state changes go through one transition path. Verified. |
| RE_RUN: `transition_state()` re-read and saved the rack, discarding the `run_count` increment. Racks were never quarantined, and RE_RUN jumped straight to BURNING. | A re-run starts a fresh run (new `run_id`, nodes cleared) in ONBOARDING, and admission happens again. Verified. |
| Commands were popped on GET, so a lost response lost an operator abort. | Commands are state (rack ABORTED or `hold`), served by an idempotent directive. |
| The hold command called `time.sleep(60)` inside the burn loop, suspending all safety checks. | Hold blocks admission and the BASELINE→BURNING step. Safety checks never pause. |
| Any agent token could WAIVE a failed rack, register racks, or abort racks. | Role separation is enforced: operator, agent, and read-only (Grafana). The orchestrator refuses to start with default, short, or identical tokens. Verified. |
| Unhandled 500 responses echoed the exception text. | Errors are mapped to proper codes (404/409/422), and the 500 body is generic. |

## 3. Broken-hardware handling

- **Continuous safety monitor.** 1.1 evaluated aborts only during Phase 4. Now a thread polls every 30 s for the agent's whole life, including the multi-hour DCGM diag and memtest runs. On abort, it kills in-flight tools and workloads immediately.
- **New abort conditions:**
  - fatal XIDs, followed via `journalctl -k -f` and mapped PCI → GPU
  - volatile uncorrectable ECC
  - HBM row-remap failure (a pending remap fails boot validation)
  - GPU missing from a successful enumeration
  - required telemetry source lost
  - unkillable tools
  - gpu_burn log not advancing for 10 minutes
  - `DIED` workers
  - HPCG `INVALID` result
- **Component attribution.** Every abort event carries `{node_id, gpu_index, uuid, serial, pci_bus_id}`. The orchestrator keeps `failed_components` per run, plus a `run_history`, so triage gets the part to pull.
- **Rack-wide stop.** When one tray aborts or fails, the rack goes to ABORTED or FAILED and the directive tells the other 17 trays to stop.
- **Lost nodes.** If a node's heartbeat is older than `NODE_STALE_S`, the rack is aborted as `node_lost:<node>`. 1.1's unit file claimed the orchestrator detected this, but nothing implemented it.
- **NVLink checks.**
  - Link state is checked on every local GPU against `nvlinks_per_gpu` (1.1 checked GPU 0 only).
  - Error counters are read in one `nvidia-smi nvlink -e` call instead of 72 sequential calls.
  - CRC is judged on the delta from burn start.
  - The pre-burn check fails when counters cannot be parsed.
- **Parser fixes.** All verified against sample output in `tests/agent/test_parsers.py`.
  - **Throttle reasons:** 1.1 compared the hex bitmask against the string `"0x00000000"`, so the 64-bit `0x0000000000000000` value (no throttling) triggered an abort. The bitmask is now decoded, and only thermal, HW-slowdown, and power-brake reasons abort.
  - **stress-ng errors:** the 1.1 regex `\bfail\b.*?(\d+)` matched the PID in `stress-ng: fail: [48213]` and never matched `failed: N`.
  - **gpu_burn throughput:** 1.1 summed every Gflop/s figure in the log, so the "baseline" grew with run length and the 2% regression check was meaningless. It now uses the median of recent aggregate samples, and adds a per-GPU regression check.
  - **PSU fault count:** "Presence detected" is no longer counted as a fault.
  - **Bandwidth matrix:** the 1.1 p2p parser matched nothing, so the result was always 0 GB/s and always FAIL. The CUDA samples path it used no longer ships with CUDA.
- **Cooldown and baselines fail closed.** They no longer accept "0 °C" from a dead sensor as idle.
- **Intake portal.** It substituted hard-coded demo coolant readings when no data was available, and defaulted missing leak data to "no leak". It now blocks submission instead.
- **Deploy preflight.** `nvidia-smi -L` must show 4 GPUs per tray, so dead GPUs are caught before the rack enters the queue.

## 4. Scaling

- **Redis access.** `KEYS rack:*` plus N sequential GETs, run on every scheduler tick and every list call, is replaced by set indexes (`racks:all`, `racks:state:*`) and chunked `MGET`. Fleet summary uses `SCARD` only.
- **Rack record contention.** Heartbeats (18,000 nodes every 30 s ≈ 600/s) and per-node phase metrics live outside the rack record, so they never contend on the rack key.
- **Scheduler.** One leader across all workers and replicas. It admits one rack per zone per tick in FIFO readiness order.
- **Agent request load.** The directive poll is 30 s while waiting and 60 s during burn (about 300 req/s for 18,000 nodes). The sender uses jittered start and backoff.
- **Metrics path.** vmagent now scrapes each tray's `:9101` (`infra/scrape.yml`). The push path is optional, authenticated, uses one shared HTTP client, and sends bounded batches off the request path. 1.1 opened a new client per request and made the agent wait on VictoriaMetrics.
- **Report rendering.** PDF generation runs in a threadpool instead of on the event loop.
- **Ansible.** `strategy: free`, and one bad tray does not fail the fleet rollout. `burnin_prebuilt_dir` avoids 18,000 GitHub clones and compiles. STREAM rebuilds when its flags change (1.1 used `creates:`, which never rebuilds). A missing STREAM source now fails with a clear message instead of `ignore_errors`.
- **Workload termination.** All workloads are signalled at once with a single bounded wait (≤35 s). 1.1 waited 30 s × N sequentially.

## 5. Other fixes

- **Alert rules.**
  - `RackAgentTelemetryStale` computed `time() - <temperature>`, so it fired permanently for every rack. It is replaced by `up == 0` and source-health alerts.
  - Added alerts for XID, ECC, missing GPUs, and hung tools.
  - Rack power is now aggregated from tray power through a recording rule, so the dashboards are unchanged.
  - The CoolantFlowLow description said 190 while the expression used 180.
- **Grafana.**
  - The JSON datasource pointed at a non-existent host (`burnin-orchestrator`).
  - The token was set under a key the plugin ignores.
  - The plugin was never installed.
- **Nginx.** Added upstream keepalive (`Connection ""`) and set `limit_req_status 429` so agents back off. Correction to an earlier assumption: the `/api` prefix *was* already stripped by `rewrite`. The actual bug was the README's agent URL, which had no `/api`, so agents hit Grafana.
- **Promtail.** It expected JSON log lines, but the agent wrote plain text. The file log is now JSON with `phase`, `rack_id`, and `node_id`.
- **Compose.** Publishing `8000:8000` with `replicas: 2` caused a port conflict. Redis no longer publishes a host port.
- **Tarball.** It contained literal directories such as `nvl72-burnin/{agent/burnin_agent/phases,orchestrator/…}`. That is `mkdir -p` with brace expansion run under `sh`. These are removed.
- **`--dry-run`.** It only shortened the duration and still launched real workloads. It is replaced by `--check-config`, which is also used as `ExecStartPre` and in the playbook.
- **Report.** Criteria that 1.1 hard-coded to PASS (duration, STREAM degradation) are now computed. Missing data shows as NO DATA, not PASS.

## 6. Tests

`pytest -c tests/pytest.ini tests` runs **109 passed** (1.1: 78/79, and the lifecycle test exercised only its own mock). The new tests cover:

- store and scheduler behaviour on fakeredis: 18 concurrent writers, capacity, stagger, deadlock regression, aborts, dedupe, stale run, re-run and quarantine, lost node, leader election
- HTTP auth and error mapping
- the agent ↔ orchestrator contract over real HTTP (uvicorn)
- full `BurninAgent.run()` end to end with stubbed hardware: PASS, gpu_burn crash → ABORTED, operator abort reaching the agent
- tool-output parsers
- fail-closed health checks
- `run_cmd` timeouts, workload death and launch failure, outbox classification

The old `integration/test_lifecycle.py` is removed. It tested a mock of the store, not the code.

## 7. Not changed — verify on hardware or in the spec

1. **The acceptance thresholds look unreachable as written.**
   - *STREAM Triad ≥ 900 GB/s per socket.* This exceeds Grace LPDDR5X peak (~512 GB/s per CPU; NVIDIA lists up to 18.4 TB/s across 36 Grace). As written, every rack fails.
   - *C2C ≥ 800 GB/s.* 900 GB/s is the bidirectional C2C figure. Any H2D or D2H measurement will be well below that.
   - *P2P ≥ 900 GB/s.* Achievable unidirectional memcpy is likely below NVLink5's 900 GB/s per-direction peak.
   - These values are left configurable and unchanged. Calibrate them against known-good trays and fix them in BIP-001.
2. **Compute-tray services.** On NVL72, the NVLink fabric is expected to be managed from the switch trays (NMX), with IMEX running on compute trays. Confirm what runs on your tray image, then set `burnin_required_services`.
3. **Tool output formats were checked against documented or sample formats, not captured from a GB200 tray.** This covers `nvidia-smi nvlink -e/-s` on NVLink5, `dcgmi diag -j` (DCGM 3 vs 4 schema), `dcgmi health -c`, the nvbandwidth testcase names, Grace thermal zone names, and gpu_burn's flush behaviour (the stall detector depends on it). All of these fail closed, so a format mismatch will show up as a clear failure on the first tray rather than a false pass. Capture real output and add it to `tests/agent/test_parsers.py`.
4. **No rack-scale NVLink test exists.** Every test is tray-local, and gpu_burn does not generate NVLink traffic. Nothing qualifies the 72-GPU NVLink domain. Recommendation: an orchestrator-coordinated step between BASELINE and BURNING that runs nccl-tests across all 18 trays with IMEX, plus NVLink traffic during burn.
5. **XID fatal list.** Review it against NVIDIA's XID catalog for the deployed driver branch.
6. **Security still open.** Tokens are shared, not per rack, and there is no mTLS. The intake portal needs the operator token in the browser.
7. **S3 artifact upload is not implemented, in 1.1 or here.** Result bundles stay on the tray under `/var/lib/burnin-agent/artifacts`.
8. **CLI (`cli/bio.py`).** It has not been updated for `force` transitions or per-node views. Its existing calls still work.

---

# 1.3 — GB200 acceptance thresholds

The threshold table and its sources are in README.md, under "Acceptance thresholds". Code changes:

- **Where thresholds live.**
  - `AcceptanceCriteria` holds the GB200 defaults, and each default is annotated with its source.
  - The agent emits every check as `criteria` together with the limit it applied.
  - `reports.rollup_criteria` combines those checks across the 18 trays. A row passes only if all 18 trays reported the check and every one passed.
  - The report no longer hard-codes any threshold.
- **STREAM.**
  - Thresholds are keyed by the LPDDR5X capacity detected on each NUMA node.
  - A cross-socket (cNVLink) check has been added.
  - The binary is built per NVIDIA's recipe: `-Ofast -mcpu=neoverse-v2`, 120M elements, 200 iterations.
- **C2C.** Both H2D and D2H are measured, and each GPU is checked against both an absolute floor and its peers on the same tray.
- **NVLink.**
  - Per-link speed is now checked, not only whether the link is up.
  - The P2P test is repeated after burn-in.
  - Every GPU must show fabric registration State=Completed and Status=Success, with Health Bandwidth=Full where reported.
  - All 18 trays must report the same ClusterUUID and CliqueId. This rack-level check runs in the orchestrator.
- **Thermal.**
  - T.Limit is collected (`temperature.gpu.tlimit`, falling back tier by tier on older drivers).
  - The agent aborts at T.Limit ≤ 0.
  - Acceptance requires a minimum T.Limit ≥ 5 °C during burn-in.
- **Driver and services.** The minimum driver is R570, with an optional qualified-version list. Compute trays now require `nvidia-imex` and `nvidia-persistenced` instead of `nvidia-fabricmanager`.
- **Alerts.**
  - The rack power limits are revised.
  - New alerts: tray under-load relative to its peers, and GPU near thermal slowdown.
- **Tests.** 120 pass. New coverage: threshold sanity, capacity mapping, fabric parsing, T.Limit abort, peer outliers, criteria roll-up, and the rack failing on a fabric UUID mismatch.

**Unverified on hardware:**
- The `temperature.gpu.tlimit` query field name.
- The exact layout of the `nvidia-smi -q` Fabric section, including whether Health › Bandwidth is present on your driver.
- The nvbandwidth D2D matrix for 4 local GPUs.

All three fail closed or fall back: a missing T.Limit falls back to the 90 °C cap, and a missing Fabric section fails boot validation. Capture real tray output and add it to the parser tests.
