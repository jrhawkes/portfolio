"""
burnin_agent/abort.py
Evaluates abort conditions against the latest telemetry snapshot.
Runs synchronously in the control loop so it acts within one poll interval,
regardless of network connectivity.

Two layers:
  evaluate()       threshold checks on values that were actually measured.
  HealthTracker    fail-closed checks: missing GPUs, sources that keep failing,
                   fatal XIDs, uncorrectable ECC / row-remap failure, and
                   tools hanging in the kernel. An unknown reading is not a
                   safe reading.

Every AbortEvent carries a `component` dict (node, GPU index/UUID/serial/PCI
where known) so triage gets the part to replace, not just "rack aborted".
"""

from __future__ import annotations

import logging
from dataclasses import asdict, dataclass, field
from typing import Dict, Iterable, List, Optional

from .config import AbortThresholds
from .telemetry import BENIGN_THROTTLE, GpuSnapshot, TelemetrySnapshot

log = logging.getLogger(__name__)


@dataclass
class AbortEvent:
    condition: str
    measured: float
    threshold: float
    unit: str = ""
    message: str = ""
    component: Dict[str, object] = field(default_factory=dict)

    def __post_init__(self):
        if not self.message:
            self.message = (
                f"ABORT: {self.condition} = {self.measured}{self.unit} "
                f"exceeded threshold {self.threshold}{self.unit}"
            )

    def to_dict(self) -> dict:
        return asdict(self)


def _gpu_component(g: GpuSnapshot, node_id: str = "") -> Dict[str, object]:
    return {"type": "gpu", "node_id": node_id, "gpu_index": g.index,
            "uuid": g.uuid, "serial": g.serial, "pci_bus_id": g.pci_bus_id}


def evaluate(snap: TelemetrySnapshot, thresholds: AbortThresholds,
             gpu_burn_errors: int = 0,
             stressng_errors: int = 0,
             nvlink_crc_baseline: Optional[Dict[int, int]] = None) -> List[AbortEvent]:
    """
    Threshold checks. Values that are None (unknown) are skipped here; the
    HealthTracker is responsible for turning persistent unknowns into aborts.
    If nvlink_crc_baseline is given, CRC is judged on the increase since the
    baseline (per GPU) instead of the absolute counter.
    """
    events: List[AbortEvent] = []
    node = snap.node_id

    for g in snap.gpus:
        comp = _gpu_component(g, node)
        if g.junction_temp_c is not None and g.junction_temp_c > thresholds.gpu_junction_max_c:
            events.append(AbortEvent(f"gpu_{g.index}_junction_temp", g.junction_temp_c,
                                     thresholds.gpu_junction_max_c, "°C", component=comp))
        if g.tlimit_c is not None and g.tlimit_c <= thresholds.gpu_tlimit_abort_c:
            events.append(AbortEvent(f"gpu_{g.index}_tlimit", g.tlimit_c,
                                     thresholds.gpu_tlimit_abort_c, "°C",
                                     message=(f"ABORT: GPU {g.index} T.Limit {g.tlimit_c}°C "
                                              f"(at/over SW thermal slowdown)"),
                                     component=comp))
        if g.hbm_temp_c is not None and g.hbm_temp_c > thresholds.gpu_hbm_max_c:
            events.append(AbortEvent(f"gpu_{g.index}_hbm_temp", g.hbm_temp_c,
                                     thresholds.gpu_hbm_max_c, "°C", component=comp))

    for c in snap.cpus:
        if c.temp_c is not None and c.temp_c > thresholds.grace_cpu_max_c:
            events.append(AbortEvent(f"cpu_socket_{c.socket}_temp", c.temp_c,
                                     thresholds.grace_cpu_max_c, "°C",
                                     component={"type": "cpu", "node_id": node, "socket": c.socket}))

    cool = snap.coolant
    if cool.outlet_temp_c is not None and cool.outlet_temp_c > thresholds.coolant_outlet_max_c:
        events.append(AbortEvent("coolant_outlet_temp", cool.outlet_temp_c,
                                 thresholds.coolant_outlet_max_c, "°C",
                                 component={"type": "coolant", "node_id": node}))
    if cool.inlet_temp_c is not None and cool.inlet_temp_c > thresholds.coolant_inlet_max_c:
        events.append(AbortEvent("coolant_inlet_temp", cool.inlet_temp_c,
                                 thresholds.coolant_inlet_max_c, "°C",
                                 component={"type": "coolant", "node_id": node}))

    # NVLink CRC (zero tolerance), per GPU so the event names the GPU.
    crc_total = 0
    worst: Optional[GpuSnapshot] = None
    for g in snap.gpus:
        if g.nvlink_crc_errors is None:
            continue
        base = (nvlink_crc_baseline or {}).get(g.index, 0)
        delta = max(0, g.nvlink_crc_errors - base)
        crc_total += delta
        if delta and (worst is None or delta > (worst.nvlink_crc_errors or 0) - base):
            worst = g
    if crc_total > thresholds.nvlink_crc_errors_max:
        events.append(AbortEvent("nvlink_crc_errors_total", float(crc_total),
                                 float(thresholds.nvlink_crc_errors_max), " errors",
                                 component=_gpu_component(worst, node) if worst else {"node_id": node}))

    for g in snap.gpus:
        bad = [r for r in g.throttle_reasons if r not in BENIGN_THROTTLE]
        if bad:
            events.append(AbortEvent(f"gpu_{g.index}_throttle", 1.0, 0.0,
                                     message=f"ABORT: GPU {g.index} throttling due to: {bad}",
                                     component=_gpu_component(g, node)))

    psu = snap.power.psu_fault_count
    if psu is not None and psu > thresholds.psu_fault_max:
        events.append(AbortEvent("psu_fault_count", float(psu), float(thresholds.psu_fault_max),
                                 " faults", component={"type": "psu", "node_id": node}))

    if gpu_burn_errors > thresholds.gpu_burn_errors_max:
        events.append(AbortEvent("gpu_burn_errors", float(gpu_burn_errors),
                                 float(thresholds.gpu_burn_errors_max), " errors",
                                 message=f"ABORT: gpu_burn reported {gpu_burn_errors} checksum errors",
                                 component={"type": "gpu", "node_id": node}))
    if stressng_errors > thresholds.stressng_errors_max:
        events.append(AbortEvent("stressng_errors", float(stressng_errors),
                                 float(thresholds.stressng_errors_max), " errors",
                                 message=f"ABORT: stress-ng reported {stressng_errors} errors",
                                 component={"type": "cpu", "node_id": node}))

    for ev in events:
        log.error(ev.message)
    return events


class HealthTracker:
    """
    Stateful fail-closed checks across polls.

    - A required source failing `telemetry_fail_cycles` polls in a row aborts.
    - A GPU that disappears from a *successful* nvidia-smi enumeration aborts
      immediately and is named from the boot-time inventory.
    - Fatal XIDs, uncorrectable ECC above threshold, row-remap failure, and
      repeated kernel-hung tool invocations abort immediately.
    """

    def __init__(self, thresholds: AbortThresholds, required_sources: Iterable[str],
                 expected_gpus: int, node_id: str = ""):
        self.t = thresholds
        self.required = set(required_sources)
        self.expected_gpus = expected_gpus
        self.node_id = node_id
        self.fail_streak: Dict[str, int] = {}
        self.inventory: Dict[str, Dict[str, object]] = {}   # uuid -> component

    def set_inventory(self, gpus: List[GpuSnapshot]):
        self.inventory = {g.uuid: _gpu_component(g, self.node_id) for g in gpus if g.uuid}

    def evaluate(self, snap: TelemetrySnapshot) -> List[AbortEvent]:
        events: List[AbortEvent] = []
        node = self.node_id or snap.node_id

        # 1. Persistent source failures.
        for src in self.required:
            if src in snap.source_errors:
                self.fail_streak[src] = self.fail_streak.get(src, 0) + 1
            else:
                self.fail_streak[src] = 0
            n = self.fail_streak[src]
            if n >= self.t.telemetry_fail_cycles:
                events.append(AbortEvent(
                    f"telemetry_lost_{src}", float(n), float(self.t.telemetry_fail_cycles),
                    " polls",
                    message=(f"ABORT: required telemetry source '{src}' failed {n} consecutive "
                             f"polls: {snap.source_errors.get(src)}"),
                    component={"type": "telemetry", "node_id": node, "source": src}))

        # 2. GPUs missing from a completed enumeration (fell off the bus).
        gpu_err = snap.source_errors.get("gpu", "")
        enumeration_ran = (bool(snap.gpus) or "visible, expected" in gpu_err
                           or "no devices were found" in gpu_err.lower())
        if enumeration_ran and len(snap.gpus) < self.expected_gpus:
            seen = {g.uuid for g in snap.gpus}
            missing = [c for u, c in self.inventory.items() if u not in seen]
            events.append(AbortEvent(
                "gpu_missing", float(len(snap.gpus)), float(self.expected_gpus), " GPUs",
                message=(f"ABORT: {len(snap.gpus)}/{self.expected_gpus} GPUs visible; "
                         f"missing {[m.get('serial') or m.get('uuid') for m in missing] or 'unknown'}"),
                component=(missing[0] if len(missing) == 1 else
                           {"type": "gpu", "node_id": node, "missing": missing})))

        # 3. Fatal XIDs.
        by_index = {g.index: g for g in snap.gpus}
        for ev in snap.xid_events:
            if ev.xid in self.t.xid_fatal:
                g = by_index.get(ev.gpu_index) if ev.gpu_index is not None else None
                comp = _gpu_component(g, node) if g else {
                    "type": "gpu", "node_id": node, "pci_bus_id": ev.pci_bus_id}
                events.append(AbortEvent(
                    f"xid_{ev.xid}", float(ev.xid), 0.0,
                    message=f"ABORT: fatal XID {ev.xid} on PCI {ev.pci_bus_id}: {ev.message}",
                    component=comp))

        # 4. Memory health.
        for g in snap.gpus:
            if g.ecc_dbe_volatile is not None and g.ecc_dbe_volatile > self.t.ecc_dbe_max:
                events.append(AbortEvent(f"gpu_{g.index}_ecc_dbe", float(g.ecc_dbe_volatile),
                                         float(self.t.ecc_dbe_max), " errors",
                                         component=_gpu_component(g, node)))
            if g.remap_failure:
                events.append(AbortEvent(f"gpu_{g.index}_row_remap_failure", 1.0, 0.0,
                                         message=f"ABORT: GPU {g.index} HBM row-remap failure",
                                         component=_gpu_component(g, node)))

        # 5. Tools stuck in the kernel.
        if snap.abandoned_children >= self.t.hung_tool_max:
            events.append(AbortEvent(
                "hung_tools", float(snap.abandoned_children), float(self.t.hung_tool_max),
                message=(f"ABORT: {snap.abandoned_children} tool invocations stuck in the kernel "
                         f"(unkillable); GPU or driver hang suspected"),
                component={"type": "node", "node_id": node}))

        for ev in events:
            log.error(ev.message)
        return events
