"""
burnin_agent/config.py
Configuration loader for the NVL72 burn-in node agent.

TOPOLOGY NOTE (changed in 1.2): a GB200 NVL72 rack is 18 compute trays, each
running its own OS with 4 Blackwell GPUs and 2 Grace CPUs. nvidia-smi, DCGM,
sysfs and the tray BMC on any one OS only see that tray. The agent therefore
runs once per compute tray ("node") and the orchestrator aggregates the 18
node results into the rack verdict. Per-node expectations live in
`topology`; rack-level sensors (CDU coolant) are collected only by the node
flagged `is_rack_leader`.

Settings are read from /etc/burnin-agent/config.yaml, with environment
variable overrides prefixed with BURNIN_.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Dict, List

import yaml

log = logging.getLogger(__name__)

CONFIG_PATH = Path(os.environ.get("BURNIN_CONFIG", "/etc/burnin-agent/config.yaml"))


@dataclass
class OrchestratorConfig:
    url: str = "https://burnin-orch.internal/api"
    token: str = ""
    timeout_s: int = 10                 # per request; the control loop never waits on it
    backoff_initial_s: float = 2.0
    backoff_max_s: float = 300.0        # full-jitter cap; avoids fleet-wide retry storms
    # Durable (state/phase/abort) events are kept this long if undeliverable.
    offline_buffer_hours: int = 96
    # Poll interval for the directive endpoint while waiting for admission.
    directive_poll_s: int = 30
    # During the 72 h burn the directive is only needed for rack-wide aborts;
    # 18,000 nodes at 60 s is ~300 req/s fleet-wide.
    directive_poll_burn_s: int = 60
    # How long to wait for scheduler admission before giving up.
    admission_timeout_h: float = 48.0
    ca_bundle: str = ""                 # optional private CA for TLS verification


@dataclass
class TopologyConfig:
    nodes_per_rack: int = 18
    gpus_per_node: int = 4
    grace_sockets_per_node: int = 2
    nvlinks_per_gpu: int = 18           # NVLink5: 18 links x 50 GB/s/dir per Blackwell GPU


@dataclass
class TelemetryConfig:
    poll_interval_s: int = 30
    collect_timeout_s: int = 20         # per-source hard timeout
    metrics_port: int = 9101
    coolant_api_url: str = ""           # CDU REST API endpoint (facility-specific)
    coolant_api_token: str = ""
    coolant_from_ipmi: bool = False     # fall back to tray BMC coolant sensors
    # Regex matched against /sys/class/thermal/thermal_zone*/type to find Grace
    # CPU sensors. Zones are assigned to sockets in sorted order. Verify on the
    # target OS image: `grep . /sys/class/thermal/thermal_zone*/type`.
    cpu_thermal_zone_regex: str = r"(?i)(grace|cpu|soc)"
    xid_source: str = "journal"         # journal | none
    # Sources whose failure counts toward the fail-closed abort. "coolant" is
    # added automatically on the rack leader, "xid" when xid_source != none.
    required_sources: List[str] = field(default_factory=lambda: ["gpu", "cpu", "nvlink", "power"])


@dataclass
class AbortThresholds:
    gpu_junction_max_c: float = 90.0
    gpu_hbm_max_c: float = 95.0
    grace_cpu_max_c: float = 90.0
    nvswitch_max_c: float = 95.0
    coolant_outlet_max_c: float = 60.0
    coolant_inlet_max_c: float = 50.0
    gpu_burn_errors_max: int = 0
    stressng_errors_max: int = 0
    nvlink_crc_errors_max: int = 0      # applied to the delta since burn-in start
    psu_fault_max: int = 0
    ecc_dbe_max: int = 0                # volatile uncorrectable ECC, any GPU
    # Abort when a GPU's T.Limit (degrees below SW thermal slowdown) drops to
    # this value. Blackwell drivers report T.Limit; absolute caps above are
    # the fallback when it is unavailable.
    gpu_tlimit_abort_c: float = 0.0
    # Fail-closed policy: a required telemetry source that fails this many
    # consecutive polls is treated as an abort. Unknown != safe.
    telemetry_fail_cycles: int = 3
    # Kernel-hung tool invocations (abandoned children) before abort.
    hung_tool_max: int = 2
    # gpu_burn log not advancing for this long => GPU/driver hang.
    workload_stall_s: int = 600
    # XIDs treated as hardware-fatal. Verify against the XID catalog for the
    # deployed driver branch; everything else is logged and counted.
    xid_fatal: List[int] = field(default_factory=lambda: [
        48, 61, 62, 64, 74, 79, 92, 95, 119, 120, 140,
    ])


@dataclass
class WorkloadConfig:
    gpu_burn_path: str = "/opt/burnin/gpu_burn"
    stream_binary: str = "/opt/burnin/stream_grace"
    hpcg_binary: str = "/opt/burnin/xhpcg"
    stress_ng_binary: str = "/usr/bin/stress-ng"
    burnin_duration_s: int = 259_200    # 72 hours
    gpu_burn_mem_pct: int = 95
    stream_timeout_s: int = 300
    stream_interval_s: int = 1800       # periodic STREAM sample during burn-in
    hpcg_nx: int = 256
    hpcg_ny: int = 256
    hpcg_nz: int = 256
    enable_hpcg: bool = True
    baseline_gpu_burn_s: int = 900
    # Deprecated rack-wide fields (1.1); ignored, see topology.
    grace_socket_count: int = 0
    expected_gpu_count: int = 0


@dataclass
class ToolsConfig:
    """External command lines. Kept in config so a tool/driver change is a
    config push, not a code release."""
    dcgm_diag_cmd: List[str] = field(default_factory=lambda: ["dcgmi", "diag", "-r", "3", "-j"])
    dcgm_diag_timeout_s: int = 7200
    memtest_cmd: List[str] = field(default_factory=lambda: ["dcgmi", "diag", "-r", "memtest", "-j"])
    memtest_timeout_s: int = 14400
    dcgm_health_group: int = 0
    # Node-local GPU<->GPU bandwidth. nvbandwidth replaced the CUDA samples
    # p2pBandwidthLatencyTest, which no longer ships under /usr/local/cuda.
    p2p_cmd: List[str] = field(default_factory=lambda: [
        "/opt/burnin/nvbandwidth", "-t", "device_to_device_memcpy_read_ce"])
    p2p_timeout_s: int = 600
    c2c_cmd: List[str] = field(default_factory=lambda: [
        "/opt/burnin/nvbandwidth", "-t", "host_to_device_memcpy_ce"])
    c2c_d2h_cmd: List[str] = field(default_factory=lambda: [
        "/opt/burnin/nvbandwidth", "-t", "device_to_host_memcpy_ce"])
    c2c_timeout_s: int = 600
    require_c2c_test: bool = True       # missing tool fails the phase (fail-closed)
    # GB200 compute trays run the driver + IMEX; the global fabric manager
    # runs in NMX-C on the NVLink switch trays, not on compute trays.
    required_services: List[str] = field(default_factory=lambda: [
        "nvidia-imex", "nvidia-persistenced"])
    # NVIDIA-qualified GB200 NVL72 branches are R570 and R580.
    min_driver_major: int = 570
    qualified_driver_versions: List[str] = field(default_factory=list)  # empty = any >= min
    # GPU fabric registration (nvidia-smi -q "Fabric"): all GPUs must be
    # State=Completed / Status=Success; Health Bandwidth must be Full if reported.
    require_fabric_registration: bool = True


@dataclass
class AcceptanceCriteria:
    """
    GB200 NVL72 acceptance criteria (BIP-001 §9, revised in 1.3). Values are
    per node (compute tray); the orchestrator rolls them up per rack.

    Sources (see README "Acceptance thresholds"):
      [G] NVIDIA Grace Performance Tuning Guide, "Basic System Health Checks"
      [P] NVIDIA product specs: NVLink5 1.8 TB/s bidirectional per GPU
          (900 GB/s per direction, 18 links); NVLink-C2C 900 GB/s bidirectional
      [F] field reports / policy; calibrate on known-good trays
    """
    # ── Memory bandwidth (Grace LPDDR5X) ─────────────────────────────────
    # [G] STREAM TRIAD minimum, 72 threads per Grace, keyed by LPDDR5X
    # capacity per Grace (GB). The 1.1 value (900 GB/s per socket) exceeded
    # Grace's ~512 GB/s theoretical peak; every rack would have failed.
    stream_triad_min_gbs_by_capacity: Dict[int, float] = field(
        default_factory=lambda: {120: 400.0, 480: 307.0})
    stream_triad_min_gbs: float = 0.0          # >0 overrides the table
    # [G] Grace<->Grace over cNVLink inside a tray: STREAM with CPUs on one
    # socket and memory on the other, each direction.
    stream_cross_socket_min_gbs: float = 100.0
    stream_degradation_max_pct: float = 5.0    # [F] policy
    # ── NVLink-C2C (Grace <-> Blackwell), nvbandwidth CE, per GPU ────────
    # [G] 480 GB systems: healthy H2D ~350-360 GB/s; D2H on 4-GPU Grace-
    # Blackwell systems ~170 GB/s (CEs reserved for NVLink). 900 GB/s is the
    # bidirectional link rate and is not a memcpy target (1.1 used 800).
    c2c_h2d_min_gbs: float = 300.0
    c2c_d2h_min_gbs: float = 145.0
    # ── NVLink5 GPU<->GPU (through NVSwitch trays), nvbandwidth CE read ──
    # [P] 900 GB/s per direction theoretical; [F] ~717 GB/s reported for a
    # memcpy on GB200 (~80%). Floor ~70% of theoretical. 1.1 used 900.
    nvlink_p2p_min_gbs: float = 630.0
    nvlink_link_min_gbs: float = 47.5          # per link: 50 GB/s nominal x 0.95 [P]
    # ── Peer consistency (catches one weak part without a fleet baseline) ─
    peer_deviation_max_pct: float = 10.0       # C2C, P2P, STREAM vs tray median [F]
    gpu_throughput_peer_deviation_max_pct: float = 5.0
    # ── Errors ────────────────────────────────────────────────────────────
    nvlink_crc_errors_max: int = 0
    nvlink_replay_errors_per_gpu_max: int = 1_000
    stressng_errors_max: int = 0
    thermal_throttle_events_max: int = 0
    cpu_freq_throttle_events_max: int = 0
    # ── Thermal ───────────────────────────────────────────────────────────
    # Blackwell drivers report T.Limit = degrees below SW slowdown instead of
    # absolute limits. Acceptance: never closer than this to slowdown.
    gpu_tlimit_min_margin_c: float = 5.0
    # Absolute caps used only when T.Limit is unavailable, and as a backstop.
    gpu_junction_peak_max_c: float = 90.0
    grace_cpu_peak_max_c: float = 90.0
    # Idle limits depend on facility coolant supply; set per site.
    idle_gpu_junction_max_c: float = 50.0
    idle_cpu_max_c: float = 55.0
    # ── Duration / regression ─────────────────────────────────────────────
    burnin_duration_min_s: int = 259_200
    gpu_throughput_degradation_max_pct: float = 2.0
    # ── 1.1 fields (ignored) ──────────────────────────────────────────────
    c2c_bandwidth_min_gbs: float = 0.0
    gpu_count_expected: int = 0
    grace_socket_count_expected: int = 0


@dataclass
class AgentConfig:
    rack_id: str = ""
    node_id: str = ""                   # e.g. compute tray hostname or slot "ct03"
    is_rack_leader: bool = False        # collects rack-level sensors (CDU)
    facility: str = ""
    run_id: str = ""                    # assigned by orchestrator directive
    artifact_bucket: str = "s3://burnin-artifacts"
    log_level: str = "INFO"
    log_dir: str = "/var/log/burnin-agent"
    state_dir: str = "/var/lib/burnin-agent"
    checkpoint_intervals_h: list = field(default_factory=lambda: [1, 4, 12, 24, 48, 72])
    orchestrator: OrchestratorConfig = field(default_factory=OrchestratorConfig)
    topology: TopologyConfig = field(default_factory=TopologyConfig)
    telemetry: TelemetryConfig = field(default_factory=TelemetryConfig)
    abort: AbortThresholds = field(default_factory=AbortThresholds)
    workload: WorkloadConfig = field(default_factory=WorkloadConfig)
    tools: ToolsConfig = field(default_factory=ToolsConfig)
    acceptance: AcceptanceCriteria = field(default_factory=AcceptanceCriteria)

    def validate(self) -> List[str]:
        """Return a list of fatal configuration problems (empty = OK)."""
        errs: List[str] = []
        if not self.rack_id:
            errs.append("rack_id is not set (BURNIN_RACK_ID)")
        if not self.node_id:
            errs.append("node_id is not set (BURNIN_NODE_ID)")
        if not self.orchestrator.token:
            errs.append("orchestrator.token is not set (BURNIN_ORCH_TOKEN)")
        if not self.orchestrator.url.startswith(("http://", "https://")):
            errs.append(f"orchestrator.url is not an http(s) URL: {self.orchestrator.url!r}")
        t = self.topology
        for name in ("nodes_per_rack", "gpus_per_node", "grace_sockets_per_node"):
            if getattr(t, name) <= 0:
                errs.append(f"topology.{name} must be > 0")
        if self.is_rack_leader and not (self.telemetry.coolant_api_url
                                        or self.telemetry.coolant_from_ipmi):
            errs.append("rack leader needs telemetry.coolant_api_url or coolant_from_ipmi")
        if self.telemetry.poll_interval_s < 5:
            errs.append("telemetry.poll_interval_s must be >= 5")
        if self.telemetry.collect_timeout_s >= self.telemetry.poll_interval_s * 2:
            errs.append("telemetry.collect_timeout_s should be < 2x poll_interval_s")
        if self.abort.telemetry_fail_cycles < 1:
            errs.append("abort_thresholds.telemetry_fail_cycles must be >= 1")
        if self.workload.burnin_duration_s < self.acceptance.burnin_duration_min_s:
            log.warning("workload.burnin_duration_s (%d) < acceptance minimum (%d): "
                        "runs will fail the duration criterion",
                        self.workload.burnin_duration_s, self.acceptance.burnin_duration_min_s)
        if self.workload.expected_gpu_count or self.workload.grace_socket_count:
            log.warning("workload.expected_gpu_count / grace_socket_count are rack-wide 1.1 "
                        "settings and are ignored; use topology.gpus_per_node / "
                        "grace_sockets_per_node")
        return errs


_SECTIONS = {
    "orchestrator": "orchestrator",
    "topology": "topology",
    "telemetry": "telemetry",
    "abort_thresholds": "abort",
    "workload": "workload",
    "tools": "tools",
    "acceptance_criteria": "acceptance",
}

_TOP_LEVEL = ("rack_id", "node_id", "is_rack_leader", "facility", "run_id",
              "artifact_bucket", "log_level", "log_dir", "state_dir",
              "checkpoint_intervals_h")


def _coerce(cur, val, where: str):
    """Coerce a YAML/env value to the type of the default, loudly."""
    if isinstance(cur, bool):
        if isinstance(val, bool):
            return val
        s = str(val).strip().lower()
        if s in ("1", "true", "yes", "on"):
            return True
        if s in ("0", "false", "no", "off"):
            return False
        raise ValueError(f"{where}: expected bool, got {val!r}")
    if isinstance(cur, int) and not isinstance(cur, bool):
        return int(val)
    if isinstance(cur, float):
        return float(val)
    if isinstance(cur, list):
        if isinstance(val, str):
            return [v for v in val.split()]
        return list(val)
    return val if val is None else (str(val) if isinstance(cur, str) else val)


def _apply(obj, data: Dict, section: str):
    if not isinstance(data, dict):
        raise ValueError(f"config section {section!r} must be a mapping")
    known = {f.name for f in fields(obj)}
    for k, v in data.items():
        if k not in known:
            log.warning("Unknown config key %s.%s (ignored)", section, k)
            continue
        setattr(obj, k, _coerce(getattr(obj, k), v, f"{section}.{k}"))


def load_config(path: Path = CONFIG_PATH) -> AgentConfig:
    """Load configuration from YAML file, applying env var overrides.
    Raises ValueError on malformed values (fail fast at startup)."""
    cfg = AgentConfig()

    if path.exists():
        with open(path) as fh:
            raw = yaml.safe_load(fh) or {}
        for key in _TOP_LEVEL:
            if key in raw:
                setattr(cfg, key, _coerce(getattr(cfg, key), raw[key], key))
        for yaml_key, attr in _SECTIONS.items():
            if yaml_key in raw and raw[yaml_key] is not None:
                _apply(getattr(cfg, attr), raw[yaml_key], yaml_key)
    else:
        log.warning("Config file %s not found; using defaults + environment", path)

    env_map = {
        "BURNIN_RACK_ID":       ("rack_id",           cfg),
        "BURNIN_NODE_ID":       ("node_id",           cfg),
        "BURNIN_RACK_LEADER":   ("is_rack_leader",    cfg),
        "BURNIN_FACILITY":      ("facility",          cfg),
        "BURNIN_RUN_ID":        ("run_id",            cfg),
        "BURNIN_ORCH_URL":      ("url",               cfg.orchestrator),
        "BURNIN_ORCH_TOKEN":    ("token",             cfg.orchestrator),
        "BURNIN_METRICS_PORT":  ("metrics_port",      cfg.telemetry),
        "BURNIN_COOLANT_URL":   ("coolant_api_url",   cfg.telemetry),
        "BURNIN_COOLANT_TOKEN": ("coolant_api_token", cfg.telemetry),
    }
    for env_key, (attr, obj) in env_map.items():
        val = os.environ.get(env_key)
        if val is not None:
            setattr(obj, attr, _coerce(getattr(obj, attr), val, env_key))

    return cfg
