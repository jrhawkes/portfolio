#!/usr/bin/env python3
"""
burnin_agent/main.py
Entry point for the NVL72 burn-in node agent (one per compute tray).
Invoked by systemd: ExecStart=/opt/burnin-agent/venv/bin/python -m burnin_agent.main
Exit codes: 0 node passed, 1 node failed/aborted, 2 agent error, 3 bad config.
"""

import argparse
import json
import logging
import sys
import time
from pathlib import Path

from .config import load_config

AGENT_VERSION = "1.3.0"


class JsonFormatter(logging.Formatter):
    """One JSON object per line; matches the promtail pipeline (levelname,
    name, message, phase)."""

    def __init__(self, rack_id: str, node_id: str):
        super().__init__()
        self.rack_id, self.node_id = rack_id, node_id

    def format(self, record):
        from .agent import CURRENT_PHASE
        d = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created)),
             "levelname": record.levelname, "name": record.name,
             "message": record.getMessage(), "phase": CURRENT_PHASE.get("phase", ""),
             "rack_id": self.rack_id, "node_id": self.node_id}
        if record.exc_info:
            d["exc"] = self.formatException(record.exc_info)
        return json.dumps(d)


def configure_logging(cfg):
    level = getattr(logging, cfg.log_level.upper(), logging.INFO)
    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(logging.Formatter("%(asctime)s %(levelname)-8s [%(name)s] %(message)s"))
    handlers = [stream]
    try:
        Path(cfg.log_dir).mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(Path(cfg.log_dir) / "agent.log", mode="a")
        fh.setFormatter(JsonFormatter(cfg.rack_id, cfg.node_id))
        handlers.append(fh)
    except OSError as exc:
        print(f"WARNING: cannot write {cfg.log_dir}/agent.log ({exc}); journal only",
              file=sys.stderr)
    logging.basicConfig(level=level, handlers=handlers, force=True)
    for lib in ("urllib3", "requests", "charset_normalizer"):
        logging.getLogger(lib).setLevel(logging.WARNING)


def main():
    parser = argparse.ArgumentParser(description="NVL72 Burn-In Node Agent")
    parser.add_argument("--config", default="/etc/burnin-agent/config.yaml")
    parser.add_argument("--log-level", default=None)
    parser.add_argument("--check-config", action="store_true",
                        help="Validate configuration and exit")
    args = parser.parse_args()

    try:
        cfg = load_config(Path(args.config))
    except (ValueError, TypeError, OSError) as exc:
        print(f"FATAL: invalid configuration: {exc}", file=sys.stderr)
        sys.exit(3)
    if args.log_level:
        cfg.log_level = args.log_level
    configure_logging(cfg)
    log = logging.getLogger(__name__)

    errors = cfg.validate()
    if errors:
        for e in errors:
            log.error("Config error: %s", e)
        sys.exit(3)
    if args.check_config:
        log.info("Configuration OK")
        sys.exit(0)

    log.info("NVL72 Burn-In Agent v%s | rack=%s node=%s facility=%s",
             AGENT_VERSION, cfg.rack_id, cfg.node_id, cfg.facility)
    from .agent import BurninAgent
    sys.exit(BurninAgent(cfg).run())


if __name__ == "__main__":
    main()
