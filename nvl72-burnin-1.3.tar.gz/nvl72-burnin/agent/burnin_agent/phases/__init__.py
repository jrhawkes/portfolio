"""
burnin_agent/phases/__init__.py
Phase execution implementing BIP-001 Rev 1.1 §§5-8, per compute tray.

Each phase returns (passed, metrics). metrics["criteria"] lists every
acceptance check as {id, desc, measured, limit, op, passed, detail}; the
orchestrator report rolls these up across the 18 nodes, so thresholds live
in exactly one place (AcceptanceCriteria) instead of being re-hard-coded in
the report as in 1.1.

Rules applied throughout (1.2):
  * Fail closed: a tool that is missing, times out, or produces output we
    cannot parse is a phase FAILURE with a reason, never a silent 0 / PASS.
  * All external calls go through proc.run_cmd (hard timeout, hang-safe).
  * Scope is the local tray (topology.gpus_per_node / grace_sockets_per_node);
    rack-wide criteria are aggregated by the orchestrator.
  * Metrics carry GPU UUID/serial so a failure names the part.
"""

from __future__ import annotations

import json
import logging
import re
import time
from pathlib import Path
import statistics
from typing import Any, Dict, List, Optional, Tuple

from .. import proc
from ..telemetry import parse_nvlink_errors
from ..workloads import (cpu_numa_nodes, cpus_in_node, parse_gpu_burn,
                         parse_stream_triad, parse_stressng, stream_cmd)

log = logging.getLogger(__name__)

PhaseResult = Tuple[bool, Dict]


# ═══════════════════════════════════════════════════════════════════════════════
# Parsers (pure; unit-tested)
# ═══════════════════════════════════════════════════════════════════════════════

def parse_dcgm_diag(stdout: str, rc: Optional[int]) -> Tuple[bool, List[str], int]:
    """
    Parse `dcgmi diag ... -j`. Returns (passed, failure_descriptions, skipped).
    Walks the JSON for any object carrying a result status, so it tolerates
    schema differences between DCGM 3.x and 4.x. Falls back to the text table.
    1.1 checked `"PASS" in stdout`; DCGM prints "Pass", so every run failed.
    A non-zero exit code with nothing parseable is a failure.
    """
    failures: List[str] = []
    skipped = 0
    seen_any = False
    try:
        data = json.loads(stdout[stdout.index("{"):]) if "{" in stdout else None
    except ValueError:
        data = None

    def walk(node, ctx: str):
        nonlocal skipped, seen_any
        if isinstance(node, dict):
            name = str(node.get("name") or node.get("test_name") or node.get("category") or ctx)
            status = node.get("status") or node.get("result")
            if isinstance(status, str):
                seen_any = True
                s = status.strip().lower()
                if s.startswith("fail"):
                    who = node.get("gpu_id", node.get("entity_id", ""))
                    info = node.get("info") or node.get("warnings") or ""
                    failures.append(f"{name}{' gpu ' + str(who) if who != '' else ''}: "
                                    f"{str(info)[:200]}")
                elif s.startswith("skip") or s == "not run":
                    skipped += 1
            for k, v in node.items():
                walk(v, name if k in ("results", "tests") else ctx)
        elif isinstance(node, list):
            for v in node:
                walk(v, ctx)

    if data is not None:
        walk(data, "dcgm")
    else:
        for line in stdout.splitlines():
            cols = [c.strip() for c in line.split("|") if c.strip()]
            if len(cols) >= 2:
                res = cols[-1].lower()
                if res.startswith(("pass", "fail", "skip", "warn")):
                    seen_any = True
                if res.startswith("fail"):
                    failures.append(" | ".join(cols)[:200])
                elif res.startswith("skip"):
                    skipped += 1

    if not seen_any:
        failures.append(f"no parsable DCGM result (rc={rc})")
    elif rc not in (0, None) and not failures:
        failures.append(f"dcgmi exited rc={rc} without a per-test failure")
    return (not failures), failures, skipped


def parse_bw_matrix(text: str) -> List[float]:
    """Numeric cells of the first bandwidth matrix in nvbandwidth /
    p2pBandwidthLatencyTest style output (row label column excluded)."""
    vals: List[float] = []
    in_matrix = False
    for line in text.splitlines():
        low = line.lower()
        if not in_matrix:
            if "gb/s" in low and ("bandwidth" in low or "matrix" in low):
                in_matrix = True
            continue
        s = line.strip()
        if not s:
            if vals:
                break
            continue
        if s.lower().startswith("sum"):
            break
        toks = s.split()
        if not re.fullmatch(r"\d+", toks[0]) or all(re.fullmatch(r"\d+", t) for t in toks):
            continue                                   # column header row (GPU indices)
        for t in toks[1:]:
            try:
                vals.append(float(t))
            except ValueError:
                pass                                   # N/A on the diagonal
    return vals


def parse_nvlink_status(text: str) -> Dict[int, Dict[str, Any]]:
    """`nvidia-smi nvlink -s` -> {gpu: {'active': n, 'inactive': m, 'speeds': [GB/s...]}}."""
    res: Dict[int, Dict[str, Any]] = {}
    cur = None
    for line in text.splitlines():
        m = re.match(r"^\s*GPU\s+(\d+)\s*:", line)
        if m:
            cur = int(m.group(1))
            res[cur] = {"active": 0, "inactive": 0, "speeds": []}
            continue
        if cur is None or not re.search(r"Link\s+\d+", line):
            continue
        if "inactive" in line.lower():
            res[cur]["inactive"] += 1
            continue
        sp = re.search(r"([\d.]+)\s*GB/s", line)
        if sp:
            res[cur]["active"] += 1
            res[cur]["speeds"].append(float(sp.group(1)))
    return res


def parse_fabric_info(text: str) -> Dict[str, Dict[str, str]]:
    """
    Parse the per-GPU "Fabric" section of `nvidia-smi -q`:
        GPU 00000008:01:00.0
            ...
            Fabric
                State                 : Completed
                Status                : Success
                CliqueId              : 32766
                ClusterUUID           : 7c1b...
                Health
                    Bandwidth         : Full
    Returns {pci_bus_id: {state, status, cliqueid, clusteruuid, bandwidth}}.
    """
    out: Dict[str, Dict[str, str]] = {}
    gpu = None
    fab_indent = None
    for line in text.splitlines():
        m = re.match(r"^GPU\s+([0-9A-Fa-f:.]+)\s*$", line.strip())
        if m and not line.startswith((" ", "\t")):
            gpu, fab_indent = m.group(1), None
            out[gpu] = {}
            continue
        if gpu is None:
            continue
        indent = len(line) - len(line.lstrip())
        if line.strip() == "Fabric":
            fab_indent = indent
            continue
        if fab_indent is not None:
            if line.strip() and indent <= fab_indent:
                fab_indent = None
                continue
            kv = re.match(r"^\s*([A-Za-z .]+?)\s*:\s*(.*?)\s*$", line)
            if kv:
                key = kv.group(1).strip().lower().replace(" ", "")
                if key in ("state", "status", "cliqueid", "clusteruuid", "bandwidth"):
                    out[gpu][key] = kv.group(2)
    return out


def peer_outliers(values: Dict[str, float], max_pct: float) -> List[Tuple[str, float, float]]:
    """Members more than max_pct below the median of their peers."""
    vals = [v for v in values.values() if v and v > 0]
    if len(vals) < 2:
        return []
    med = statistics.median(vals)
    return [(k, v, (med - v) / med * 100) for k, v in values.items()
            if v and med and (med - v) / med * 100 > max_pct]


def numa_capacity_gb(node: int) -> Optional[float]:
    try:
        for line in Path(f"/sys/devices/system/node/node{node}/meminfo").read_text().splitlines():
            if "MemTotal" in line:
                return int(line.split()[-2]) / 1024 / 1024          # kB -> GiB
    except (OSError, ValueError, IndexError):
        return None
    return None


def nominal_capacity(visible_gib: Optional[float], table: Dict[int, float]) -> Optional[int]:
    """Map OS-visible MemTotal (GiB) to the nominal LPDDR5X size in the table.
    Firmware/driver carve-outs make MemTotal a few percent below nominal."""
    if not visible_gib:
        return None
    best = min(table, key=lambda k: abs(visible_gib - k), default=None)
    if best is not None and 0.80 * best <= visible_gib <= 1.05 * best:
        return best
    return None


def stream_threshold(cfg, node: int) -> Tuple[Optional[float], str]:
    acc = cfg.acceptance
    if acc.stream_triad_min_gbs > 0:
        return acc.stream_triad_min_gbs, "configured override"
    table = {int(k): float(v) for k, v in acc.stream_triad_min_gbs_by_capacity.items()}
    cap = numa_capacity_gb(node)
    nom = nominal_capacity(cap, table)
    if nom is None:
        return None, (f"no STREAM reference for {cap and round(cap)} GiB on NUMA {node}; "
                      f"set acceptance_criteria.stream_triad_min_gbs")
    return table[nom], f"NVIDIA reference for {nom} GB Grace"


# ═══════════════════════════════════════════════════════════════════════════════
# Criteria bookkeeping
# ═══════════════════════════════════════════════════════════════════════════════

class Criteria:
    def __init__(self, metrics: Dict, failures: List[str]):
        self.items: List[Dict[str, Any]] = metrics.setdefault("criteria", [])
        self.failures = failures

    def check(self, cid: str, desc: str, measured, limit, op: str, detail: str = "") -> bool:
        if measured is None:
            ok = False
            detail = detail or "not measured"
        elif op == ">=":
            ok = measured >= limit
        elif op == "<=":
            ok = measured <= limit
        elif op == "==":
            ok = measured == limit
        else:
            raise ValueError(op)
        self.items.append({"id": cid, "desc": desc, "measured": measured, "limit": limit,
                           "op": op, "passed": ok, "detail": detail})
        if not ok:
            self.failures.append(f"{desc}: measured {measured} (need {op} {limit})"
                                 + (f" — {detail}" if detail else ""))
        return ok


# ═══════════════════════════════════════════════════════════════════════════════
# Shared steps
# ═══════════════════════════════════════════════════════════════════════════════

def _write(path: Path, res: proc.CmdResult):
    try:
        path.write_text(f"# {' '.join(map(str, res.cmd))}\n# {res.describe()}\n"
                        f"{res.stdout}\n--- stderr ---\n{res.stderr}")
    except OSError as exc:
        log.warning("Could not write %s: %s", path, exc)


def run_dcgm_diag(cmd: List[str], timeout_s: int, log_path: Path) -> Tuple[bool, List[str], int]:
    res = proc.run_cmd(cmd, timeout_s)
    _write(log_path, res)
    if res.error or res.timed_out:
        return False, [res.describe()], 0
    return parse_dcgm_diag(res.stdout, res.rc)


def collect_nvlink_counters(timeout_s: int, gpu_indices: List[int]) -> Tuple[Dict[str, Dict], str]:
    res = proc.run_cmd(["nvidia-smi", "nvlink", "-e"], timeout_s)
    if not res.ok:
        return {}, res.describe()
    parsed = parse_nvlink_errors(res.stdout)
    missing = [i for i in gpu_indices if i not in parsed or parsed[i]["links"] == 0]
    out = {str(i): {k: v for k, v in c.items() if k != "links"} for i, c in parsed.items()}
    return out, (f"no NVLink counters parsed for GPUs {missing}" if missing else "")


def run_stream_all(cfg, log_dir: Path, tag: str, crit: Criteria) -> Dict[str, float]:
    """Local STREAM per Grace (72 threads, spread) + cross-socket cNVLink."""
    nodes = cpu_numa_nodes()
    expected = cfg.topology.grace_sockets_per_node
    crit.check(f"cpu_numa_nodes_{tag}", "CPU NUMA nodes", len(nodes), expected, "==",
               "check NPS/NUMA mode" if len(nodes) != expected else "")
    results: Dict[str, float] = {}
    for node in nodes:
        cmd, env = stream_cmd(cfg, node)
        res = proc.run_cmd(cmd, cfg.workload.stream_timeout_s, env=env)
        _write(log_dir / f"stream_{tag}_node_{node}.log", res)
        gbs = parse_stream_triad(res.stdout) if res.ok else None
        results[str(node)] = gbs or 0.0
        limit, why = stream_threshold(cfg, node)
        if limit is None:
            crit.check(f"stream_triad_{tag}", f"STREAM Triad NUMA {node} (GB/s)",
                       None, 0.0, ">=", why)          # fail closed: no reference
            continue
        crit.check(f"stream_triad_{tag}", f"STREAM Triad NUMA {node} (GB/s)",
                   round(gbs, 1) if gbs else None, limit, ">=",
                   why if res.ok else res.describe())
    for k, v, pct in peer_outliers(results, cfg.acceptance.peer_deviation_max_pct):
        crit.check(f"stream_peer_{tag}", f"STREAM NUMA {k} vs tray median (% below)",
                   round(pct, 1), cfg.acceptance.peer_deviation_max_pct, "<=")
    # Cross-socket: CPUs on one Grace, memory on the other (both directions).
    if len(nodes) >= 2:
        a, b = nodes[0], nodes[1]
        for cpu_n, mem_n in ((a, b), (b, a)):
            env = dict(stream_cmd(cfg, cpu_n)[1])
            cmd = ["numactl", f"--cpunodebind={cpu_n}", f"--membind={mem_n}",
                   cfg.workload.stream_binary]
            res = proc.run_cmd(cmd, cfg.workload.stream_timeout_s, env=env)
            _write(log_dir / f"stream_{tag}_cpu{cpu_n}_mem{mem_n}.log", res)
            gbs = parse_stream_triad(res.stdout) if res.ok else None
            results[f"{cpu_n}->{mem_n}"] = gbs or 0.0
            crit.check(f"stream_cross_socket_{tag}",
                       f"STREAM cross-socket CPU{cpu_n}->MEM{mem_n} (GB/s)",
                       round(gbs, 1) if gbs else None,
                       cfg.acceptance.stream_cross_socket_min_gbs, ">=",
                       "" if res.ok else res.describe())
    return results


def run_bw_test(cmd: List[str], timeout_s: int, log_path: Path, crit: Criteria, cid: str,
                desc: str, limit: float, peer_pct: float, required: bool = True) -> List[float]:
    res = proc.run_cmd(cmd, timeout_s)
    _write(log_path, res)
    vals = parse_bw_matrix(res.stdout) if res.ok else []
    if not vals:
        if required:
            crit.check(cid, desc, None, limit, ">=", res.describe())
        else:
            log.warning("%s produced no result: %s", desc, res.describe())
        return []
    crit.check(cid, f"{desc} min", round(min(vals), 1), limit, ">=")
    for k, v, pct in peer_outliers({str(i): v for i, v in enumerate(vals)}, peer_pct):
        crit.check(f"{cid}_peer", f"{desc} entry {k} vs tray median (% below)",
                   round(pct, 1), peer_pct, "<=")
    return vals


def run_stressng_sanity(cfg, log_path: Path) -> Tuple[int, List[str]]:
    res = proc.run_cmd([cfg.workload.stress_ng_binary, "--cpu", "0", "--cpu-method",
                        "matrixprod", "--verify", "--timeout", "300s", "--metrics-brief"], 420)
    _write(log_path, res)
    if res.error or res.timed_out:
        return -1, [f"stress-ng: {res.describe()}"]
    errors = parse_stressng(res.stdout + res.stderr, res.rc)
    fails = [f"stress-ng: {errors} errors (rc={res.rc})"] if errors or res.rc not in (0,) else []
    return errors, fails


def run_gpu_throughput(cfg, log_path: Path, crit: Optional[Criteria] = None,
                       tag: str = "") -> Tuple[float, List[str], Dict]:
    """Short gpu_burn; returns (steady aggregate TFLOP/s, failures, per_gpu)."""
    secs = cfg.workload.baseline_gpu_burn_s
    res = proc.run_cmd([cfg.workload.gpu_burn_path, "-tc", "-m", "90%", str(secs)], secs + 300)
    _write(log_path, res)
    r = parse_gpu_burn(res.stdout)
    fails: List[str] = []
    if res.error or res.timed_out:
        fails.append(f"gpu_burn: {res.describe()}")
    if r.progress_lines == 0:
        fails.append("gpu_burn produced no progress output")
    if r.total_errors or r.faulty_gpus or r.died:
        fails.append(f"gpu_burn errors={r.per_gpu_errors} faulty={r.faulty_gpus} died={r.died}")
    per_gpu = {str(i): g for i, g in enumerate(r.per_gpu_gflops)}
    if crit is not None:
        crit.check(f"gpu_burn_gpus_{tag}", "gpu_burn GPUs reporting", len(per_gpu),
                   cfg.topology.gpus_per_node, "==")
        for k, v, pct in peer_outliers(per_gpu, cfg.acceptance.gpu_throughput_peer_deviation_max_pct):
            crit.check(f"gpu_throughput_peer_{tag}", f"GPU {k} throughput vs tray median (% below)",
                       round(pct, 1), cfg.acceptance.gpu_throughput_peer_deviation_max_pct, "<=")
    return r.steady_gflops / 1000.0, fails, per_gpu


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 2: OS Boot Validation (BIP-001 §5.2-5.3) — low power
# ═══════════════════════════════════════════════════════════════════════════════

def run_boot_validation(cfg, collector, health=None, baseline_samples: int = 10,
                        sample_interval_s: int = 30) -> PhaseResult:
    metrics: Dict = {}
    failures: List[str] = []
    crit = Criteria(metrics, failures)
    topo, acc, tools = cfg.topology, cfg.acceptance, cfg.tools

    snap = collector.collect_once()
    metrics["gpu_count"] = len(snap.gpus)
    metrics["gpu_inventory"] = [{"index": g.index, "uuid": g.uuid, "serial": g.serial,
                                 "pci_bus_id": g.pci_bus_id} for g in snap.gpus]
    crit.check("gpu_count", "GPU count", len(snap.gpus), topo.gpus_per_node, "==",
               snap.source_errors.get("gpu", ""))
    if health is not None:
        health.set_inventory(snap.gpus)
    for g in snap.gpus:
        if g.remap_failure:
            failures.append(f"GPU {g.index} ({g.serial}) row-remap failure present at boot")
        if g.remap_pending:
            failures.append(f"GPU {g.index} ({g.serial}) row remap pending (needs reset)")
        if g.ecc_dbe_volatile:
            failures.append(f"GPU {g.index} ({g.serial}) {g.ecc_dbe_volatile} volatile DBEs at boot")

    res = proc.run_cmd(["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"], 30)
    if res.ok and res.stdout.strip():
        ver = res.stdout.strip().splitlines()[0].strip()
        metrics["driver_version"] = ver
        try:
            crit.check("driver_major", "Driver major version", int(ver.split(".")[0]),
                       tools.min_driver_major, ">=", ver)
        except ValueError:
            failures.append(f"Unparseable driver version {ver!r}")
        if tools.qualified_driver_versions and ver not in tools.qualified_driver_versions:
            failures.append(f"Driver {ver} not in qualified list {tools.qualified_driver_versions}")
    else:
        failures.append(f"Driver version check: {res.describe()}")

    res = proc.run_cmd(["dcgmi", "discovery", "-l"], 60)
    if res.ok:
        n = len(re.findall(r"^\|\s*\d+\s*\|", res.stdout, re.MULTILINE)) or \
            len(re.findall(r"GPU\s+\d+", res.stdout))
        metrics["dcgm_gpu_count"] = n
        crit.check("dcgm_gpu_count", "GPUs visible to DCGM", n, topo.gpus_per_node, ">=")
    else:
        failures.append(f"DCGM discovery: {res.describe()}")

    # NVLink5: every link active and trained at full per-link rate.
    res = proc.run_cmd(["nvidia-smi", "nvlink", "-s"], 60)
    if res.ok:
        st = parse_nvlink_status(res.stdout)
        metrics["nvlink_status"] = {str(k): {kk: vv for kk, vv in v.items() if kk != "speeds"}
                                    for k, v in st.items()}
        for g in snap.gpus:
            s = st.get(g.index)
            if s is None:
                failures.append(f"NVLink status missing for GPU {g.index}")
                continue
            crit.check("nvlink_active_links", f"GPU {g.index} active NVLinks", s["active"],
                       topo.nvlinks_per_gpu, ">=", f"{s['inactive']} inactive; serial {g.serial}")
            slow = [sp for sp in s["speeds"] if sp < acc.nvlink_link_min_gbs]
            crit.check("nvlink_link_speed", f"GPU {g.index} slowest NVLink (GB/s)",
                       min(s["speeds"]) if s["speeds"] else None, acc.nvlink_link_min_gbs, ">=",
                       f"{len(slow)} link(s) below rate" if slow else "")
    else:
        failures.append(f"NVLink status: {res.describe()}")

    # NVLink fabric registration (GB200: GPUs join the rack-wide fabric via
    # NMX/IMEX; an unregistered GPU cannot use multi-node NVLink).
    if tools.require_fabric_registration:
        res = proc.run_cmd(["nvidia-smi", "-q"], 120)
        fab = parse_fabric_info(res.stdout) if res.ok else {}
        metrics["fabric"] = fab
        with_fab = {k: v for k, v in fab.items() if v}
        if not with_fab:
            failures.append(f"GPU fabric info not found in nvidia-smi -q ({res.describe()})")
        for bus, f in with_fab.items():
            ok = f.get("state", "").lower() == "completed" and f.get("status", "").lower() == "success"
            if not ok:
                failures.append(f"GPU {bus}: fabric state={f.get('state')} status={f.get('status')}")
            bw = f.get("bandwidth")
            if bw and bw.lower() != "full":
                failures.append(f"GPU {bus}: fabric health bandwidth={bw}")
        uuids = {f.get("clusteruuid") for f in with_fab.values() if f.get("clusteruuid")}
        metrics["fabric_cluster_uuids"] = sorted(uuids)
        cliques = {f.get("cliqueid") for f in with_fab.values() if f.get("cliqueid")}
        metrics["fabric_clique_ids"] = sorted(cliques)
        if len(uuids) > 1:
            failures.append(f"GPUs on this tray report different fabric ClusterUUIDs: {sorted(uuids)}")

    for svc in tools.required_services:
        res = proc.run_cmd(["systemctl", "is-active", svc], 15)
        metrics[f"service_{svc}"] = res.stdout.strip() or res.describe()
        if res.stdout.strip() != "active":
            failures.append(f"service {svc} is {res.stdout.strip() or res.describe()}")

    samples = []
    for i in range(baseline_samples):
        s = collector.collect_once()
        samples.append(s)
        if s.xid_events:
            failures.append(f"XID(s) during boot validation: "
                            f"{[(e.xid, e.pci_bus_id) for e in s.xid_events]}")
        if i < baseline_samples - 1:
            time.sleep(sample_interval_s)
    gpu_vals = [s.gpu_junction_max() for s in samples if s.gpu_junction_max() is not None]
    cpu_vals = [s.cpu_temp_max() for s in samples if s.cpu_temp_max() is not None]
    if len(gpu_vals) < baseline_samples // 2:
        failures.append(f"GPU temperature readable in only {len(gpu_vals)}/{baseline_samples} samples")
    if len(cpu_vals) < baseline_samples // 2:
        failures.append(f"CPU temperature readable in only {len(cpu_vals)}/{baseline_samples} samples")
    metrics["baseline_gpu_junction_avg_c"] = _avg(gpu_vals)
    metrics["baseline_cpu_temp_avg_c"] = _avg(cpu_vals)
    metrics["baseline_coolant_inlet_c"] = samples[-1].coolant.inlet_temp_c
    metrics["baseline_coolant_outlet_c"] = samples[-1].coolant.outlet_temp_c
    if gpu_vals:
        crit.check("idle_gpu_junction", "Idle GPU junction avg (°C)",
                   round(metrics["baseline_gpu_junction_avg_c"], 1), acc.idle_gpu_junction_max_c, "<=")
    if cpu_vals:
        crit.check("idle_cpu_temp", "Idle Grace temp avg (°C)",
                   round(metrics["baseline_cpu_temp_avg_c"], 1), acc.idle_cpu_max_c, "<=")

    return _finish("Boot validation", metrics, failures)


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 3: Functional Validation (BIP-001 §6) — full power, needs admission
# ═══════════════════════════════════════════════════════════════════════════════

def run_functional_validation(cfg, log_dir: Path, gpu_indices: Optional[List[int]] = None) -> PhaseResult:
    metrics: Dict = {}
    failures: List[str] = []
    crit = Criteria(metrics, failures)
    tools, acc = cfg.tools, cfg.acceptance
    gpu_indices = gpu_indices if gpu_indices is not None else list(range(cfg.topology.gpus_per_node))

    log.info("DCGM diagnostics (baseline)...")
    ok, fails, skipped = run_dcgm_diag(tools.dcgm_diag_cmd, tools.dcgm_diag_timeout_s,
                                       log_dir / "dcgm_diag_baseline.log")
    metrics.update(dcgm_l3_baseline_passed=ok, dcgm_l3_baseline_failures=fails,
                   dcgm_l3_baseline_skipped=skipped)
    crit.check("dcgm_diag_baseline", "DCGM diag baseline failures", len(fails), 0, "==",
               "; ".join(fails[:3]))

    log.info("Grace CPU sanity (stress-ng 5 min)...")
    errs, fails = run_stressng_sanity(cfg, log_dir / "stressng_sanity.log")
    metrics["stressng_sanity_errors"] = errs
    crit.check("stressng_sanity", "stress-ng sanity errors", errs if errs >= 0 else None,
               acc.stressng_errors_max, "<=", "; ".join(fails))

    log.info("STREAM baseline (local per Grace + cross-socket)...")
    stream = run_stream_all(cfg, log_dir, "baseline", crit)
    metrics["stream_baseline_gbs_per_socket"] = stream
    local = [v for k, v in stream.items() if "->" not in k]
    metrics["stream_baseline_min_gbs"] = min(local) if local else 0.0

    log.info("NVLink-C2C bandwidth (H2D, D2H)...")
    h2d = run_bw_test(tools.c2c_cmd, tools.c2c_timeout_s, log_dir / "c2c_h2d.log", crit,
                      "c2c_h2d", "C2C host->device CE (GB/s)", acc.c2c_h2d_min_gbs,
                      acc.peer_deviation_max_pct, tools.require_c2c_test)
    d2h = run_bw_test(tools.c2c_d2h_cmd, tools.c2c_timeout_s, log_dir / "c2c_d2h.log", crit,
                      "c2c_d2h", "C2C device->host CE (GB/s)", acc.c2c_d2h_min_gbs,
                      acc.peer_deviation_max_pct, tools.require_c2c_test)
    metrics["c2c_h2d_gbs"] = h2d
    metrics["c2c_d2h_gbs"] = d2h
    metrics["c2c_baseline_gbs"] = min(h2d) if h2d else 0.0

    log.info("GPU<->GPU NVLink bandwidth...")
    p2p = run_bw_test(tools.p2p_cmd, tools.p2p_timeout_s, log_dir / "p2p_bandwidth.log", crit,
                      "nvlink_p2p", "NVLink P2P CE read (GB/s)", acc.nvlink_p2p_min_gbs,
                      acc.peer_deviation_max_pct)
    metrics["nvlink_allpairs_min_gbs"] = min(p2p) if p2p else 0.0

    log.info("NVLink error counters (pre-burn-in)...")
    counters, err = collect_nvlink_counters(60, gpu_indices)
    metrics["nvlink_errors_pre_burnin"] = counters
    if err:
        failures.append(f"NVLink counters: {err}")
    crit.check("nvlink_crc_pre", "NVLink CRC errors before burn-in",
               sum(c.get("crc", 0) for c in counters.values()) if counters else None, 0, "==")

    log.info("GPU memory test...")
    ok, fails, _ = run_dcgm_diag(tools.memtest_cmd, tools.memtest_timeout_s, log_dir / "mem_test.log")
    metrics["gpu_memory_test_errors"] = len(fails)
    crit.check("gpu_memtest", "GPU memory test failures", len(fails), 0, "==", "; ".join(fails[:3]))

    log.info("GPU throughput baseline (%ds gpu_burn)...", cfg.workload.baseline_gpu_burn_s)
    tflops, fails, per_gpu = run_gpu_throughput(cfg, log_dir / "gpu_burn_baseline.log", crit, "baseline")
    metrics["gpu_throughput_baseline_tflops"] = tflops
    metrics["gpu_throughput_baseline_per_gpu_gflops"] = per_gpu
    failures += [f"GPU baseline: {f}" for f in fails]

    return _finish("Functional validation", metrics, failures)


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 5: Post-Burn-In Validation (BIP-001 §8)
# ═══════════════════════════════════════════════════════════════════════════════

def run_post_burnin(cfg, log_dir: Path, baseline_metrics: Dict,
                    gpu_indices: Optional[List[int]] = None) -> PhaseResult:
    metrics: Dict = {}
    failures: List[str] = []
    crit = Criteria(metrics, failures)
    tools, acc = cfg.tools, cfg.acceptance
    gpu_indices = gpu_indices if gpu_indices is not None else list(range(cfg.topology.gpus_per_node))

    ok, fails, skipped = run_dcgm_diag(tools.dcgm_diag_cmd, tools.dcgm_diag_timeout_s,
                                       log_dir / "dcgm_diag_post_burnin.log")
    metrics.update(dcgm_l3_post_passed=ok, dcgm_l3_post_failures=fails,
                   dcgm_l3_post_skipped=skipped)
    crit.check("dcgm_diag_post", "DCGM diag post-burn failures", len(fails), 0, "==",
               "; ".join(fails[:3]))

    stream = run_stream_all(cfg, log_dir, "post", crit)
    metrics["stream_post_gbs_per_socket"] = stream
    local = {k: v for k, v in stream.items() if "->" not in k}
    metrics["stream_post_min_gbs"] = min(local.values()) if local else 0.0
    base = baseline_metrics.get("stream_baseline_gbs_per_socket", {})
    degr = {}
    for node, gbs in stream.items():
        b = base.get(node, 0.0)
        if b > 0 and gbs > 0:
            degr[node] = round((b - gbs) / b * 100, 2)
    metrics["stream_degradation_pct"] = degr
    metrics["stream_degradation_max_pct"] = max(degr.values()) if degr else None
    crit.check("stream_degradation", "STREAM worst degradation vs baseline (%)",
               metrics["stream_degradation_max_pct"], acc.stream_degradation_max_pct, "<=")

    errs, fails = run_stressng_sanity(cfg, log_dir / "stressng_post.log")
    metrics["stressng_post_errors"] = errs
    crit.check("stressng_post", "stress-ng post-burn errors", errs if errs >= 0 else None,
               acc.stressng_errors_max, "<=", "; ".join(fails))

    counters, err = collect_nvlink_counters(60, gpu_indices)
    (log_dir / "nvlink_errors_post.json").write_text(json.dumps(counters, indent=2))
    metrics["nvlink_errors_post"] = counters
    if err:
        failures.append(f"NVLink counters: {err}")
    pre = baseline_metrics.get("nvlink_errors_pre_burnin", {})
    crc_delta = sum(max(0, c.get("crc", 0) - pre.get(g, {}).get("crc", 0))
                    for g, c in counters.items()) if counters else None
    max_replay = max((c.get("replay", 0) for c in counters.values()), default=None)
    metrics["nvlink_crc_total"] = crc_delta
    metrics["nvlink_replay_max_per_gpu"] = max_replay
    crit.check("nvlink_crc", "NVLink CRC errors during burn-in", crc_delta,
               acc.nvlink_crc_errors_max, "<=")
    crit.check("nvlink_replay", "NVLink replay errors, worst GPU", max_replay,
               acc.nvlink_replay_errors_per_gpu_max, "<=")

    # Re-measure links after 72 h: a marginal lane often shows up here first.
    p2p = run_bw_test(tools.p2p_cmd, tools.p2p_timeout_s, log_dir / "p2p_bandwidth_post.log", crit,
                      "nvlink_p2p_post", "NVLink P2P CE read post-burn (GB/s)",
                      acc.nvlink_p2p_min_gbs, acc.peer_deviation_max_pct)
    metrics["nvlink_allpairs_post_min_gbs"] = min(p2p) if p2p else 0.0

    tflops, fails, per_gpu = run_gpu_throughput(cfg, log_dir / "gpu_burn_post.log", crit, "post")
    metrics["gpu_throughput_post_tflops"] = tflops
    metrics["gpu_throughput_post_per_gpu_gflops"] = per_gpu
    failures += [f"GPU post: {f}" for f in fails]
    base_t = baseline_metrics.get("gpu_throughput_baseline_tflops", 0.0)
    d = round((base_t - tflops) / base_t * 100, 2) if base_t > 0 and tflops > 0 else None
    metrics["gpu_throughput_degradation_pct"] = d
    crit.check("gpu_throughput_degradation", "GPU throughput degradation vs baseline (%)", d,
               acc.gpu_throughput_degradation_max_pct, "<=")
    base_pg = baseline_metrics.get("gpu_throughput_baseline_per_gpu_gflops", {})
    for g, v in per_gpu.items():
        b = base_pg.get(g)
        if b and v:
            crit.check("gpu_throughput_degradation_per_gpu",
                       f"GPU {g} throughput degradation (%)", round((b - v) / b * 100, 2),
                       acc.gpu_throughput_degradation_max_pct, "<=")

    return _finish("Post-burn-in validation", metrics, failures)


def _avg(vals: List[float]) -> float:
    return sum(vals) / len(vals) if vals else 0.0


def _finish(name: str, metrics: Dict, failures: List[str]) -> PhaseResult:
    metrics["failures"] = failures
    if failures:
        log.error("%s FAILED: %s", name, failures)
    else:
        log.info("%s PASSED", name)
    return not failures, metrics


# 1.1 names kept for callers/tests
_parse_stream_triad = parse_stream_triad


def _parse_gpu_burn_gflops(output: str) -> float:
    return parse_gpu_burn(output).steady_gflops


def _count_stressng_errors(output: str) -> int:
    return parse_stressng(output)
