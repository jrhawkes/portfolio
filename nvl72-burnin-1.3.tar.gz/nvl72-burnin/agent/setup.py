from setuptools import setup, find_packages

setup(
    name="burnin-agent",
    version="1.3.0",
    description="NVL72 Burn-In Node Agent",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "requests>=2.31.0",
        "urllib3>=2.0.0",
        "prometheus-client>=0.20.0",
        "PyYAML>=6.0.1",
    ],
    entry_points={
        "console_scripts": [
            "burnin-agent=burnin_agent.main:main",
        ]
    },
)
