"""
orchestrator/burnin_orchestrator/main.py
Burn-In Orchestrator (BIO) — FastAPI application.
State lives in Redis; any number of workers/replicas may run. Exactly one
instance runs the scheduler at a time (Redis lease).
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .config import load_config
from .redis_store import RedisStore, StoreError
from .routers import metrics, nodes, racks, reports
from .scheduler import BurninScheduler

log = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    cfg = load_config()
    logging.basicConfig(level=getattr(logging, cfg.log_level.upper(), logging.INFO),
                        format="%(asctime)s %(levelname)-8s [%(name)s] %(message)s")
    store = RedisStore(cfg)
    await store.connect()
    scheduler = BurninScheduler(cfg, store)
    await scheduler.start()
    fwd = None
    if cfg.vm_forward and cfg.victoriametrics_url:
        fwd = metrics.VMForwarder(cfg.victoriametrics_url)
        await fwd.start()
    app.state.cfg, app.state.store, app.state.scheduler = cfg, store, scheduler
    app.state.vm_forwarder = fwd
    log.info("Burn-In Orchestrator started (scheduler instance %s)", scheduler.instance_id)
    yield
    await scheduler.stop()
    if fwd:
        await fwd.stop()
    await store.close()


app = FastAPI(title="NVL72 Burn-In Orchestrator", version="1.3.0",
              description="Central state machine for parallel NVL72 rack burn-in qualification",
              lifespan=lifespan)

# Bearer-token API; no cookies, so no credentials over CORS.
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["GET", "POST"],
                   allow_headers=["Authorization", "Content-Type"], allow_credentials=False)

app.include_router(racks.router, prefix="/racks", tags=["Racks"])
app.include_router(nodes.router, prefix="/racks", tags=["Nodes"])
app.include_router(metrics.router, prefix="/metrics", tags=["Metrics"])
app.include_router(reports.router, prefix="/reports", tags=["Reports"])


@app.get("/healthz")
async def health():
    return {"status": "ok"}


@app.get("/readyz")
async def ready(request: Request):
    try:
        await request.app.state.store.r.ping()
    except Exception as exc:                                   # noqa: BLE001
        return JSONResponse(status_code=503, content={"status": "redis unavailable",
                                                      "detail": str(exc)})
    return {"status": "ok", "scheduler_leader": request.app.state.scheduler.is_leader}


@app.exception_handler(StoreError)
async def store_error_handler(request: Request, exc: StoreError):
    return JSONResponse(status_code=exc.status, content={"detail": str(exc)})


@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    log.exception("Unhandled exception on %s %s", request.method, request.url.path)
    return JSONResponse(status_code=500, content={"detail": "internal error"})
