"""
orchestrator/burnin_orchestrator/redis_store.py
Redis-backed state store shared by all orchestrator workers.

1.2 changes (correctness under concurrency and scale):
  * Every rack mutation is an optimistic transaction (WATCH/MULTI/EXEC with
    retry). 1.1 did GET -> modify -> SET, so concurrent agent/scheduler/
    operator writes silently overwrote each other (e.g. RE_RUN's run_count
    increment was always lost, so racks were never quarantined).
  * State, zone-slot and index updates happen in the same MULTI as the rack
    write, so they cannot diverge. 1.1's record_abort() set ABORTED without
    touching the zone index, leaking a power slot per abort.
  * Set indexes (racks:all, racks:state:<S>) + MGET replace KEYS rack:*,
    which is O(keyspace) and blocks Redis for every scheduler tick.
  * Transitions are validated (models.ALLOWED_TRANSITIONS); operator force is
    explicit and audited.
  * Node events are de-duplicated on event_id inside the same transaction and
    rejected if they carry a stale run_id.
  * Streams are capped (XADD MAXLEN ~). Unbounded audit/alert streams plus
    maxmemory-policy allkeys-lru meant Redis would eventually evict rack
    records.
  * Heartbeats and per-node phase metrics live outside the rack record, so
    18 x 1,000 heartbeats/30 s never contend on the rack key.
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple

import redis.asyncio as aioredis
from redis.exceptions import WatchError

from .models import (AGENT_DRIVEN_STATES, ALLOWED_TRANSITIONS, HUMAN_REQUIRED_STATES,
                     NODE_PHASES, POWER_SLOT_STATES, STATE_TIMEOUTS, TERMINAL_FAILURE_STATES,
                     NodeRecord, RackRecord, RackState)

log = logging.getLogger(__name__)
S = RackState

RACK_KEY_PREFIX  = "rack:"
RACKS_ALL        = "racks:all"
STATE_SET        = "racks:state:"
ZONE_SLOTS       = "zone:slots:"
ZONE_LAST_ADMIT  = "zone:last_admit:"
AUDIT_STREAM_KEY = "audit:events"
ALERT_STREAM_KEY = "alerts:stream"
EVENT_DEDUPE     = "evt:"
HEARTBEATS       = "hb"            # zset "rack|node" -> ts
HB_DATA          = "hbdata:"       # hash node -> summary json
PHASE_METRICS    = "phase:"        # phase:<rack>:<run>:<node>:<phase>
CHECKPOINTS      = "ckpt:"         # list per rack/run
LEADER_KEY       = "scheduler:leader"
MGET_CHUNK       = 500


class StoreError(Exception):
    status = 400


class NotFound(StoreError):
    status = 404


class InvalidTransition(StoreError):
    status = 409


class StaleRun(StoreError):
    status = 409


class Conflict(StoreError):
    status = 409


def rk(rack_id: str) -> str:
    return f"{RACK_KEY_PREFIX}{rack_id}"


@dataclass
class Ctx:
    """Side effects collected during a mutation, applied inside MULTI."""
    audits: List[Tuple[str, Dict]] = field(default_factory=list)
    alerts: List[Tuple[str, str]] = field(default_factory=list)
    ops: List[Callable[[Any], None]] = field(default_factory=list)
    result: Any = None
    actor: str = "system"


class RedisStore:
    def __init__(self, cfg, client: Optional[aioredis.Redis] = None):
        self.cfg = cfg
        self._redis: Optional[aioredis.Redis] = client

    async def connect(self):
        if self._redis is None:
            self._redis = aioredis.from_url(self.cfg.redis_url, encoding="utf-8",
                                            decode_responses=True, max_connections=100,
                                            socket_timeout=10, health_check_interval=30)
        await self._redis.ping()
        policy = None
        try:
            policy = (await self._redis.config_get("maxmemory-policy")).get("maxmemory-policy")
        except Exception:                                  # noqa: BLE001 (managed Redis may block CONFIG)
            pass
        if policy and policy != "noeviction":
            log.error("Redis maxmemory-policy=%s: rack state can be EVICTED. Use noeviction.", policy)
        log.info("Connected to Redis")

    async def close(self):
        if self._redis:
            await self._redis.aclose()

    @property
    def r(self) -> aioredis.Redis:
        return self._redis

    # ── transaction core ────────────────────────────────────────────────────

    async def _mutate(self, rack_id: str,
                      fn: Callable[[RackRecord, Ctx, Dict], Any],
                      pre_read: Optional[Callable[[Any], Awaitable[Dict]]] = None,
                      extra_watch: Tuple[str, ...] = (),
                      actor: str = "system",
                      retries: int = 25) -> Tuple[RackRecord, Ctx]:
        key = rk(rack_id)
        for attempt in range(retries):
            async with self.r.pipeline(transaction=True) as pipe:
                try:
                    await pipe.watch(key, *extra_watch)
                    raw = await pipe.get(key)
                    if raw is None:
                        raise NotFound(f"Rack {rack_id} not found")
                    rack = RackRecord.model_validate_json(raw)
                    old_state = rack.state
                    extra = await pre_read(pipe) if pre_read else {}
                    ctx = Ctx(actor=actor)
                    ctx.result = fn(rack, ctx, extra)
                    pipe.multi()
                    pipe.set(key, rack.model_dump_json())
                    self._queue_index_updates(pipe, rack, old_state)
                    for etype, data in ctx.audits:
                        self._queue_audit(pipe, etype, rack.rack_id, data)
                    for sev, msg in ctx.alerts:
                        self._queue_alert(pipe, sev, rack, msg)
                    for op in ctx.ops:
                        op(pipe)
                    await pipe.execute()
                    for sev, msg in ctx.alerts:
                        log.warning("ALERT [%s] %s: %s", sev, rack_id, msg)
                    return rack, ctx
                except WatchError:
                    await asyncio.sleep(random.uniform(0, 0.01 * (attempt + 1)))
        raise Conflict(f"Rack {rack_id}: too much write contention")

    def _queue_index_updates(self, pipe, rack: RackRecord, old: RackState):
        new = rack.state
        if new == old:
            return
        pipe.srem(f"{STATE_SET}{old.value}", rack.rack_id)
        pipe.sadd(f"{STATE_SET}{new.value}", rack.rack_id)
        zkey = f"{ZONE_SLOTS}{rack.power_zone}"
        if new in POWER_SLOT_STATES:
            pipe.zadd(zkey, {rack.rack_id: time.time()}, nx=True)
        else:
            pipe.zrem(zkey, rack.rack_id)
        if new not in AGENT_DRIVEN_STATES and rack.nodes:
            pipe.zrem(HEARTBEATS, *[f"{rack.rack_id}|{n}" for n in rack.nodes])

    def _queue_audit(self, pipe, event_type: str, rack_id: str, data: dict):
        pipe.xadd(AUDIT_STREAM_KEY, {"type": event_type, "rack_id": rack_id,
                                     "timestamp": str(time.time()),
                                     "data": json.dumps(data, default=str)},
                  maxlen=self.cfg.audit_maxlen, approximate=True)

    def _queue_alert(self, pipe, severity: str, rack: RackRecord, message: str):
        pipe.xadd(ALERT_STREAM_KEY, {"severity": severity, "rack_id": rack.rack_id,
                                     "facility": rack.facility, "power_zone": rack.power_zone,
                                     "message": message, "timestamp": str(time.time())},
                  maxlen=self.cfg.alert_maxlen, approximate=True)

    @staticmethod
    def _transition(rack: RackRecord, ctx: Ctx, new_state, reason: str = "",
                    force: bool = False, operator_id: Optional[str] = None):
        new = RackState(new_state) if not isinstance(new_state, RackState) else new_state
        old = rack.state
        if new == old:
            return False
        if not force and new not in ALLOWED_TRANSITIONS.get(old, set()):
            raise InvalidTransition(f"{old.value} -> {new.value} not allowed")
        rack.previous_state = old
        rack.state = new
        rack.state_entered_at = time.time()
        rack.state_reason = reason
        if new == S.ONBOARDING:
            RedisStore._start_new_run(rack)
        ctx.audits.append(("rack.state_transition", {
            "from": old.value, "to": new.value, "reason": reason, "force": force,
            "operator_id": operator_id or ctx.actor, "run_id": rack.run_id}))
        log.info("Rack %s: %s -> %s (%s)", rack.rack_id, old.value, new.value, reason)
        return True

    @staticmethod
    def _start_new_run(rack: RackRecord):
        if rack.run_id and (rack.nodes or rack.abort_events):
            rack.run_history.append({
                "run_id": rack.run_id, "ended_state": (rack.previous_state or rack.state).value,
                "abort_events": rack.abort_events[-5:],
                "failed_components": rack.failed_components[-20:],
                "ended_at": time.time()})
            rack.run_history = rack.run_history[-10:]
        rack.run_id = uuid.uuid4().hex[:12]
        rack.nodes = {}
        rack.phase_results = {k: v for k, v in rack.phase_results.items()
                              if k == "physical_inspection"}
        rack.abort_events = []
        rack.failed_components = []
        rack.admission_ready = False
        rack.burn_deadline_ts = 0.0
        rack.checkpoints = []

    # ── reads ────────────────────────────────────────────────────────────────

    async def get_rack(self, rack_id: str) -> Optional[RackRecord]:
        data = await self.r.get(rk(rack_id))
        return RackRecord.model_validate_json(data) if data else None

    async def _mget_racks(self, ids: List[str]) -> List[RackRecord]:
        out: List[RackRecord] = []
        ids = sorted(ids)
        for i in range(0, len(ids), MGET_CHUNK):
            chunk = ids[i:i + MGET_CHUNK]
            for raw in await self.r.mget([rk(x) for x in chunk]):
                if raw:
                    out.append(RackRecord.model_validate_json(raw))
        return out

    async def list_racks(self, facility: Optional[str] = None) -> List[RackRecord]:
        racks = await self._mget_racks(list(await self.r.smembers(RACKS_ALL)))
        return [r for r in racks if facility is None or r.facility == facility]

    async def get_racks_in_state(self, state) -> List[RackRecord]:
        v = state.value if isinstance(state, RackState) else str(state)
        return await self._mget_racks(list(await self.r.smembers(f"{STATE_SET}{v}")))

    get_racks_in_state_value = get_racks_in_state          # 1.1 name

    async def get_fleet_summary(self) -> dict:
        pipe = self.r.pipeline(transaction=False)
        for s in RackState:
            pipe.scard(f"{STATE_SET}{s.value}")
        counts = await pipe.execute()
        by_state = {s.value: c for s, c in zip(RackState, counts) if c}
        return {"total": sum(counts), "by_state": by_state, "timestamp": time.time()}

    async def active_rack_count_in_zone(self, power_zone: str) -> int:
        return await self.r.zcard(f"{ZONE_SLOTS}{power_zone}")

    # ── operator operations ──────────────────────────────────────────────────

    async def create_rack(self, rack: RackRecord) -> RackRecord:
        if not rack.run_id:
            rack.run_id = uuid.uuid4().hex[:12]
        created = await self.r.set(rk(rack.rack_id), rack.model_dump_json(), nx=True)
        if not created:
            raise Conflict(f"Rack {rack.rack_id} already registered")
        pipe = self.r.pipeline(transaction=True)
        pipe.sadd(RACKS_ALL, rack.rack_id)
        pipe.sadd(f"{STATE_SET}{rack.state.value}", rack.rack_id)
        self._queue_audit(pipe, "rack.created", rack.rack_id,
                          {"facility": rack.facility, "power_zone": rack.power_zone,
                           "node_count": rack.node_count})
        await pipe.execute()
        log.info("Registered rack %s (facility=%s zone=%s)", rack.rack_id, rack.facility,
                 rack.power_zone)
        return rack

    async def save_rack(self, rack: RackRecord):
        """Unsafe blind write; retained for tests/migrations only."""
        await self.r.set(rk(rack.rack_id), rack.model_dump_json())

    async def transition_state(self, rack_id: str, new_state: str, reason: str = "",
                               operator_id: str = "agent", force: bool = False) -> RackRecord:
        try:
            RackState(new_state)
        except ValueError:
            raise InvalidTransition(f"Unknown state: {new_state}")
        rack, _ = await self._mutate(
            rack_id, lambda r, c, e: self._transition(r, c, new_state, reason, force, operator_id),
            actor=operator_id)
        return rack

    async def record_phase_result(self, rack_id: str, phase: str, passed: bool,
                                  metrics: dict) -> RackRecord:
        """Rack-level phase result (operator tools, e.g. intake inspection)."""
        def fn(rack, ctx, _):
            rack.phase_results[phase] = {"passed": passed, "metrics": metrics,
                                         "timestamp": time.time()}
            ctx.audits.append(("rack.phase_result", {"phase": phase, "passed": passed}))
            if not passed and rack.state not in HUMAN_REQUIRED_STATES:
                self._transition(rack, ctx, S.FAILED, f"Phase {phase} failed")
        rack, _ = await self._mutate(rack_id, fn, actor="operator")
        return rack

    async def record_abort(self, rack_id: str, events: list, snapshot: dict,
                           node_id: str = "", actor: str = "operator") -> RackRecord:
        def fn(rack, ctx, _):
            self._apply_abort(rack, ctx, node_id, events)
        rack, _ = await self._mutate(rack_id, fn, actor=actor)
        return rack

    def _apply_abort(self, rack: RackRecord, ctx: Ctx, node_id: str, events: list):
        rack.abort_events.append({"timestamp": time.time(), "node_id": node_id,
                                  "events": events[:20]})
        rack.abort_events = rack.abort_events[-50:]
        for ev in events[:20]:
            comp = ev.get("component") if isinstance(ev, dict) else None
            if comp:
                rack.failed_components.append({**comp, "condition": ev.get("condition"),
                                               "run_id": rack.run_id})
        rack.failed_components = rack.failed_components[-100:]
        if node_id and node_id in rack.nodes:
            rack.nodes[node_id].aborted = True
        first = events[0].get("condition", "unknown") if events and isinstance(events[0], dict) else "unknown"
        where = f"node {node_id}: " if node_id else ""
        if S.ABORTED in ALLOWED_TRANSITIONS.get(rack.state, set()):
            self._transition(rack, ctx, S.ABORTED, f"{where}{first}")
            ctx.alerts.append(("CRITICAL", f"Rack ABORTED ({where}{first})"))
        else:
            ctx.audits.append(("rack.abort_recorded", {"node_id": node_id, "condition": first,
                                                       "state": rack.state.value}))

    async def set_hold(self, rack_id: str, hold: bool, operator_id: str) -> RackRecord:
        def fn(rack, ctx, _):
            rack.hold = hold
            ctx.audits.append(("rack.hold", {"hold": hold, "operator_id": operator_id}))
        rack, _ = await self._mutate(rack_id, fn, actor=operator_id)
        return rack

    async def triage(self, rack_id: str, disposition: str, reason: str,
                     operator_id: str) -> RackRecord:
        def fn(rack, ctx, _):
            d = disposition.upper()
            ctx.audits.append(("rack.triage", {"disposition": d, "reason": reason,
                                               "operator_id": operator_id}))
            if d in ("RE_RUN", "RE_RUN_AFTER_COOLDOWN"):
                rack.run_count += 1
                if rack.run_count >= self.cfg.max_reruns:
                    self._transition(rack, ctx, S.QUARANTINED,
                                     f"Max re-runs ({self.cfg.max_reruns}) exceeded", force=True,
                                     operator_id=operator_id)
                else:
                    if rack.state in (S.FAILED, S.ABORTED, S.QUARANTINED):
                        self._transition(rack, ctx, S.TRIAGE, "re-run requested",
                                         operator_id=operator_id)
                    self._transition(rack, ctx, S.ONBOARDING,
                                     f"Re-run #{rack.run_count} by {operator_id}: {reason}",
                                     operator_id=operator_id)
            elif d == "QUARANTINE":
                self._transition(rack, ctx, S.QUARANTINED, reason, operator_id=operator_id)
            elif d == "REPAIR":
                rack.notes += f"\nREPAIR: {reason} by {operator_id} at {time.time():.0f}"
                self._transition(rack, ctx, S.TRIAGE, "Awaiting repair", operator_id=operator_id)
            elif d == "WAIVE":
                if rack.state not in (S.FAILED, S.ABORTED, S.TRIAGE):
                    raise InvalidTransition(f"Cannot waive a rack in {rack.state.value}")
                rack.notes += f"\nWAIVER: {reason} by {operator_id} at {time.time():.0f}"
                self._transition(rack, ctx, S.PASSED, f"Engineering waiver: {reason}",
                                 operator_id=operator_id)
            else:
                raise StoreError(f"Unknown disposition {disposition}")
        rack, _ = await self._mutate(rack_id, fn, actor=operator_id)
        return rack

    # ── node agent operations ────────────────────────────────────────────────

    async def apply_node_event(self, rack_id: str, node_id: str, ev) -> Dict:
        dkey = f"{EVENT_DEDUPE}{ev.event_id}"

        async def pre(pipe):
            return {"dup": bool(await pipe.exists(dkey))}

        def fn(rack: RackRecord, ctx: Ctx, extra: Dict):
            if extra["dup"]:
                ctx.result = {"status": "duplicate"}
                return ctx.result
            if ev.run_id != rack.run_id:
                raise StaleRun(f"event run_id {ev.run_id!r} != current {rack.run_id!r}")
            node = self._node(rack, node_id)
            node.last_event_seq = max(node.last_event_seq, ev.seq)
            p = ev.payload
            if ev.type == "state":
                node.state = str(p.get("state", ""))
                if rack.state == S.ONBOARDING and node.state == "BOOTING":
                    self._transition(rack, ctx, S.BOOTING, f"node {node_id} started boot validation")
            elif ev.type == "phase_result":
                self._apply_phase_result(rack, ctx, node, str(p.get("phase")),
                                         bool(p.get("passed")), p.get("metrics") or {})
            elif ev.type == "abort":
                self._apply_abort(rack, ctx, node_id, list(p.get("abort_events") or []))
            elif ev.type == "checkpoint":
                entry = json.dumps({"node_id": node_id, "hours": p.get("hours"),
                                    "timestamp": ev.timestamp, **(p.get("snapshot") or {})},
                                   default=str)
                key = f"{CHECKPOINTS}{rack.rack_id}:{rack.run_id}"
                ctx.ops.append(lambda pipe: (pipe.rpush(key, entry), pipe.ltrim(key, -2000, -1)))
            else:
                raise StoreError(f"unknown event type {ev.type!r}")
            ttl = self.cfg.event_dedupe_ttl_s
            ctx.ops.append(lambda pipe: pipe.set(dkey, "1", ex=ttl))
            return {"status": "ok", "rack_state": rack.state.value}

        _, ctx = await self._mutate(rack_id, fn, pre_read=pre, extra_watch=(dkey,),
                                    actor=f"node:{node_id}")
        return ctx.result

    def _node(self, rack: RackRecord, node_id: str) -> NodeRecord:
        if node_id in rack.nodes:
            return rack.nodes[node_id]
        if rack.expected_nodes and node_id not in rack.expected_nodes:
            raise Conflict(f"node {node_id} not in expected_nodes for {rack.rack_id}")
        if len(rack.nodes) >= rack.node_count:
            raise Conflict(f"rack {rack.rack_id} already has {rack.node_count} nodes")
        rack.nodes[node_id] = NodeRecord(node_id=node_id)
        return rack.nodes[node_id]

    def _apply_phase_result(self, rack: RackRecord, ctx: Ctx, node: NodeRecord,
                            phase: str, passed: bool, metrics: Dict):
        if phase not in NODE_PHASES:
            raise StoreError(f"unknown phase {phase!r}")
        failures = [str(f)[:300] for f in (metrics.get("failures") or [])][:20]
        node.phases[phase] = {"passed": passed, "timestamp": time.time(), "failures": failures}
        if phase == "boot_validation":
            node.phases[phase]["fabric_cluster_uuids"] = list(metrics.get("fabric_cluster_uuids") or [])
            node.phases[phase]["fabric_clique_ids"] = list(metrics.get("fabric_clique_ids") or [])
        mkey = f"{PHASE_METRICS}{rack.rack_id}:{rack.run_id}:{node.node_id}:{phase}"
        blob = json.dumps(metrics, default=str)
        ctx.ops.append(lambda pipe: pipe.set(mkey, blob, ex=180 * 86400))
        ctx.audits.append(("node.phase_result", {"node_id": node.node_id, "phase": phase,
                                                 "passed": passed, "failures": failures[:3]}))
        if rack.state in TERMINAL_FAILURE_STATES:
            return
        if not passed:
            rack.failed_components.append({"type": "node", "node_id": node.node_id,
                                           "phase": phase, "failures": failures[:5],
                                           "run_id": rack.run_id})
            self._transition(rack, ctx, S.FAILED,
                             f"node {node.node_id} failed {phase}: {'; '.join(failures[:2])}")
            ctx.alerts.append(("CRITICAL", f"node {node.node_id} failed {phase}"))
            return
        done = sum(1 for n in rack.nodes.values() if n.phases.get(phase, {}).get("passed"))
        rack.phase_results[phase] = {"passed_nodes": done, "node_count": rack.node_count,
                                     "passed": done >= rack.node_count}
        if done < rack.node_count:
            return
        if phase == "boot_validation":
            # All 72 GPUs must have registered with the same NVLink fabric
            # (NMX cluster) and partition; a tray on a different ClusterUUID
            # or clique cannot participate in the rack's NVLink domain.
            for key, what in (("fabric_cluster_uuids", "ClusterUUID"),
                              ("fabric_clique_ids", "CliqueId")):
                seen = {u for n in rack.nodes.values()
                        for u in n.phases.get(phase, {}).get(key, [])}
                if len(seen) > 1:
                    rack.failed_components.append({"type": "fabric", "field": what,
                                                   "values": sorted(seen), "run_id": rack.run_id})
                    self._transition(rack, ctx, S.FAILED,
                                     f"NVLink fabric {what} differs across trays: {sorted(seen)}")
                    ctx.alerts.append(("CRITICAL", f"fabric {what} mismatch"))
                    return
            if rack.state == S.ONBOARDING:
                self._transition(rack, ctx, S.BOOTING, "all nodes reported")
            rack.admission_ready = True
            ctx.audits.append(("rack.admission_ready", {}))
        elif phase == "functional_validation" and rack.state == S.BASELINE and not rack.hold:
            self._begin_burn(rack, ctx)
        elif phase == "burnin" and rack.state in (S.BURNING, S.COOLING):
            self._transition(rack, ctx, S.VALIDATING, "all nodes completed burn-in")
        elif phase == "post_burnin" and rack.state == S.VALIDATING:
            self._transition(rack, ctx, S.REPORTING, "all nodes passed post-burn validation")
            self._transition(rack, ctx, S.PASSED, "All acceptance criteria met on all nodes")

    def _begin_burn(self, rack: RackRecord, ctx: Ctx):
        rack.burn_deadline_ts = time.time() + self.cfg.burnin_duration_s
        self._transition(rack, ctx, S.BURNING, "all nodes passed functional validation")

    async def record_heartbeat(self, rack_id: str, node_id: str, hb) -> Dict:
        now = time.time()
        pipe = self.r.pipeline(transaction=False)
        pipe.sismember(RACKS_ALL, rack_id)
        pipe.zadd(HEARTBEATS, {f"{rack_id}|{node_id}": now})
        pipe.hset(f"{HB_DATA}{rack_id}", node_id,
                  json.dumps({**hb.summary, "phase": hb.phase, "run_id": hb.run_id,
                              "received_at": now}, default=str))
        pipe.expire(f"{HB_DATA}{rack_id}", 7 * 86400)
        exists, *_ = await pipe.execute()
        if not exists:
            await self.r.zrem(HEARTBEATS, f"{rack_id}|{node_id}")
            raise NotFound(f"Rack {rack_id} not found")
        return {"status": "ok"}

    async def get_directive(self, rack_id: str, node_id: str) -> Dict:
        rack = await self.get_rack(rack_id)
        if rack is None:
            raise NotFound(f"Rack {rack_id} not found")
        abort = rack.state in TERMINAL_FAILURE_STATES
        return {
            "rack_id": rack_id, "node_id": node_id, "rack_state": rack.state.value,
            "run_id": rack.run_id if rack.state not in (S.REGISTERED, S.INSPECTING) else "",
            "command": "abort" if abort else ("hold" if rack.hold else None),
            "reason": rack.state_reason,
            "burn_deadline_ts": rack.burn_deadline_ts or None,
            "server_time": time.time(),
        }

    async def get_latest_telemetry(self, rack_id: str) -> Optional[dict]:
        data = await self.r.hgetall(f"{HB_DATA}{rack_id}")
        return {n: json.loads(v) for n, v in data.items()} if data else None

    async def get_node_phase_metrics(self, rack: RackRecord) -> Dict[str, Dict[str, Any]]:
        keys, idx = [], []
        for n in rack.nodes:
            for ph in NODE_PHASES:
                keys.append(f"{PHASE_METRICS}{rack.rack_id}:{rack.run_id}:{n}:{ph}")
                idx.append((n, ph))
        out: Dict[str, Dict[str, Any]] = {}
        if keys:
            for (n, ph), raw in zip(idx, await self.r.mget(keys)):
                if raw:
                    out.setdefault(n, {})[ph] = json.loads(raw)
        return out

    async def get_checkpoints(self, rack: RackRecord) -> List[Dict]:
        raw = await self.r.lrange(f"{CHECKPOINTS}{rack.rack_id}:{rack.run_id}", 0, -1)
        return [json.loads(x) for x in raw]

    # ── scheduler operations (leader only) ───────────────────────────────────

    async def try_admit(self, rack_id: str, capacity: int, interval_s: int) -> Tuple[bool, str]:
        """Atomically move a BOOTING, admission-ready rack to BASELINE if its
        zone has a free power slot and the stagger interval has elapsed."""
        rack = await self.get_rack(rack_id)
        if rack is None:
            return False, "gone"
        zkey = f"{ZONE_SLOTS}{rack.power_zone}"
        lkey = f"{ZONE_LAST_ADMIT}{rack.power_zone}"

        async def pre(pipe):
            return {"used": await pipe.zcard(zkey), "last": float(await pipe.get(lkey) or 0)}

        def fn(r: RackRecord, ctx: Ctx, extra: Dict):
            if r.state != S.BOOTING or not r.admission_ready or r.hold:
                return False, f"not eligible ({r.state.value})"
            if extra["used"] >= capacity:
                return False, f"zone full {extra['used']}/{capacity}"
            wait = interval_s - (time.time() - extra["last"])
            if wait > 0:
                return False, f"stagger {wait:.0f}s"
            self._transition(r, ctx, S.BASELINE,
                             f"admitted: zone {r.power_zone} slot {extra['used'] + 1}/{capacity}")
            now = str(time.time())
            ctx.ops.append(lambda pipe: pipe.set(lkey, now))
            return True, "admitted"

        # A rejected admission still rewrites the unchanged record; cheap and
        # keeps a single code path. Only the leader calls this.
        _, ctx = await self._mutate(rack_id, fn, pre_read=pre, extra_watch=(zkey, lkey),
                                    actor="scheduler")
        return ctx.result

    async def advance_unheld_baseline(self, rack_id: str) -> bool:
        def fn(r: RackRecord, ctx: Ctx, _):
            done = sum(1 for n in r.nodes.values()
                       if n.phases.get("functional_validation", {}).get("passed"))
            if r.state == S.BASELINE and not r.hold and done >= r.node_count:
                self._begin_burn(r, ctx)
                return True
            return False
        _, ctx = await self._mutate(rack_id, fn, actor="scheduler")
        return bool(ctx.result)

    async def check_stalled_racks(self) -> List[str]:
        stalled = []
        now = time.time()
        for state, timeout in STATE_TIMEOUTS.items():
            for rack in await self.get_racks_in_state(state):
                elapsed = now - rack.state_entered_at
                if elapsed <= timeout:
                    continue
                stalled.append(rack.rack_id)
                msg = (f"stalled in {state.value} {elapsed / 3600:.1f}h "
                       f"(limit {timeout / 3600:.1f}h)")
                if state in HUMAN_REQUIRED_STATES:
                    # Alert at most hourly for human-gated states.
                    if int(elapsed) % 3600 < self.cfg.scheduler_tick_s * 2:
                        await self._alert_only(rack, "WARNING", msg)
                    continue

                def fn(r, ctx, _, st=state, m=msg):
                    if r.state == st:
                        self._transition(r, ctx, S.FAILED, f"Timeout: {m}")
                        ctx.alerts.append(("CRITICAL", m))
                try:
                    await self._mutate(rack.rack_id, fn, actor="scheduler")
                except StoreError as exc:
                    log.warning("Timeout transition for %s failed: %s", rack.rack_id, exc)
        return stalled

    async def check_stale_nodes(self) -> List[Tuple[str, str]]:
        cutoff = time.time() - self.cfg.node_stale_s
        lost = []
        for member in await self.r.zrangebyscore(HEARTBEATS, "-inf", cutoff):
            rack_id, _, node_id = member.partition("|")
            lost.append((rack_id, node_id))

            def fn(r, ctx, _, n=node_id):
                if r.state in AGENT_DRIVEN_STATES and n in r.nodes and not r.nodes[n].aborted:
                    self._apply_abort(r, ctx, n, [{
                        "condition": "node_lost",
                        "message": f"no heartbeat from {n} for >{self.cfg.node_stale_s}s",
                        "component": {"type": "node", "node_id": n}}])
            try:
                await self._mutate(rack_id, fn, actor="scheduler")
            except NotFound:
                pass
            except StoreError as exc:
                log.warning("node_lost handling for %s/%s failed: %s", rack_id, node_id, exc)
            await self.r.zrem(HEARTBEATS, member)
        return lost

    async def _alert_only(self, rack: RackRecord, severity: str, message: str):
        pipe = self.r.pipeline(transaction=False)
        self._queue_alert(pipe, severity, rack, message)
        await pipe.execute()
        log.warning("ALERT [%s] %s: %s", severity, rack.rack_id, message)

    # ── leader election ──────────────────────────────────────────────────────

    async def acquire_or_renew_leader(self, instance_id: str, ttl_ms: int) -> bool:
        if await self.r.set(LEADER_KEY, instance_id, nx=True, px=ttl_ms):
            return True
        async with self.r.pipeline(transaction=True) as pipe:
            try:
                await pipe.watch(LEADER_KEY)
                if await pipe.get(LEADER_KEY) != instance_id:
                    await pipe.unwatch()
                    return False
                pipe.multi()
                pipe.pexpire(LEADER_KEY, ttl_ms)
                await pipe.execute()
                return True
            except WatchError:
                return False

    async def release_leader(self, instance_id: str):
        async with self.r.pipeline(transaction=True) as pipe:
            try:
                await pipe.watch(LEADER_KEY)
                if await pipe.get(LEADER_KEY) == instance_id:
                    pipe.multi()
                    pipe.delete(LEADER_KEY)
                    await pipe.execute()
                else:
                    await pipe.unwatch()
            except WatchError:
                pass
