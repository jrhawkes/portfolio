"""
orchestrator/burnin_orchestrator/routers/reports.py
Acceptance report: aggregates the 18 node results of the current run.

1.1 issues fixed: unauthenticated; REPORT_DIR created at import time (the
non-root container user can't create /var/lib/..., so the app failed to
start); WeasyPrint ran on the event loop, blocking every other request for
the length of a render; criteria were hard-coded PASS (duration, STREAM
degradation) and C2C could read FAIL on a PASSED rack.
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import FileResponse

from ..deps import get_cfg, get_store, require_operator
from ..redis_store import RedisStore

log = logging.getLogger(__name__)
router = APIRouter()


def _report_dir(cfg) -> Path:
    d = Path(cfg.report_dir)
    d.mkdir(parents=True, exist_ok=True)
    return d


@router.get("/{rack_id}")
async def get_report(rack_id: str, store: RedisStore = Depends(get_store),
                     _=Depends(require_operator)):
    rack = await store.get_rack(rack_id)
    if rack is None:
        raise HTTPException(status_code=404, detail=f"Rack {rack_id} not found")
    return _build_report(rack, await store.get_node_phase_metrics(rack),
                         await store.get_checkpoints(rack))


@router.post("/{rack_id}/generate-pdf")
async def generate_pdf(rack_id: str, request: Request, store: RedisStore = Depends(get_store),
                       _=Depends(require_operator)):
    rack = await store.get_rack(rack_id)
    if rack is None:
        raise HTTPException(status_code=404, detail=f"Rack {rack_id} not found")
    data = _build_report(rack, await store.get_node_phase_metrics(rack),
                         await store.get_checkpoints(rack))
    try:
        path = await run_in_threadpool(_render_pdf, _report_dir(get_cfg(request)),
                                       rack_id, rack.run_id, data)
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"report write failed: {exc}")
    return {"rack_id": rack_id, "path": str(path)}


@router.get("/{rack_id}/download")
async def download_report(rack_id: str, request: Request, store: RedisStore = Depends(get_store),
                          _=Depends(require_operator)):
    rack = await store.get_rack(rack_id)
    if rack is None:
        raise HTTPException(status_code=404, detail="Rack not found")
    d = Path(get_cfg(request).report_dir)
    for ext, mt in (("pdf", "application/pdf"), ("json", "application/json")):
        p = d / f"{rack_id}_{rack.run_id}_acceptance.{ext}"
        if p.exists():
            return FileResponse(str(p), media_type=mt, filename=p.name)
    raise HTTPException(status_code=404, detail="Not generated. POST /reports/{rack_id}/generate-pdf")


PHASE_ORDER = ("boot_validation", "functional_validation", "burnin", "post_burnin")


def rollup_criteria(node_metrics: Dict[str, Dict[str, Any]], node_count: int) -> List[dict]:
    """
    Roll per-node criteria (emitted by the agents, with the thresholds that
    were actually applied) up to one row per (phase, criterion). A row passes
    only if every expected node reported it and every instance passed.
    1.1 re-hard-coded thresholds here (900 GB/s, 800 GB/s, 72 GPUs...) and
    marked two criteria PASS unconditionally.
    """
    groups: Dict[tuple, List[tuple]] = {}
    for node, phases in node_metrics.items():
        for phase in PHASE_ORDER:
            for c in (phases.get(phase) or {}).get("criteria", []) or []:
                groups.setdefault((phase, c.get("id")), []).append((node, c))
    rows = []
    for phase in PHASE_ORDER:
        for (ph, cid), entries in sorted(groups.items(), key=lambda kv: kv[0][1]):
            if ph != phase:
                continue
            op = entries[0][1].get("op")
            limit = entries[0][1].get("limit")
            nodes = {n for n, _ in entries}
            failing = [(n, c) for n, c in entries if not c.get("passed")]
            meas = [c.get("measured") for _, c in entries if isinstance(c.get("measured"), (int, float))]
            worst = None
            if meas:
                worst = min(meas) if op == ">=" else max(meas)
            complete = len(nodes) >= node_count
            passed = complete and not failing
            rows.append({
                "phase": phase, "criterion": cid,
                "description": entries[0][1].get("desc"),
                "required": f"{op} {limit}", "measured": worst,
                "nodes_reported": len(nodes), "nodes_failed": len({n for n, _ in failing}),
                "failing": [{"node_id": n, "desc": c.get("desc"), "measured": c.get("measured"),
                             "detail": c.get("detail")} for n, c in failing[:20]],
                "passed": passed,
                "result": "PASS" if passed else ("FAIL" if failing else "INCOMPLETE"),
            })
    return rows


def _build_report(rack, node_metrics: Dict[str, Dict[str, Any]], checkpoints: List[dict]) -> dict:
    rows = [{"phase": "rack", "criterion": "nodes_reporting",
             "description": "Compute trays reporting", "required": f"== {rack.node_count}",
             "measured": len(node_metrics), "nodes_reported": len(node_metrics),
             "nodes_failed": 0, "failing": [],
             "passed": len(node_metrics) >= rack.node_count,
             "result": "PASS" if len(node_metrics) >= rack.node_count else "INCOMPLETE"}]
    rows += rollup_criteria(node_metrics, rack.node_count)
    overall = rack.state.value == "PASSED"
    return {
        "rack_id": rack.rack_id, "serial_number": rack.serial_number,
        "facility": rack.facility, "power_zone": rack.power_zone, "run_id": rack.run_id,
        "run_count": rack.run_count, "overall_result": "PASS" if overall else "FAIL",
        "overall_passed": overall, "state": rack.state.value,
        "waived": "WAIVER:" in (rack.notes or ""),
        "criteria_all_passed": all(r["passed"] for r in rows),
        "registered_at": rack.registered_at, "report_generated_at": time.time(),
        "acceptance_criteria": rows,
        "nodes": {n: {"phases": r.phases, "aborted": r.aborted} for n, r in rack.nodes.items()},
        "failed_components": rack.failed_components,
        "checkpoints": checkpoints, "abort_events": rack.abort_events, "notes": rack.notes,
    }


def _render_pdf(report_dir: Path, rack_id: str, run_id: str, report_data: dict) -> Path:
    try:
        from jinja2 import Template
        from weasyprint import HTML
    except (ImportError, OSError) as exc:     # OSError: pango/cairo libs missing
        json_path = report_dir / f"{rack_id}_{run_id}_acceptance.json"
        json_path.write_text(json.dumps(report_data, indent=2, default=str))
        log.warning("PDF renderer unavailable (%s); wrote JSON report %s", exc, json_path)
        return json_path
    pdf_path = report_dir / f"{rack_id}_{run_id}_acceptance.pdf"
    HTML(string=Template(_PDF_TEMPLATE).render(**report_data)).write_pdf(str(pdf_path))
    return pdf_path


_PDF_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  body { font-family: Arial, sans-serif; font-size: 11pt; margin: 2cm; }
  h1 { color: #1A3A5C; border-bottom: 3px solid #76B900; padding-bottom: 8px; }
  h2 { color: #1F5C99; margin-top: 24px; }
  .verdict { font-size: 28pt; font-weight: bold; padding: 16px; text-align: center;
             border: 3px solid; border-radius: 8px; margin: 20px 0; }
  .pass { color: #2d7a2d; border-color: #2d7a2d; background: #f0fff0; }
  .fail { color: #cc0000; border-color: #cc0000; background: #fff0f0; }
  table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 10pt; }
  th { background: #1A3A5C; color: white; padding: 6px 10px; text-align: left; }
  td { padding: 5px 10px; border-bottom: 1px solid #ddd; }
  tr:nth-child(even) { background: #f5f8fc; }
  .p { color: #2d7a2d; font-weight: bold; }
  .f { color: #cc0000; font-weight: bold; }
</style>
</head>
<body>
<h1>NVL72 Burn-In Acceptance Report</h1>

<table>
  <tr><td><b>Rack ID</b></td><td>{{ rack_id }}</td>
      <td><b>Serial</b></td><td>{{ serial_number }}</td></tr>
  <tr><td><b>Facility</b></td><td>{{ facility }}</td>
      <td><b>Power Zone</b></td><td>{{ power_zone }}</td></tr>
  <tr><td><b>Run ID</b></td><td>{{ run_id }}</td>
      <td><b>Run #</b></td><td>{{ run_count }}</td></tr>
</table>

<div class="verdict {{ 'pass' if overall_passed else 'fail' }}">
  OVERALL: {{ overall_result }}
</div>

<h2>Acceptance Criteria</h2>
<table>
  <tr><th>Phase</th><th>Criterion</th><th>Required</th><th>Worst measured</th><th>Nodes</th><th>Result</th></tr>
  {% for row in acceptance_criteria %}
  <tr>
    <td>{{ row.phase }}</td>
    <td>{{ row.description or row.criterion }}</td>
    <td>{{ row.required if row.required is not none else '—' }}</td>
    <td>{{ row.measured if row.measured is not none else '—' }}</td>
    <td>{{ row.nodes_reported }}{% if row.nodes_failed %} ({{ row.nodes_failed }} failed){% endif %}</td>
    <td class="{{ 'p' if row.passed else 'f' }}">{{ row.result }}</td>
  </tr>
  {% endfor %}
</table>

{% if checkpoints %}
<h2>Thermal Checkpoints</h2>
<table>
  <tr><th>Time</th><th>GPU °C</th><th>CPU °C</th><th>CDU Out °C</th><th>Power kW</th></tr>
  {% for cp in checkpoints %}
  <tr>
    <td>T+{{ cp.hours }}h</td>
    <td>{{ cp.get('node_id', '') }} {{ cp.get('gpu_junction_max_c') }}</td>
    <td>{{ cp.get('cpu_temp_max_c') }}</td>
    <td>{{ cp.get('coolant_outlet_c') }}</td>
    <td>{{ cp.get('tray_power_kw') }}</td>
  </tr>
  {% endfor %}
</table>
{% endif %}

{% if notes %}
<h2>Notes</h2>
<p>{{ notes }}</p>
{% endif %}

<hr>
<p><small>Report generated {{ report_generated_at }}</small></p>
<p>Engineer Signature: ______________________________ Date: _______________</p>
</body>
</html>
"""
