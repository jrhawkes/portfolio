"""GB200 acceptance thresholds and the checks that apply them."""
from burnin_agent.config import AgentConfig
from burnin_agent.abort import evaluate
from burnin_agent.phases import (Criteria, nominal_capacity, parse_fabric_info, peer_outliers,
                                 stream_threshold)
from burnin_agent import phases
from burnin_agent.telemetry import GpuSnapshot, TelemetrySnapshot

TABLE = {120: 400.0, 480: 307.0}


def test_defaults_are_physically_achievable_on_gb200():
    a = AgentConfig().acceptance
    # Grace LPDDR5X peak ~512 GB/s; NVLink-C2C 900 GB/s is bidirectional;
    # NVLink5 is 900 GB/s per direction per GPU.
    assert max(a.stream_triad_min_gbs_by_capacity.values()) < 512
    assert a.c2c_h2d_min_gbs < 450 and a.c2c_d2h_min_gbs < a.c2c_h2d_min_gbs
    assert a.nvlink_p2p_min_gbs < 900
    assert AgentConfig().tools.required_services == ["nvidia-imex", "nvidia-persistenced"]
    assert AgentConfig().tools.min_driver_major == 570


def test_capacity_mapping_tolerates_carveouts():
    assert nominal_capacity(452.6, TABLE) == 480        # OS-visible MemTotal on a 480 GB Grace
    assert nominal_capacity(116.0, TABLE) == 120
    assert nominal_capacity(230.0, TABLE) is None        # 240 GB: no NVIDIA reference -> fail closed
    assert nominal_capacity(None, TABLE) is None


def test_stream_threshold_override_and_fail_closed(monkeypatch):
    cfg = AgentConfig()
    monkeypatch.setattr(phases, "numa_capacity_gb", lambda n: 455.0)
    assert stream_threshold(cfg, 0)[0] == 307.0
    monkeypatch.setattr(phases, "numa_capacity_gb", lambda n: 230.0)
    lim, why = stream_threshold(cfg, 0)
    assert lim is None and "no STREAM reference" in why
    cfg.acceptance.stream_triad_min_gbs = 250.0
    assert stream_threshold(cfg, 0)[0] == 250.0


def test_peer_outliers():
    out = peer_outliers({"0": 360.0, "1": 355.0, "2": 300.0, "3": 358.0}, 10.0)
    assert [k for k, _, _ in out] == ["2"]


def test_criteria_none_fails():
    m, f = {}, []
    c = Criteria(m, f)
    assert c.check("x", "X", 400.0, 307.0, ">=")
    assert not c.check("y", "Y", None, 307.0, ">=")
    assert len(f) == 1 and m["criteria"][1]["passed"] is False


FABRIC = """
==============NVSMI LOG==============
Attached GPUs                             : 2
GPU 00000008:01:00.0
    Product Name                          : NVIDIA GB200
    Fabric
        State                             : Completed
        Status                            : Success
        CliqueId                          : 32766
        ClusterUUID                       : 7c1b0e2a-0000-4000-8000-000000000001
        Health
            Bandwidth                     : Full
    Processes                             : None

GPU 00000009:01:00.0
    Product Name                          : NVIDIA GB200
    Fabric
        State                             : In Progress
        Status                            : N/A
        CliqueId                          : N/A
        ClusterUUID                       : N/A
        Health
            Bandwidth                     : Degraded
"""


def test_fabric_parse():
    f = parse_fabric_info(FABRIC)
    a, b = f["00000008:01:00.0"], f["00000009:01:00.0"]
    assert a["state"] == "Completed" and a["status"] == "Success" and a["bandwidth"] == "Full"
    assert a["cliqueid"] == "32766" and a["clusteruuid"].startswith("7c1b")
    assert b["state"] == "In Progress" and b["bandwidth"] == "Degraded"


def test_tlimit_abort():
    th = AgentConfig().abort
    g = GpuSnapshot(index=2, junction_temp_c=84.0, tlimit_c=0.0)
    ev = evaluate(TelemetrySnapshot(gpus=[g]), th)
    assert [e.condition for e in ev] == ["gpu_2_tlimit"]
    g.tlimit_c = 3.0
    assert not evaluate(TelemetrySnapshot(gpus=[g]), th)


def test_c2c_run_flags_weak_gpu(tmp_path):
    script = tmp_path / "nvbw"
    script.write_text("#!/bin/sh\ncat <<'X'\nRunning host_to_device_memcpy_ce.\n"
                      "memcpy CE CPU(row) -> GPU(column) bandwidth (GB/s)\n"
                      "           0         1         2         3\n"
                      " 0    355.10    352.80    301.20    356.00\n\n"
                      "SUM host_to_device_memcpy_ce 1365.1\nX\n")
    script.chmod(0o755)
    m, f = {}, []
    vals = phases.run_bw_test([str(script)], 30, tmp_path / "log", Criteria(m, f), "c2c_h2d",
                              "C2C H2D", 300.0, 10.0)
    assert vals == [355.10, 352.80, 301.20, 356.00]
    ids = [(c["id"], c["passed"]) for c in m["criteria"]]
    assert ("c2c_h2d", True) in ids              # absolute floor met
    assert ("c2c_h2d_peer", False) in ids        # but GPU 2 is 15% below its peers


def test_missing_bw_tool_fails_closed(tmp_path):
    m, f = {}, []
    assert phases.run_bw_test(["/nonexistent/nvbandwidth"], 5, tmp_path / "l", Criteria(m, f),
                              "p2p", "P2P", 630.0, 10.0) == []
    assert f and m["criteria"][0]["passed"] is False
