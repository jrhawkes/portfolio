"""HTTP layer: role separation and error mapping."""
import fakeredis
import pytest
from fastapi.testclient import TestClient

from burnin_orchestrator import main
from burnin_orchestrator.config import OrchestratorConfig
from burnin_orchestrator.redis_store import RedisStore

OP = {"Authorization": "Bearer o"}
AG = {"Authorization": "Bearer a"}


class _Sched:
    is_leader = True


@pytest.fixture
def client():
    cfg = OrchestratorConfig(agent_shared_token="a", operator_token="o", start_interval_s=0)
    main.app.state.cfg = cfg
    main.app.state.store = RedisStore(cfg, client=fakeredis.FakeAsyncRedis(decode_responses=True))
    main.app.state.scheduler = _Sched()
    main.app.state.vm_forwarder = None
    return TestClient(main.app)          # no `with`: lifespan (real Redis) not started


def reg(c):
    return c.post("/racks", headers=OP, json={"rack_id": "r1", "serial_number": "S",
                                               "facility": "dc1", "power_zone": "zA"})


def test_agent_cannot_register_or_waive(client):
    assert client.post("/racks", headers=AG, json={}).status_code in (403, 422)
    assert reg(client).status_code == 201
    r = client.post("/racks/r1/triage", headers=AG,
                    json={"disposition": "WAIVE", "reason": "x", "operator_id": "a"})
    assert r.status_code == 403


def test_invalid_transition_is_409_not_404(client):
    reg(client)
    r = client.post("/racks/r1/state", headers=OP, json={"state": "BURNING"})
    assert r.status_code == 409


def test_node_event_flow_and_directive(client):
    reg(client)
    client.post("/racks/r1/state", headers=OP, json={"state": "ONBOARDING"})
    d = client.get("/racks/r1/nodes/ct00/directive", headers=AG).json()
    assert d["rack_state"] == "ONBOARDING" and d["run_id"]
    body = {"event_id": "e1", "type": "state", "run_id": d["run_id"],
            "payload": {"state": "BOOTING"}}
    assert client.post("/racks/r1/nodes/ct00/events", headers=AG, json=body).status_code == 200
    assert client.post("/racks/r1/nodes/ct00/events", headers=AG,
                       json=body).json()["status"] == "duplicate"
    body2 = {**body, "event_id": "e2", "run_id": "stale"}
    assert client.post("/racks/r1/nodes/ct00/events", headers=AG, json=body2).status_code == 409
    assert client.get("/racks/r1", headers=AG).json()["state"] == "BOOTING"


def test_unknown_rack_is_404(client):
    assert client.get("/racks/nope/nodes/ct00/directive", headers=AG).status_code == 404


def test_reports_require_operator(client):
    reg(client)
    assert client.get("/reports/r1", headers=AG).status_code == 403
    rep = client.get("/reports/r1", headers=OP).json()
    assert rep["acceptance_criteria"][0]["result"] == "INCOMPLETE"


def test_report_rollup_uses_agent_thresholds():
    from burnin_orchestrator.routers.reports import rollup_criteria
    nm = {f"ct{i:02d}": {"functional_validation": {"criteria": [
        {"id": "stream_triad_baseline", "desc": "STREAM", "measured": 330.0 - i,
         "limit": 307.0, "op": ">=", "passed": True}]}} for i in range(18)}
    rows = rollup_criteria(nm, 18)
    assert rows[0]["result"] == "PASS" and rows[0]["measured"] == 313.0
    nm["ct05"]["functional_validation"]["criteria"][0].update(measured=250.0, passed=False)
    rows = rollup_criteria(nm, 18)
    assert rows[0]["result"] == "FAIL" and rows[0]["failing"][0]["node_id"] == "ct05"
    del nm["ct17"]
    rows = rollup_criteria(nm, 18)
    assert rows[0]["nodes_reported"] == 17 and not rows[0]["passed"]
