"""Store + scheduler behaviour against fakeredis (real transactions)."""
import asyncio
import time
import uuid

import fakeredis
import pytest

from burnin_orchestrator.config import OrchestratorConfig
from burnin_orchestrator.models import NodeEvent, RackRecord, RackState, HeartbeatRequest
from burnin_orchestrator.redis_store import (InvalidTransition, RedisStore, StaleRun,
                                             ZONE_SLOTS)
from burnin_orchestrator.scheduler import BurninScheduler

S = RackState
NODES = [f"ct{i:02d}" for i in range(18)]


def cfg(**kw):
    c = OrchestratorConfig(agent_shared_token="a", operator_token="o",
                           default_zone_capacity=2, start_interval_s=0, node_stale_s=300)
    for k, v in kw.items():
        setattr(c, k, v)
    return c


@pytest.fixture
async def store():
    s = RedisStore(cfg(), client=fakeredis.FakeAsyncRedis(decode_responses=True))
    await s.connect()
    yield s


async def new_rack(store, rid="rack-1", zone="zA"):
    await store.create_rack(RackRecord(rack_id=rid, facility="dc1", power_zone=zone,
                                       state=S.INSPECTING))
    return await store.transition_state(rid, "ONBOARDING", "inspection ok", "tech")


def ev(run_id, etype, payload):
    return NodeEvent(event_id=str(uuid.uuid4()), type=etype, run_id=run_id, payload=payload)


async def all_nodes(store, rid, phase, passed=True, nodes=NODES, concurrent=True):
    rack = await store.get_rack(rid)
    coros = [store.apply_node_event(rid, n, ev(rack.run_id, "phase_result",
                                               {"phase": phase, "passed": passed,
                                                "metrics": {"failures": [] if passed else ["x"]}}))
             for n in nodes]
    if concurrent:
        await asyncio.gather(*coros)
    else:
        for c in coros:
            await c


async def test_full_lifecycle_with_concurrent_nodes(store):
    sched = BurninScheduler(store.cfg, store)
    await new_rack(store)
    await all_nodes(store, "rack-1", "boot_validation")        # 18 concurrent writers
    r = await store.get_rack("rack-1")
    assert r.state == S.BOOTING and r.admission_ready
    assert len(r.nodes) == 18                                   # no lost updates
    assert await sched.admit_waiting_racks() == ["rack-1"]
    assert (await store.get_rack("rack-1")).state == S.BASELINE
    assert await store.active_rack_count_in_zone("zA") == 1
    await all_nodes(store, "rack-1", "functional_validation")
    r = await store.get_rack("rack-1")
    assert r.state == S.BURNING and r.burn_deadline_ts > time.time()
    await all_nodes(store, "rack-1", "burnin")
    assert (await store.get_rack("rack-1")).state == S.VALIDATING
    await all_nodes(store, "rack-1", "post_burnin")
    assert (await store.get_rack("rack-1")).state == S.PASSED
    assert await store.active_rack_count_in_zone("zA") == 0     # slot released


async def test_waiting_racks_do_not_consume_capacity(store):
    store.cfg.default_zone_capacity = 1
    sched = BurninScheduler(store.cfg, store)
    for rid in ("r1", "r2", "r3"):
        await new_rack(store, rid)
        await all_nodes(store, rid, "boot_validation")
    assert len(await sched.admit_waiting_racks()) == 1
    assert await sched.admit_waiting_racks() == []              # zone full, others wait
    admitted = [r.rack_id for r in await store.get_racks_in_state(S.BASELINE)]
    await all_nodes(store, admitted[0], "functional_validation", passed=False, nodes=["ct00"])
    assert await store.active_rack_count_in_zone("zA") == 0
    assert len(await sched.admit_waiting_racks()) == 1          # slot freed -> next rack


async def test_stagger_interval_enforced(store):
    store.cfg.start_interval_s = 300
    sched = BurninScheduler(store.cfg, store)
    for rid in ("r1", "r2"):
        await new_rack(store, rid)
        await all_nodes(store, rid, "boot_validation")
    assert len(await sched.admit_waiting_racks()) == 1
    assert await sched.admit_waiting_racks() == []


async def test_node_abort_records_component_and_releases_slot(store):
    sched = BurninScheduler(store.cfg, store)
    await new_rack(store)
    await all_nodes(store, "rack-1", "boot_validation")
    await sched.admit_waiting_racks()
    run = (await store.get_rack("rack-1")).run_id
    await store.apply_node_event("rack-1", "ct05", ev(run, "abort", {"abort_events": [{
        "condition": "xid_79", "message": "fell off bus",
        "component": {"type": "gpu", "node_id": "ct05", "serial": "1654321"}}]}))
    r = await store.get_rack("rack-1")
    assert r.state == S.ABORTED
    assert r.failed_components[0]["serial"] == "1654321"
    assert await store.active_rack_count_in_zone("zA") == 0
    d = await store.get_directive("rack-1", "ct01")
    assert d["command"] == "abort"                               # other trays stop too


async def test_duplicate_and_stale_events(store):
    await new_rack(store)
    run = (await store.get_rack("rack-1")).run_id
    e = ev(run, "phase_result", {"phase": "boot_validation", "passed": True, "metrics": {}})
    assert (await store.apply_node_event("rack-1", "ct00", e))["status"] == "ok"
    assert (await store.apply_node_event("rack-1", "ct00", e))["status"] == "duplicate"
    with pytest.raises(StaleRun):
        await store.apply_node_event("rack-1", "ct00", ev("old-run", "state", {"state": "X"}))


async def test_transition_validation(store):
    await new_rack(store)
    with pytest.raises(InvalidTransition):
        await store.transition_state("rack-1", "BURNING", "skip ahead", "op")
    r = await store.transition_state("rack-1", "BURNING", "forced", "op", force=True)
    assert r.state == S.BURNING


async def test_rerun_counts_persist_and_quarantine(store):
    store.cfg.max_reruns = 2
    await new_rack(store)
    run1 = (await store.get_rack("rack-1")).run_id
    await store.record_abort("rack-1", [{"condition": "x"}], {})
    r = await store.triage("rack-1", "RE_RUN", "retry", "eng1")
    assert r.state == S.ONBOARDING and r.run_count == 1 and r.run_id != run1
    assert r.nodes == {} and r.run_history
    await store.record_abort("rack-1", [{"condition": "x"}], {})
    r = await store.triage("rack-1", "RE_RUN", "retry", "eng1")
    assert r.state == S.QUARANTINED and r.run_count == 2


async def test_stale_node_aborts_rack(store):
    await new_rack(store)
    await all_nodes(store, "rack-1", "boot_validation")
    await store.record_heartbeat("rack-1", "ct03", HeartbeatRequest())
    await store.r.zadd("hb", {"rack-1|ct03": time.time() - 3600})
    await store.check_stale_nodes()
    r = await store.get_rack("rack-1")
    assert r.state == S.ABORTED and "ct03" in r.state_reason


async def test_single_scheduler_leader(store):
    a, b = BurninScheduler(store.cfg, store), BurninScheduler(store.cfg, store)
    assert await store.acquire_or_renew_leader(a.instance_id, 90000)
    assert not await store.acquire_or_renew_leader(b.instance_id, 90000)
    assert await store.acquire_or_renew_leader(a.instance_id, 90000)   # renew


async def test_unexpected_extra_node_rejected(store):
    await new_rack(store)
    await all_nodes(store, "rack-1", "boot_validation")
    run = (await store.get_rack("rack-1")).run_id
    with pytest.raises(Exception):
        await store.apply_node_event("rack-1", "ct99", ev(run, "state", {"state": "BOOTING"}))


async def test_fleet_summary_uses_indexes(store):
    await new_rack(store, "r1")
    await new_rack(store, "r2")
    s = await store.get_fleet_summary()
    assert s["total"] == 2 and s["by_state"]["ONBOARDING"] == 2


async def test_fabric_cluster_uuid_mismatch_fails_rack(store):
    await new_rack(store)
    run = (await store.get_rack("rack-1")).run_id
    for i, n in enumerate(NODES):
        uuid_ = "A" if i != 7 else "B"
        await store.apply_node_event("rack-1", n, ev(run, "phase_result", {
            "phase": "boot_validation", "passed": True,
            "metrics": {"failures": [], "fabric_cluster_uuids": [uuid_],
                        "fabric_clique_ids": ["32766"]}}))
    r = await store.get_rack("rack-1")
    assert r.state == S.FAILED and "ClusterUUID" in r.state_reason
